package com.cern.client;

import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RadioButton;

import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;

import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Button;


public class FlexTableSizePannel extends HorizontalPanel
{

  private Label ftSizeLabel = new Label();
  TextBox ftSizeEntry = new TextBox();


  Button applyButton = new Button("Apply");



  public FlexTableSizePannel(final LogReader logReader) {

  //*******************************
  //assemble chooseCriticityPanel panel
  //*******************************


ftSizeLabel.setText( "Number of lines to display in the Logs table : (currently " + logReader.MAX_NUMBER_OF_LOGS_IN_TABLE + ")" );

this.add(ftSizeLabel);

  ftSizeLabel.addStyleDependentName("lineHeaderLabel");
  ftSizeLabel.setWordWrap(false);


this.add(ftSizeEntry);



this.add(applyButton);





applyButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {
		int ftSize = Integer.valueOf(ftSizeEntry.getText());
		logReader.MAX_NUMBER_OF_LOGS_IN_TABLE = ftSize;
ftSizeLabel.setText( "Number of lines to display in the Logs table : (currently " + logReader.MAX_NUMBER_OF_LOGS_IN_TABLE + ")" );

	logReader.cleanupFlexTable();
	logReader.cleanupErrorTree();
  	logReader.reparseLogsFile();
	logReader.refreshWatchList();


//		logReader.ft.
  }
} );





}







}












