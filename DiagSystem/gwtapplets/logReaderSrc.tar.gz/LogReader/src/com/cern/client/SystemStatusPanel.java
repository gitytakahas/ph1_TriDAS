package com.cern.client;

import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RadioButton;

import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;

import com.google.gwt.user.client.ui.TextArea;

import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HTMLTable.RowFormatter;
import com.google.gwt.i18n.client.DateTimeFormat;
import java.util.Date;



public class SystemStatusPanel extends VerticalPanel
{



  //Logs Criticity selection related pannel
//  public HorizontalPanel chooseCriticityPanel = new HorizontalPanel();

/*
  private Label connectionModeStatusLabel = new Label("Status of connection to JSON data source : ");
  private Label timerStatusLabel = new Label("Status of auto-refresh timer : ");
  private Label timerIntervalLabel = new Label("Value in milliseconds of auto-refresh timer interval : ");
  private Label logsStatusLabel = new Label("Number of logs currently in display buffer (table) : ");
*/
  private TextArea ta = new TextArea();

  private FlexTable ft = new FlexTable();

  private int flexTableMaxIndex = 100;
  private int flexTableCurrentIndex = 0;
// public int toto = 14;


public Label titleLabel = new Label("Applet Monitoring Pannel");

  public SystemStatusPanel(final LogReader logReader) {

  //*******************************
  //assemble chooseCriticityPanel panel
  //*******************************
/*
  getConnectionModeStatus(logReader);
 this.add(connectionModeStatusLabel);

  getTimerStatusLabel(logReader);
 this.add(timerStatusLabel);

  getTimerIntervalLabel(logReader);
 this.add(timerIntervalLabel);

 this.add(logsStatusLabel);

*/
  this.add(titleLabel);

  //Initialize textArea
  ta.setCharacterWidth(200);
  ta.setVisibleLines(5);
  this.add(ta);


  //Initialize FlexTable
  for (int i=0; i<flexTableMaxIndex; i++)
  {
    ft.setText(flexTableCurrentIndex, 0, " ");
	flexTableCurrentIndex++; if (flexTableCurrentIndex >= flexTableMaxIndex) {flexTableCurrentIndex=0;}
  }

/*
    addMsgToDisplayList(getConnectionModeStatus(logReader) + "\n");
    addMsgToDisplayList(getTimerStatusLabel(logReader) + "\n");
    addMsgToDisplayList(getTimerIntervalLabel(logReader) + "\n");
    displayMsgListContent();
*/
/*
  refreshConnectionStatusInfos(logReader);
  refreshTimerInfos(logReader);
  refreshTimeIntervalInfos(logReader);
*/
}
  


public void refreshConnectionStatusInfos(final LogReader logReader)
{
addMsgToDisplayList(getConnectionModeStatus(logReader) + "\n");
displayMsgListContent();
}



public void refreshTimerInfos(final LogReader logReader)
{
addMsgToDisplayList(getTimerStatusLabel(logReader) + "\n");
displayMsgListContent();
}


public void refreshTimeIntervalInfos(final LogReader logReader)
{
addMsgToDisplayList(getTimerIntervalLabel(logReader) + "\n");
displayMsgListContent();
}


public void refreshStreamingTimeIntervalInfos(final LogReader logReader)
{
addMsgToDisplayList(getTimerStreamingIntervalLabel(logReader) + "\n");
displayMsgListContent();
}





public void addMsgToDisplayList(String Message)
{
	String fullMsg;
	fullMsg = DateTimeFormat.getMediumDateTimeFormat().format(new Date()) + ":" + Message;
    ft.setText(flexTableCurrentIndex, 0, fullMsg);
	flexTableCurrentIndex++; if (flexTableCurrentIndex >= flexTableMaxIndex) {flexTableCurrentIndex=0;}

}



public void displayMsgListContent()
{
  int flexTableParseIndex = flexTableCurrentIndex-1;
  if (flexTableParseIndex < 0) flexTableParseIndex = flexTableMaxIndex-1;

  //Pour "le nombre de ligens qu'on a dans la table
  String toDisplay = "";
  for (int i=0; i<flexTableMaxIndex; i++)
  {
    toDisplay = toDisplay + 
    ft.getText(flexTableParseIndex, 0);
	flexTableParseIndex--;
	if (flexTableParseIndex < 0) flexTableParseIndex = flexTableMaxIndex-1;
  }

  ta.setText(toDisplay);

}





public void refreshInfos(final LogReader logReader)
{
addMsgToDisplayList(getConnectionModeStatus(logReader) + "\n");
addMsgToDisplayList(getTimerStatusLabel(logReader) + "\n");
addMsgToDisplayList(getTimerIntervalLabel(logReader) + "\n");
displayMsgListContent();
}





public String getConnectionModeStatus(final LogReader logReader) {
if (logReader.hasAttemptedOneConnection == false)
{

if (logReader.isRunningXsiteScript == false)
{
	return ("Status of connection to JSON data source : " + "Working in automated data server source detection, Polling for a data server source with " + logReader.Defs.LID_MIN_POLL_LIMIT + "<=LID<=" + logReader.Defs.LID_MAX_POLL_LIMIT);
}
else
{
	return ("Status of connection to JSON data source : " + "Working in cross-site scripting server source access, Polling for a data server source on URL " + logReader.JSON_URL);
}
//connectionModeStatusLabel.setText("Status of connection to JSON data source : " + "Polling for a data server source...");
}
else
{
	if (logReader.isRunningXsiteScript == false)
	{
		if (logReader.hasFindJsonServerSource == true)
		{
			return ("Status of connection to JSON data source : " + "Working in automated data server source detection. " + "Detection successful, using URL : " + logReader.JSON_URL);
		}
		else
		{
			return ("Status of connection to JSON data source : " + "Working in automated data server source detection. " + "Error during detection, poll timer stopped");
		}
	}
	else
	{
		if (logReader.hasFindJsonServerSource == true)
		{
			return ("Status of connection to JSON data source : " + "Working in cross-site scripting server source access. " + "Detection successful, using URL : " + logReader.JSON_URL);
		}
		else
		{
			return ("Status of connection to JSON data source : " + "Working in cross-site scripting server source access. " + "Error during detection on URL " +  logReader.JSON_URL + ", poll timer stopped.");
		}

	}
}


}








public String getTimerStatusLabel(final LogReader logReader) {
if (logReader.timerIsOn == false)
{
	return ("Status of auto-refresh timer : " + "OFF");
}
else
{
	return ("Status of auto-refresh timer : " + "ON");
}
}




public String getTimerIntervalLabel(final LogReader logReader) {
	return ("Value in milliseconds of auto-refresh timer interval : " + logReader.CURRENT_REFRESH_INTERVAL);
}



public String getTimerStreamingIntervalLabel(final LogReader logReader) {
	return ("Value in milliseconds of streaming timer interval : " + logReader.userdefinedStreamingRefreshInterval);
}





}


















