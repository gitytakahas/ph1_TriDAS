package com.cern.client;

import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
//import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.ListBox;

import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HTMLTable.RowFormatter;

import com.google.gwt.user.client.ui.TreeItem;


//import com.google.gwt.user.client.ui.ClickHandler;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;
//import com.google.gwt.user.client.Window.Location;
import com.google.gwt.user.client.Window;

import com.google.gwt.user.client.ui.ChangeListener;
import com.google.gwt.user.client.ui.Widget;


//import com.google.gwt.user.client.ui.TreeListener;
import com.google.gwt.user.client.ui.PopupPanel;

import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.user.client.ui.Button;


import com.google.gwt.user.client.Timer;


//public class DiagTreeItem extends TreeItem implements ClickHandler 
public class DiagTreePopup extends PopupPanel
{
public Defines Defs = new Defines();


public VerticalPanel popupChoicesPanel = new VerticalPanel();

public VerticalPanel labelAndRadioPanel = new VerticalPanel();
public HorizontalPanel buttonsPanel = new HorizontalPanel();

Label popupLabel = new Label();

public RadioButton rbShow = new RadioButton("myRadioGroup", "Show");
public RadioButton rbHide = new RadioButton("myRadioGroup", "Hide");
public RadioButton rbFocus = new RadioButton("myRadioGroup", "Focus");

 Button applyButton = new Button("Ok");
 Button cancelButton = new Button("Cancel");



public LogReader LogReader;
public DiagTreeItem diagTreeItem;

    public DiagTreePopup(final LogReader logReaderReference)
    {
      // PopupPanel's constructor takes 'auto-hide' as its boolean parameter.
      // If this is set, the panel closes itself automatically when the user
      // clicks outside of it.
      //super(true);
      super(true);

//Window.alert("In popup instanciation");
//this.setAnimationEnabled(true);


LogReader = logReaderReference;


applyButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
/*
	String message = "";
	if (rbShow.isChecked() == true)
	{
		message += "SHOW=true";
	}
	else message += "SHOW=false";


	if (rbHide.isChecked() == true)
	{
		message += "HIDE=true";
	}
	else message += "HIDE=false";


	if (rbFocus.isChecked() == true)
	{
		message += "FOCUS=true";
	}
	else message += "FOCUS=false";

	debugApplet(message);
*/

	if (rbShow.isChecked() == true)
	{
		diagTreeItem.showInLogsTable = true;
		diagTreeItem.hideInLogsTable = false;
		diagTreeItem.focusInLogsTable = false;
	}
	else diagTreeItem.showInLogsTable = false;


	if (rbHide.isChecked() == true)
	{
		diagTreeItem.showInLogsTable = false;
		diagTreeItem.hideInLogsTable = true;
		diagTreeItem.focusInLogsTable = false;
	}
	else diagTreeItem.hideInLogsTable = false;



	if (rbFocus.isChecked() == true)
	{
		diagTreeItem.showInLogsTable = false;
		diagTreeItem.hideInLogsTable = false;
		diagTreeItem.focusInLogsTable = true;
	}
	else diagTreeItem.focusInLogsTable = false;


fireAppletModifications(diagTreeItem);

	hideApplet();
  }
} );


//    }




//Window.alert("In popup instanciation 6");





cancelButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
	hideApplet();
  }
} );

//Window.alert("In popup instanciation 7");

    } //END OF CLASS CONSTRUCTOR






  public void setDiagTreeItemReference(DiagTreeItem diagTreeItemReference) {
    diagTreeItem = diagTreeItemReference;
    

//Window.alert("In popup instanciation 1");

if (diagTreeItem.showInLogsTable == true)
{
	rbShow.setChecked(true);
}
else rbShow.setChecked(false);

//Window.alert("In popup instanciation 2");


if (diagTreeItem.hideInLogsTable == true)
{
	rbHide.setChecked(true);
}
else rbHide.setChecked(false);

//Window.alert("In popup instanciation 3");


if (diagTreeItem.focusInLogsTable == true)
{
	rbFocus.setChecked(true);
}
else rbFocus.setChecked(false);

//Window.alert("In popup instanciation 4");


    labelAndRadioPanel.add(popupLabel);
    labelAndRadioPanel.add(rbShow);
    labelAndRadioPanel.add(rbHide);
    labelAndRadioPanel.add(rbFocus);
    labelAndRadioPanel.setStyleName("gwt-Popup-Pannel-Background");
    buttonsPanel.add(applyButton);
    buttonsPanel.add(cancelButton);
    buttonsPanel.setStyleName("gwt-Popup-Pannel-Background");
    
//Window.alert("In popup instanciation 5");
popupChoicesPanel.add(labelAndRadioPanel);
popupChoicesPanel.add(buttonsPanel);
popupChoicesPanel.setStyleName("gwt-Popup-Pannel-Background");
      // PopupPanel is a SimplePanel, so you have to set it's widget property to
      // whatever you want its contents to be.
      setWidget(popupChoicesPanel);

  }








  public void hideApplet() {
    this.hide();
  }



  public void debugApplet(String message) {
popupLabel.setText(message);
  }




  public void fireAppletModifications(final DiagTreeItem diagTreeItem) {

	if (diagTreeItem.focusInLogsTable == true)
	{
		LogReader.manageFocusRequest(diagTreeItem.machineNodeLevel, diagTreeItem.portNodeLevel, diagTreeItem.procnameNodeLevel, diagTreeItem.instanceNodeLevel);
	}
	else if (diagTreeItem.showInLogsTable == true)
	{
		LogReader.manageShowHideRequest(diagTreeItem.machineNodeLevel, diagTreeItem.portNodeLevel, diagTreeItem.procnameNodeLevel, diagTreeItem.instanceNodeLevel, true);
	}
	else if (diagTreeItem.showInLogsTable == false)
	{
		LogReader.manageShowHideRequest(diagTreeItem.machineNodeLevel, diagTreeItem.portNodeLevel, diagTreeItem.procnameNodeLevel, diagTreeItem.instanceNodeLevel, false);
	}

	LogReader.redrawFlexTableAccordingToTreeMasking();

  }





}













