package com.cern.client;


import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.HorizontalSplitPanel;
import com.google.gwt.user.client.ui.VerticalSplitPanel;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Tree;
import com.google.gwt.user.client.ui.TreeItem;
import com.google.gwt.user.client.ui.FlexTable;

import com.google.gwt.user.client.ui.HTMLTable.ColumnFormatter;

import com.google.gwt.user.client.ui.HTMLTable.CellFormatter;
import com.google.gwt.user.client.ui.FileUpload;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Frame;


import com.google.gwt.user.client.Window;

import java.util.ArrayList;
import com.google.gwt.user.client.Timer;

import com.google.gwt.user.client.Random;

import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.i18n.client.NumberFormat;

import java.util.Date;


import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONException;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.json.client.JSONValue;
import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.gwt.http.client.URL;

import java.util.Iterator;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.ui.HTMLTable.RowFormatter;

import com.google.gwt.user.client.ui.RadioButton;

import java.lang.Throwable;


import com.google.gwt.user.client.ui.ListBox;


import com.google.gwt.user.client.Element;

//import com.google.gwt.user.client.ui.TabPanel;
import com.google.gwt.user.client.ui.HorizontalSplitPanel;
import com.google.gwt.user.client.ui.Tree;

import com.google.gwt.user.client.Window.Location;


//import com.google.gwt.core.ext.typeinfo.JPrimitiveType;
import com.google.gwt.core.client.JavaScriptObject;


import com.allen_sauer.gwt.voices.client.Sound;
import com.allen_sauer.gwt.voices.client.SoundController;
import com.allen_sauer.gwt.voices.client.ui.NativeSoundWidget;
import com.allen_sauer.gwt.voices.client.ui.VoicesMovieWidget;

//import com.allen_sauer.gwt.voices.client.handler.SoundCompleteEvent;
import com.allen_sauer.gwt.voices.client.handler.SoundHandler;
import com.allen_sauer.gwt.voices.client.handler.SoundLoadStateChangeEvent;
import com.allen_sauer.gwt.voices.client.handler.PlaybackCompleteEvent;


import com.google.gwt.user.client.ui.TreeListener;


import com.google.gwt.user.client.ui.TabPanel;


public class LogReader implements EntryPoint
{

//DEBUG
//public ListBox nodeListBox = new ListBox();


//public String[] resu;
public Defines Defs = new Defines();
  public String JSON_URL = "";

  //FlexTable used to store received logs
  public LogsFlexTable ft = new LogsFlexTable(this);

//  private ControlCriticityPannel controlCriticityPannel = new ControlCriticityPannel();   
  private ConnectionParametersPannel connectionParametersPannel = new ConnectionParametersPannel(this);   

  private ControlCriticityPannel controlCriticityPannel = new ControlCriticityPannel(this);   
  private ColumnsManagementPannel columnsManagementPannel = new ColumnsManagementPannel(this);   


  private SystemStatusPanel systemStatusPanel = new SystemStatusPanel(this);   


  private UpdateRatePannel updateRatePannel = new UpdateRatePannel(this);


  //Define panels
//  private VerticalSplitPanel mainPanel = new VerticalSplitPanel();   
  private VerticalPanel mainPanel = new VerticalPanel();   




  private VerticalPanel logsManagementPanel = new VerticalPanel();   
  private VerticalPanel logsDisplayPanel = new VerticalPanel();

  private VerticalPanel treeDisplayPanel = new VerticalPanel();

  //Define labels used as panels headers
//  public Label logsManagementLabel = new Label();


  //Informationnal label, aka. keepalive
  private Label lastUpdatedLabel = new Label("");


  //Refresh timer rate in milliseconds
//  private static final int REFRESH_INTERVAL = 5000; // ms
//  private int STANDARD_REFRESH_INTERVAL = 5000; // ms
//  private int QUICK_REFRESH_INTERVAL = 1000; // ms
  public int CURRENT_REFRESH_INTERVAL; // ms
  public int USER_DEFINED_REFRESH_INTERVAL; // ms



  public String userdefinedRefreshInterval = ""; // ms
  public String userdefinedStreamingRefreshInterval = ""; // ms

  public String fileParsingCommand = ""; // ms



  //Target XDAQ Url delivering the JSON data array
//  private static final String JSON_URL = "http://cmstkint11.cern.ch:14000/urn:xdaq-application:lid=20/getJSONDataList";
//  private String JSON_URL = "http://cmstkint11.cern.ch:14000/urn:xdaq-application:lid=20/getJSONDataList";

  //Generic errorsMsgLabel
//  private Label errorMsgLabel = new Label("");
  
  
  //Html helpers
/*
  HTML htmlLine = new HTML("<HR>");
  HTML htmlBreak = new HTML("<BR>");
  HTML htmlSpacer3 = new HTML("&nbsp;&nbsp;&nbsp;");

*/
//  private static final String HIDE_CTRL_BUTTON = "Hide control pannel";
//  private static final String SHOW_CTRL_BUTTON = "Show control pannel";


  
  //Manage log display properties
  //Control buttons related pannel
  private HorizontalPanel controlPanel = new HorizontalPanel();
  Button controlPannelButton = new Button(Defs.HIDE_CTRL_BUTTON);


  Button appletActivityLogsButton = new Button(Defs.HIDE_LOGS_BUTTON);

  Button parserButton = new Button(Defs.HIDE_PARSER_BUTTON);


  private boolean showControl = false;

  private boolean showAppletActivity = true;

  private boolean showParser = false;



  //Define labels used as panels headers
//  public Label infoMsgLabel = new Label("NoInfo");




  private HorizontalSplitPanel endPanel = new HorizontalSplitPanel();   




//DEBUG
//  private VerticalPanel glbPanel = new VerticalPanel();   


  Tree errorsTree = new Tree();

//DNEW
  Tree hardwareErrorsTree = new Tree();


  private int jsonLidFound = 0;
  private String peekJsonUrl;


  private long numberOfLogsInTable = 0;
public long MAX_NUMBER_OF_LOGS_IN_TABLE = Defs.DEFAULT_MAX_NUMBER_OF_LOGS_IN_TABLE;


  public int logsBurstLength = Defs.DEFAULT_LOGS_BURST_LENGTH;
  
    public String appletUid = Defs.DEFAULT_APPLET_UID;



  private Timer refreshTimer;

// public Timer waitActionCompletionTimer;

//String xdaqLID = "";
//String xdaqHost = "";


//  public JSONExternalWrapper MyJSONExternalWrapper = new JSONExternalWrapper();
//  public JSONHandler MyJSONHandler = new JSONHandler();


//public JSONHandler MyJSONHandler;


public boolean isRunningXsiteScript;

public String xsiteConnectionUrl = "";
public String xsiteConnectionLid = "";

public boolean hasAttemptedOneConnection;

public boolean timerIsOn;

public boolean hasFindJsonServerSource;





  private HorizontalPanel commandButtonsPanel = new HorizontalPanel();

  public Label controlPannelTitle = new Label("Control Pannel");




  private ReparseLogsFilePannel logsParserPanel = new ReparseLogsFilePannel(this);
//  public Label parserPannelTitle = new Label("Logs Parser Pannel");


//  Button reparseAllButton = new Button(Defs.REPARSE_ALL_BUTTON);
/*
  Button parseBackButton = new Button(Defs.PARSE_BACK_BUTTON);
  Button parseForwardButton = new Button(Defs.PARSE_FORWARD_BUTTON);
*/

  public FlexTableSizePannel flexTableSizePannel = new FlexTableSizePannel(this);

  public DataBlockLengthPerReadoutPannel dataBlockLengthPerReadoutPannel = new DataBlockLengthPerReadoutPannel(this);



public int currentSubClassesToProcessInTree;
public String[] subClassesList;




SoundController soundController;
Sound soundTrace;
Sound soundDebug;
Sound soundInfo;
Sound soundWarn;
Sound soundUserinfo;
Sound soundError;
Sound soundFatal;



  public LogReader LogReaderReference;



  Button activateTreeButton = new Button(Defs.ENABLE_TREE_EVENTS_BUTTON_LABEL);
  boolean treeRespondsToEvents = false;



DiagTreePopup dtp;
  boolean treePopupExists = false;







 public boolean USE_SOUNDS_FOR_TRACE = true;
 public boolean USE_SOUNDS_FOR_DEBUG = true;
 public boolean USE_SOUNDS_FOR_INFO = true;
 public boolean USE_SOUNDS_FOR_WARN = true;
 public boolean USE_SOUNDS_FOR_USERINFO = true;
 public boolean USE_SOUNDS_FOR_ERROR = true;
 public boolean USE_SOUNDS_FOR_FATAL = true;




public int lastNLogsToParse = -1;









//HWXDEPS
public String hwdepsFecCrate = "";
public String hwdepsFecSlot = "";
public String hwdepsFecRing = "";
public String hwdepsFecCcu = "";
public String hwdepsFecI2cChannel = "";
public String hwdepsFecI2cAddress = "";

public String hwdepsFedCrate = "";
public String hwdepsFedSlot = "";
public String hwdepsFedChannel = "";

public String hwdepsDetId = "";

Button hwdepsTestButton = new Button("Test Hardware Dependancies");

public String xdaqServerLid="";



//public boolean autoReconnectWhenXdaqStops = Defs.FORCE_EXPLICIT_RECONNECTION_WHEN_XDAQ_STOPS;



  public void onModuleLoad()
  {

LogReaderReference = this;


USE_SOUNDS_FOR_TRACE = Defs.USE_SOUNDS_FOR_TRACE;
USE_SOUNDS_FOR_DEBUG = Defs.USE_SOUNDS_FOR_DEBUG;
USE_SOUNDS_FOR_INFO = Defs.USE_SOUNDS_FOR_INFO;
USE_SOUNDS_FOR_WARN = Defs.USE_SOUNDS_FOR_WARN;
USE_SOUNDS_FOR_USERINFO = Defs.USE_SOUNDS_FOR_USERINFO;
USE_SOUNDS_FOR_ERROR = Defs.USE_SOUNDS_FOR_ERROR;
USE_SOUNDS_FOR_FATAL = Defs.USE_SOUNDS_FOR_FATAL;
    




//Window.alert("Will create a new sound controller");
//    SoundController soundController = new SoundController();
    soundController = new SoundController();
//    Sound sound = soundController.createSound(Sound.MIME_TYPE_AUDIO_MPEG,
    soundTrace = soundController.createSound(Sound.MIME_TYPE_AUDIO_MPEG, "sounds/soundTrace.mp3");
    soundDebug = soundController.createSound(Sound.MIME_TYPE_AUDIO_MPEG, "sounds/soundDebug.mp3");
    soundInfo = soundController.createSound(Sound.MIME_TYPE_AUDIO_MPEG, "sounds/soundInfo.mp3");
    soundWarn = soundController.createSound(Sound.MIME_TYPE_AUDIO_MPEG, "sounds/soundWarn.mp3");
    soundUserinfo = soundController.createSound(Sound.MIME_TYPE_AUDIO_MPEG, "sounds/soundUserinfo.mp3");
    soundError = soundController.createSound(Sound.MIME_TYPE_AUDIO_MPEG, "sounds/soundError.mp3");
    soundFatal = soundController.createSound(Sound.MIME_TYPE_AUDIO_MPEG, "sounds/soundFatal.mp3");
//        "http://sbgat248.cern.ch:14000/gwtapplets/LogReader/sample-1.swf");
//        "http://www.a1sounddownload.com/freesounds5/alarmring.mp3");

//sound.play();
//Window.alert("End of new sound controller creation");






currentSubClassesToProcessInTree = 0;

isRunningXsiteScript = false;
hasAttemptedOneConnection = false;
hasFindJsonServerSource = false;
timerIsOn = false;

CURRENT_REFRESH_INTERVAL = Defs.STANDARD_REFRESH_INTERVAL;
USER_DEFINED_REFRESH_INTERVAL = Defs.STANDARD_REFRESH_INTERVAL;
lastUpdatedLabel.setText("Not refreshed yet" + " (Update rate : " + CURRENT_REFRESH_INTERVAL/1000 + " seconds)");
//showHeartBeatLabel();
/* 
	TabPanel tp = new TabPanel();
	tp.setWidth("100%");
	tp.setHeight("100%");
*/


/*
//    TreeItem tracker = new TreeItem("Tracker");
    DiagTreeItem tracker = new DiagTreeItem(Defs.SUBDETECTOR_NAME);
     // Create a tree with a few items in it.
    errorsTree.addItem(tracker);
    tracker.setNodeProperties(Defs.SUBDETECTOR_NAME);
*/
 
  ft.setColumnsHeaders();



//DNEW
/*
    TreeItem detector = new TreeItem("Detector");
     // Create a tree with a few items in it.
    hardwareErrorsTree.addItem(detector);
*/





/*
/////////////////////////////
//Debug on startup section
LogMessage logMessage = new LogMessage( "level",
										"errCode",
										"message",
										"timestamp",
										"source",
										"systemid",
										"subsystemid",
										"extraBuffer",
										"machine",
										"port",
										"procname",
										"procinstance");
updateTable(logMessage);


logMessage.setLevel("TRACE");
updateTable(logMessage);

logMessage.setLevel("DEBUG");
updateTable(logMessage);

logMessage.setLevel("INFO");
updateTable(logMessage);

logMessage.setLevel("WARN");
updateTable(logMessage);

logMessage.setLevel("USERINFO");
logMessage.setPort("toto");
updateTable(logMessage);

logMessage.setLevel("ERROR");
logMessage.setMachine("otherMachine");
updateTable(logMessage);

logMessage.setLevel("FATAL");
logMessage.setProcInstance("22");
updateTable(logMessage);
//End of Debug on startup section
/////////////////////////////

*/

  //*******************************
  //assemble controlPannelButton panel
  //*******************************


//ZZZZZZZZZZZZZZZZZz
//controlPanel.add(controlPannelButton);
//controlPanel.add(appletActivityLogsButton);


  //*******************************
  //assemble logsManagement panel
  //*******************************
/*
chooseCriticityPanel.setBorderWidth(1);
columnManagementPanel.setBorderWidth(1);
logsManagementPanel.setBorderWidth(1);
*/

//controlCriticityPannel.initializeControlCriticityPannel();


//  logsManagementPanel.add(logsManagementLabel);


//  logsManagementPanel.add(controlPanel);


  logsManagementPanel.add(controlPannelTitle);

  logsManagementPanel.add(connectionParametersPannel);
  logsManagementPanel.add(updateRatePannel);
  logsManagementPanel.add(controlCriticityPannel);
  logsManagementPanel.add(columnsManagementPannel);
  logsManagementPanel.add(flexTableSizePannel);
  logsManagementPanel.add(dataBlockLengthPerReadoutPannel);
  

  hideControlPannel();

/*
	treeDisplayPanel.add(lastUpdatedLabel);
	treeDisplayPanel.add(errorMsgLabel);
	treeDisplayPanel.add(infoMsgLabel);
*/


//ZZZZZZZZZZZZZZzz
//  logsManagementPanel.add(lastUpdatedLabel);
//  errorMsgLabel.setText("Last system log : " + errorMsgLabel.getText());
//  logsManagementPanel.add(errorMsgLabel);

//  logsManagementPanel.add(testPanel.iChooseCriticityPanel);



  //*******************************
  //assemble logsParserPanel panel
  //*******************************

//  logsParserPanel.add(parserPannelTitle);

//  logsParserPanel.add(reparseAllButton);
//  logsParserPanel.add(parseBackButton);
//  logsParserPanel.add(parseForwardButton);



  hideParserPannel();

  //*******************************
  //assemble logsDisplayPanel panel
  //*******************************

  logsDisplayPanel.add(ft);


  //*******************************
  //assemble logsManagement + logsDisplayPanel = mainPanel
  //*******************************
//  mainPanel.setTopWidget(logsManagementPanel);
//  mainPanel.setBottomWidget(logsDisplayPanel);


commandButtonsPanel.add(controlPannelButton);
commandButtonsPanel.add(appletActivityLogsButton);
commandButtonsPanel.add(parserButton);
mainPanel.add(commandButtonsPanel);


logsManagementPanel.setBorderWidth(10);
  mainPanel.add(logsManagementPanel);



logsParserPanel.setBorderWidth(10);
  mainPanel.add(logsParserPanel);


  mainPanel.add(lastUpdatedLabel);
logsDisplayPanel.setBorderWidth(2);
  mainPanel.add(logsDisplayPanel);


systemStatusPanel.setBorderWidth(10);
  mainPanel.add(systemStatusPanel);






	//FOR DEBUG PURPOSES ONLY ???
/*
	treeDisplayPanel.add(lastUpdatedLabel);
	treeDisplayPanel.add(errorMsgLabel);
	treeDisplayPanel.add(infoMsgLabel);
*/

//HWXDEPS
	treeDisplayPanel.add(hwdepsTestButton);

	treeDisplayPanel.add(activateTreeButton);
	treeDisplayPanel.add(errorsTree);

//DNEW
	treeDisplayPanel.add(hardwareErrorsTree);




  //*******************************
  //associate builup panels to root panel
  //*******************************
  // add the main panel to the HTML element with the id "stockList"
endPanel.setRightWidget(mainPanel);
endPanel.setLeftWidget(treeDisplayPanel);


//endPanel.add(systemStatusPanel);
//DEBUG
//glbPanel.add(endPanel);

//  RootPanel.get().add(mainPanel);


  RootPanel.get().add(endPanel);



//  RootPanel.get().add(glbPanel);


//RootPanel.get().add(systemStatusPanel);

/*
	tp.add(mainPanel, "MessagesList");
    // Show the 'bar' tab initially.
//    tp.selectTab(1);
*/

//  RootPanel.get().add(tp);
    

//lastUpdatedLabel.setText( RootPanel.get().getBodyElement().toString() );
//   lastUpdatedLabel.setText("Last update : " + DateTimeFormat.getMediumDateTimeFormat().format(new Date()));







controlPannelButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
		if (showControl == true)
		{
		    hideControlPannel(/*controlPannelButton*/);
		}
		else
		{
		    showControlPannel(/*controlPannelButton*/);
		}
  }
} );



appletActivityLogsButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
		if (showAppletActivity == true)
		{
		    hideAppletActivityPannel(/*controlPannelButton*/);
		}
		else
		{
		    showAppletActivityPannel(/*controlPannelButton*/);
		}
  }
} );



parserButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
		if (showParser == true)
		{
		    hideParserPannel(/*controlPannelButton*/);
		}
		else
		{
		    showParserPannel(/*controlPannelButton*/);
		}
  }
} );







//HWXDEPS
hwdepsTestButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
//	Window.alert("Hardware dependancies testing required");
	getHwDependancies();
  }
} );





errorsTree.addTreeListener(new TreeListener()
{
  public void onTreeItemStateChanged(TreeItem item)
  {
	  //Window.alert("state changed");
  }
  
  

    public void onTreeItemSelected(TreeItem item)
  {

	if (treeRespondsToEvents == true)
	{
	DiagTreeItem myItem = (DiagTreeItem)item;


	//String popMsg;
/*
	popMsg = "subdetectorNodeLevel=" + myItem.subdetectorNodeLevel;
	if (!(myItem.machineNodeLevel.equals(Defs.INIT_TREENODE_VALUE)))
	{ popMsg += "\nmachineNodeLevel=" + myItem.machineNodeLevel;}
	if (!(myItem.portNodeLevel.equals(Defs.INIT_TREENODE_VALUE)))
	{popMsg += "\nportNodeLevel=" + myItem.portNodeLevel;}
	if (!(myItem.procnameNodeLevel.equals(Defs.INIT_TREENODE_VALUE)))
	{popMsg += "\nprocnameNodeLevel=" + myItem.procnameNodeLevel;}
	if (!(myItem.instanceNodeLevel.equals(Defs.INIT_TREENODE_VALUE)))
	{popMsg += "\ninstanceNodeLevel=" + myItem.instanceNodeLevel;}
*/

/*
	if (!(myItem.classnameNodeLevel.equals(Defs.INIT_TREENODE_VALUE)))
	{popMsg += "\nclassnameNodeLevel=" + myItem.classnameNodeLevel;}
	if (!(myItem.subclassnameNodeLevel.equals(Defs.INIT_TREENODE_VALUE)))
	{popMsg += "\nsubclassnameNodeLevel=" + myItem.subclassnameNodeLevel;}
	if (!(myItem.subclassnameNodeLevel.equals(Defs.INIT_TREENODE_VALUE)))	
	{popMsg += "\nsubsubclassnameNodeLevel=" + myItem.subsubclassnameNodeLevel;}
*/	
	//Window.alert(popMsg);


	if ( (myItem.classnameNodeLevel.equals(Defs.INIT_TREENODE_VALUE)) && (myItem.subclassnameNodeLevel.equals(Defs.INIT_TREENODE_VALUE)) && (myItem.subsubclassnameNodeLevel.equals(Defs.INIT_TREENODE_VALUE)) )
	{
		//Set popup variable references;
//		dtp.setDiagTreeItemReference(myItem);

		//popMsg = "DISPLAY FILTER OPTIONS";
		//DiagTreePopup dtp = new DiagTreePopup(myItem, LogReaderReference);
		if (treePopupExists == false)	
		{
			dtp = new DiagTreePopup(LogReaderReference);
			String popMsg = "DISPLAY FILTER OPTIONS";
			dtp.popupLabel.setText(popMsg);
			treePopupExists = true;
		}

		dtp.setDiagTreeItemReference(myItem);
		dtp.center();
		dtp.show();
	}
	
	}
  }

} );




activateTreeButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {
	if (treeRespondsToEvents == false)
	{
		treeRespondsToEvents = true;
		activateTreeButton.setText(Defs.DISABLE_TREE_EVENTS_BUTTON_LABEL);
	}
	else
	{
		treeRespondsToEvents = false;
		activateTreeButton.setText(Defs.ENABLE_TREE_EVENTS_BUTTON_LABEL);
	}
  }
} );





/*
controlCriticityPannel.rbTrace.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
		if (controlCriticityPannel.isRbTraceChecked() == true)
		{
			logsManagementLabel.setText("Must display logs table with TRACE ENABLED");
		}
		else logsManagementLabel.setText("Must display logs table with TRACE DISABLED");
  }
} );

*/


/*
	hideShowMessagesWithCriticity(	controlCriticityPannel.rbTraceChecked,
									controlCriticityPannel.rbDebugChecked,
									controlCriticityPannel.rbInfoChecked,
									controlCriticityPannel.rbWarnChecked,
									controlCriticityPannel.rbUserinfoChecked,
									controlCriticityPannel.rbErrorChecked,
									controlCriticityPannel.rbFatalChecked );
*/




//displayError("toto");
/***************************************/


 // setup timer to refresh list automatically
//  Timer refreshTimer = new Timer() {
  refreshTimer = new Timer() {
    public void run() {
      refreshWatchList();
    }
  };
CURRENT_REFRESH_INTERVAL = Defs.STANDARD_REFRESH_INTERVAL;
/***************************************/




/*

  waitActionCompletionTimer = new Timer() {
    public void run() {
      //refreshWatchList();
      blah();
    }
  };
waitActionCompletionTimer.cancel();

*/



findXdaqJsonServer();


//AAAAAAA
/*
  refreshTimer.scheduleRepeating(CURRENT_REFRESH_INTERVAL);
timerIsOn = true;
systemStatusPanel.refreshInfos(this);
*/

/*
  Window.alert("In main, launching JSON request");
  JSONExternalWrapper MyJSONExternalWrapper = new JSONExternalWrapper();
  JSONExternalWrapper.makeJSONRequest("http://cmstkint11.cern.ch:14000/urn:xdaq-application:lid=21/"+"getJsJSONDataList?alt=json-in-script&callback=",
										new JSONExternalWrapper.JSONHandler()
  {
    public void handleJSON(JavaScriptObject obj)
    {
      JSONObject resp= new JSONObject(obj);
      JSONArray jsonArray = resp.get("Logs").isArray();
         
      if (jsonArray != null)
      {
        updateTable(jsonArray);
      }
      else
      {
        throw new JSONException();
      }

    }
  }	
  );
*/



//  Window.alert("In main, end of JSON request execution");

//JSONExternalWrapper.makeJSONRequest("http://cmstRkint11.cern.ch:14000/urn:xdaq-application:lid=21/getJSONDataList?callback="/*, MyJSONHandler*/);



//DEBUG
//nodeListBox.addItem("ligne1");
//errorsTree.addItem(nodeListBox);
//errorsTree.addItem(logsDisplayPanel);

/*

//Initialize popup static properties
String popMsg = "DISPLAY FILTER OPTIONS";
//DiagTreePopup dtp = new DiagTreePopup(myItem, LogReaderReference);
dtp.popupLabel.setText(popMsg);
dtp.setLogReaderReference(this);

*/

  } //end of OnLoad method






public void cleanupFlexTable(/*Button b*/)
{
  while (ft.getRowCount() > 1)
  {
    ft.removeRow(ft.getRowCount()-1);
  }
  numberOfLogsInTable = 0;

}



public void cleanupErrorTree(/*Button b*/)
{
	errorsTree.removeItems();
/*
    DiagTreeItem tracker = new DiagTreeItem(Defs.SUBDETECTOR_NAME);
     // Create a tree with a few items in it.
    errorsTree.addItem(tracker);
*/

}


public void cleanupHardwareErrorTree(/*Button b*/)
{
	hardwareErrorsTree.removeItems();
/*
    DiagTreeHardwareItem detector = new DiagTreeHardwareItem(Defs.HARDWARE_SUBDETECTOR_NAME);
     // Create a tree with a few items in it.
    hardwareErrorsTree.addItem(detector);
*/

}




public void reparseLogsFile(/*Button b*/)
{

	fileParsingCommand = "DO_REWIND=TRUE";

	if (controlCriticityPannel.rbTraceChecked == true) { fileParsingCommand = fileParsingCommand + "&TRACE=TRUE"; }
		else fileParsingCommand = fileParsingCommand + "&TRACE=FALSE";

	if (controlCriticityPannel.rbDebugChecked == true) { fileParsingCommand = fileParsingCommand + "&DEBUG=TRUE"; }
		else fileParsingCommand = fileParsingCommand + "&DEBUG=FALSE";

	if (controlCriticityPannel.rbInfoChecked == true) { fileParsingCommand = fileParsingCommand + "&INFO=TRUE"; }
		else fileParsingCommand = fileParsingCommand + "&INFO=FALSE";

	if (controlCriticityPannel.rbWarnChecked == true) { fileParsingCommand = fileParsingCommand + "&WARN=TRUE"; }
		else fileParsingCommand = fileParsingCommand + "&WARN=FALSE";

	if (controlCriticityPannel.rbUserinfoChecked == true) { fileParsingCommand = fileParsingCommand + "&USERINFO=TRUE"; }
		else fileParsingCommand = fileParsingCommand + "&USERINFO=FALSE";

	if (controlCriticityPannel.rbErrorChecked == true) { fileParsingCommand = fileParsingCommand + "&ERROR=TRUE"; }
		else fileParsingCommand = fileParsingCommand + "&ERROR=FALSE";

	if (controlCriticityPannel.rbFatalChecked == true) { fileParsingCommand = fileParsingCommand + "&FATAL=TRUE"; }
		else fileParsingCommand = fileParsingCommand + "&FATAL=FALSE";

	//Send data block length-per-readout  information
	fileParsingCommand = fileParsingCommand + "&LOGS_BURST_LENGTH=" + logsBurstLength;

	//Send data block length-per-readout  information
	fileParsingCommand = fileParsingCommand + "&READ_LIMITED_LOGS_NUMBER=" + lastNLogsToParse;

}





/*
public void sendEveryburstInfos()
{
	//Send data block length-per-readout  information
	fileParsingCommand = "LOGS_BURST_LENGTH=" + logsBurstLength;
}

*/




private void showControlPannel(/*Button b*/)
{
	controlPannelButton.setText(Defs.HIDE_CTRL_BUTTON);
	showControl = true;


	logsManagementPanel.setVisible(true);
/*
	connectionParametersPannel.setVisible(true);
	updateRatePannel.setVisible(true);
	controlCriticityPannel.setVisible(true);
	columnsManagementPannel.setVisible(true);
*/
}


private void hideControlPannel(/*Button b*/)
{
	controlPannelButton.setText(Defs.SHOW_CTRL_BUTTON);
	showControl = false;

	logsManagementPanel.setVisible(false);
/*
	connectionParametersPannel.setVisible(false);
	updateRatePannel.setVisible(false);
	controlCriticityPannel.setVisible(false);
	columnsManagementPannel.setVisible(false);
*/
}





private void showAppletActivityPannel(/*Button b*/)
{
	appletActivityLogsButton.setText(Defs.HIDE_LOGS_BUTTON);
	showAppletActivity = true;
	systemStatusPanel.setVisible(true);
}


private void hideAppletActivityPannel(/*Button b*/)
{
	appletActivityLogsButton.setText(Defs.SHOW_LOGS_BUTTON);
	showAppletActivity = false;
	systemStatusPanel.setVisible(false);
}



private void showParserPannel(/*Button b*/)
{
	parserButton.setText(Defs.HIDE_PARSER_BUTTON);
	showParser = true;
	logsParserPanel.setVisible(true);
}


private void hideParserPannel(/*Button b*/)
{
	parserButton.setText(Defs.SHOW_PARSER_BUTTON);
	showParser = false;
	logsParserPanel.setVisible(false);
}





private void showHeartBeatLabel()
{
  lastUpdatedLabel.setText("(Update rate : " + CURRENT_REFRESH_INTERVAL/1000 + " seconds) Last update : " + DateTimeFormat.getMediumDateTimeFormat().format(new Date()) + " from data source : " + JSON_URL + "  --  Number of logs buffered for display : " + (ft.getRowCount() - 1) + " for a max. of " + MAX_NUMBER_OF_LOGS_IN_TABLE + " at a time.");
}







private void updateTable(LogMessage[] messages) {
//  for (int i=0; i<messages.length; i++) {


//Window.alert("In updateTable[]; cancelling timer");
refreshTimer.cancel();
  for (int i=(messages.length-1); i>=0; i--) {


    int resu = updateTable(messages[i]);
  }
  // change the last update timestamp
//  lastUpdatedLabel.setText("Last update : " + DateTimeFormat.getMediumDateTimeFormat().format(new Date()));

//Window.alert("In updateTable[]; table now refreshed");


if (messages.length >= logsBurstLength)
{
//Window.alert("Long readout forseen ; messages.length >= logsBurstLength");

//displayError("PARTIAL RECOVERY OF MESSAGES ; GOT " + messages.length + " OUT OF " + logsBurstLength + " MESSAGES IN LIST");
if (CURRENT_REFRESH_INTERVAL != Defs.QUICK_REFRESH_INTERVAL)
{
//Window.alert("Forcing refresh interval to Defs.QUICK_REFRESH_INTERVAL");
	CURRENT_REFRESH_INTERVAL = Defs.QUICK_REFRESH_INTERVAL;
	refreshTimer.scheduleRepeating(CURRENT_REFRESH_INTERVAL);
	systemStatusPanel.refreshTimeIntervalInfos(this);
}
else
{
//Window.alert("Keeping refresh interval to Defs.QUICK_REFRESH_INTERVAL");
	refreshTimer.scheduleRepeating(CURRENT_REFRESH_INTERVAL);

}

//lastUpdatedLabel.setText("(Update rate : " + CURRENT_REFRESH_INTERVAL/1000 + " seconds) Last update : " + DateTimeFormat.getMediumDateTimeFormat().format(new Date()) + " from data source : " + JSON_URL);
}
else
{
//displayError("NO MORE MESSAGES TO RECOVER; GOT " + messages.length + " OUT OF " + logsBurstLength + " MESSAGES IN LIST");
//Window.alert("Short readout ; messages.length < logsBurstLength");



//CONDITIONS && PAS PRISES EN COMPTE ; LE TIMER USER DEFINED NE TIENS PAS LE PREMIER REFRESH

/*
Window.alert("Starting timer setup");
if (USER_DEFINED_REFRESH_INTERVAL != Defs.STANDARD_REFRESH_INTERVAL)
{
Window.alert("Step 1 over");
  if (USER_DEFINED_REFRESH_INTERVAL != Defs.QUICK_REFRESH_INTERVAL)
  {
Window.alert("Step 2 over");
    CURRENT_REFRESH_INTERVAL = USER_DEFINED_REFRESH_INTERVAL;
  }
}
else
{
Window.alert("Step ELSE triggered");
  CURRENT_REFRESH_INTERVAL = Defs.STANDARD_REFRESH_INTERVAL;
}
*/

if ( (USER_DEFINED_REFRESH_INTERVAL != Defs.STANDARD_REFRESH_INTERVAL) && (USER_DEFINED_REFRESH_INTERVAL != Defs.QUICK_REFRESH_INTERVAL) )
{

  if (CURRENT_REFRESH_INTERVAL != USER_DEFINED_REFRESH_INTERVAL)
  {
	CURRENT_REFRESH_INTERVAL = USER_DEFINED_REFRESH_INTERVAL;
	refreshTimer.scheduleRepeating(CURRENT_REFRESH_INTERVAL);
	systemStatusPanel.refreshTimeIntervalInfos(this);
  }

//  CURRENT_REFRESH_INTERVAL = USER_DEFINED_REFRESH_INTERVAL;
}
else
{
  if (CURRENT_REFRESH_INTERVAL != Defs.STANDARD_REFRESH_INTERVAL)
  {
	CURRENT_REFRESH_INTERVAL = Defs.STANDARD_REFRESH_INTERVAL;
	refreshTimer.scheduleRepeating(CURRENT_REFRESH_INTERVAL);
	systemStatusPanel.refreshTimeIntervalInfos(this);
  }
  else refreshTimer.scheduleRepeating(CURRENT_REFRESH_INTERVAL);
//  CURRENT_REFRESH_INTERVAL = Defs.STANDARD_REFRESH_INTERVAL;
}




//refreshTimer.scheduleRepeating(CURRENT_REFRESH_INTERVAL);
//systemStatusPanel.refreshInfos(this);
//lastUpdatedLabel.setText("(Update rate : " + CURRENT_REFRESH_INTERVAL/1000 + " seconds) Last update : " + DateTimeFormat.getMediumDateTimeFormat().format(new Date()) + " from data source : " + JSON_URL);

//fileParsingCommand = "";
}

showHeartBeatLabel();
}




private void buildTreeNodeDisplay(LogMessage message, TreeItem item)
{

	DiagTreeItem lclItem = (DiagTreeItem)item;
	if ( message.getLevel().equals("TRACE") ) lclItem.setTraceCounter(lclItem.getTraceCounter() + 1);
	if ( message.getLevel().equals("DEBUG") ) lclItem.setDebugCounter(lclItem.getDebugCounter() + 1);
	if ( message.getLevel().equals("INFO") ) lclItem.setInfoCounter(lclItem.getInfoCounter() + 1);
	if ( message.getLevel().equals("WARN") ) lclItem.setWarnCounter(lclItem.getWarnCounter() + 1);
	if ( message.getLevel().equals("USERINFO") ) lclItem.setUserinfoCounter(lclItem.getUserinfoCounter() + 1);
	if ( message.getLevel().equals("ERROR") ) lclItem.setErrorCounter(lclItem.getErrorCounter() + 1);
	if ( message.getLevel().equals("FATAL") ) lclItem.setFatalCounter(lclItem.getFatalCounter() + 1);


String warnDisplayModeBegin = "";
String warnDisplayModeEnd = "";
String userinfoDisplayModeBegin = "";
String userinfoDisplayModeEnd = "";
String errorDisplayModeBegin = "";
String errorDisplayModeEnd = "";
String fatalDisplayModeBegin = "";
String fatalDisplayModeEnd = "";
if (lclItem.getWarnCounter() > 0)
{
	warnDisplayModeBegin = "<span style=\"color: rgb(255, 204, 51);\">" + "<b>";
	warnDisplayModeEnd = "</b></span>";
}
if (lclItem.getUserinfoCounter() > 0)
{
	userinfoDisplayModeBegin = "<span style=\"color: rgb(102, 255, 153);\">" + "<b>";
	userinfoDisplayModeEnd = "</b></span>";
}
if (lclItem.getErrorCounter() > 0)
{
	errorDisplayModeBegin = "<span style=\"color: rgb(255, 0, 0);\">" + "<b>";
	errorDisplayModeEnd = "</b></span>";
}
if (lclItem.getFatalCounter() > 0)
{
	fatalDisplayModeBegin = "<span style=\"color: rgb(153, 51, 153);\">" + "<b>";
	fatalDisplayModeEnd = "</b></span>";
}

    lclItem.setHTML(lclItem.getTreeItemName() 	+ " -- " + "T:" + lclItem.getTraceCounter() 
												+ " D:"	+ lclItem.getDebugCounter()
												+ " I:"	+ lclItem.getInfoCounter()
												+ warnDisplayModeBegin + " W:" + lclItem.getWarnCounter() + warnDisplayModeEnd
												+ userinfoDisplayModeBegin + " U:"	+ lclItem.getUserinfoCounter() + userinfoDisplayModeEnd
												+ errorDisplayModeBegin + " E:"	+ lclItem.getErrorCounter() + errorDisplayModeEnd
												+ fatalDisplayModeBegin + " F:"	+ lclItem.getFatalCounter() + fatalDisplayModeEnd);
}



private void buildNamedTreeNodeDisplay(LogMessage message, TreeItem item, String nodeName)
{

	DiagTreeItem lclItem = (DiagTreeItem)item;
	if ( message.getLevel().equals("TRACE") ) lclItem.setTraceCounter(lclItem.getTraceCounter() + 1);
	if ( message.getLevel().equals("DEBUG") ) lclItem.setDebugCounter(lclItem.getDebugCounter() + 1);
	if ( message.getLevel().equals("INFO") ) lclItem.setInfoCounter(lclItem.getInfoCounter() + 1);
	if ( message.getLevel().equals("WARN") ) lclItem.setWarnCounter(lclItem.getWarnCounter() + 1);
	if ( message.getLevel().equals("USERINFO") ) lclItem.setUserinfoCounter(lclItem.getUserinfoCounter() + 1);
	if ( message.getLevel().equals("ERROR") ) lclItem.setErrorCounter(lclItem.getErrorCounter() + 1);
	if ( message.getLevel().equals("FATAL") ) lclItem.setFatalCounter(lclItem.getFatalCounter() + 1);

String warnDisplayModeBegin = "";
String warnDisplayModeEnd = "";
String userinfoDisplayModeBegin = "";
String userinfoDisplayModeEnd = "";
String errorDisplayModeBegin = "";
String errorDisplayModeEnd = "";
String fatalDisplayModeBegin = "";
String fatalDisplayModeEnd = "";
if (lclItem.getWarnCounter() > 0)
{
	warnDisplayModeBegin = "<span style=\"color: rgb(255, 204, 51);\">" + "<b>";
	warnDisplayModeEnd = "</b></span>";
}
if (lclItem.getUserinfoCounter() > 0)
{
	userinfoDisplayModeBegin = "<span style=\"color: rgb(102, 255, 153);\">" + "<b>";
	userinfoDisplayModeEnd = "</b></span>";
}
if (lclItem.getErrorCounter() > 0)
{
	errorDisplayModeBegin = "<span style=\"color: rgb(255, 0, 0);\">" + "<b>";
	errorDisplayModeEnd = "</b></span>";
}
if (lclItem.getFatalCounter() > 0)
{
	fatalDisplayModeBegin = "<span style=\"color: rgb(153, 51, 153);\">" + "<b>";
	fatalDisplayModeEnd = "</b></span>";
}

    lclItem.setHTML(nodeName + " -- " + "T:" + lclItem.getTraceCounter() 
												+ " D:"	+ lclItem.getDebugCounter()
												+ " I:"	+ lclItem.getInfoCounter()
												+ warnDisplayModeBegin + " W:" + lclItem.getWarnCounter() + warnDisplayModeEnd
												+ userinfoDisplayModeBegin + " U:"	+ lclItem.getUserinfoCounter() + userinfoDisplayModeEnd
												+ errorDisplayModeBegin + " E:"	+ lclItem.getErrorCounter() + errorDisplayModeEnd
												+ fatalDisplayModeBegin + " F:"	+ lclItem.getFatalCounter() + fatalDisplayModeEnd);

}


















private void buildHardwareTreeNodeDisplay(LogMessage message, DiagTreeHardwareItem item)
{

	
	if ( message.getLevel().equals("TRACE") ) item.setTraceCounter(item.getTraceCounter() + 1);
	if ( message.getLevel().equals("DEBUG") ) item.setDebugCounter(item.getDebugCounter() + 1);
	if ( message.getLevel().equals("INFO") ) item.setInfoCounter(item.getInfoCounter() + 1);
	if ( message.getLevel().equals("WARN") ) item.setWarnCounter(item.getWarnCounter() + 1);
	if ( message.getLevel().equals("USERINFO") ) item.setUserinfoCounter(item.getUserinfoCounter() + 1);
	if ( message.getLevel().equals("ERROR") ) item.setErrorCounter(item.getErrorCounter() + 1);
	if ( message.getLevel().equals("FATAL") ) item.setFatalCounter(item.getFatalCounter() + 1);


String warnDisplayModeBegin = "";
String warnDisplayModeEnd = "";
String userinfoDisplayModeBegin = "";
String userinfoDisplayModeEnd = "";
String errorDisplayModeBegin = "";
String errorDisplayModeEnd = "";
String fatalDisplayModeBegin = "";
String fatalDisplayModeEnd = "";
if (item.getWarnCounter() > 0)
{
	warnDisplayModeBegin = "<span style=\"color: rgb(255, 204, 51);\">" + "<b>";
	warnDisplayModeEnd = "</b></span>";
}
if (item.getUserinfoCounter() > 0)
{
	userinfoDisplayModeBegin = "<span style=\"color: rgb(102, 255, 153);\">" + "<b>";
	userinfoDisplayModeEnd = "</b></span>";
}
if (item.getErrorCounter() > 0)
{
	errorDisplayModeBegin = "<span style=\"color: rgb(255, 0, 0);\">" + "<b>";
	errorDisplayModeEnd = "</b></span>";
}
if (item.getFatalCounter() > 0)
{
	fatalDisplayModeBegin = "<span style=\"color: rgb(153, 51, 153);\">" + "<b>";
	fatalDisplayModeEnd = "</b></span>";
}

    item.setHTML(item.getTreeItemName() 	+ " -- " + "T:" + item.getTraceCounter() 
												+ " D:"	+ item.getDebugCounter()
												+ " I:"	+ item.getInfoCounter()
												+ warnDisplayModeBegin + " W:" + item.getWarnCounter() + warnDisplayModeEnd
												+ userinfoDisplayModeBegin + " U:"	+ item.getUserinfoCounter() + userinfoDisplayModeEnd
												+ errorDisplayModeBegin + " E:"	+ item.getErrorCounter() + errorDisplayModeEnd
												+ fatalDisplayModeBegin + " F:"	+ item.getFatalCounter() + fatalDisplayModeEnd);
}










private void buildHardwareTreeTerminalNodeDisplay(LogMessage message, DiagTreeHardwareItem item)
{


String DisplayModeBegin = "";
String DisplayModeEnd = "";

if ( message.getLevel().equals("WARN") )
{
	DisplayModeBegin = "<span style=\"color: rgb(255, 204, 51);\">" + "<b>";
	DisplayModeEnd = "</b></span>";
}
if ( message.getLevel().equals("USERINFO") )
{
	DisplayModeBegin = "<span style=\"color: rgb(102, 255, 153);\">" + "<b>";
	DisplayModeEnd = "</b></span>";
}
if ( message.getLevel().equals("ERROR") )
{
	DisplayModeBegin = "<span style=\"color: rgb(255, 0, 0);\">" + "<b>";
	DisplayModeEnd = "</b></span>";
}
if ( message.getLevel().equals("FATAL") )
{
	DisplayModeBegin = "<span style=\"color: rgb(153, 51, 153);\">" + "<b>";
	DisplayModeEnd = "</b></span>";
}


item.setHTML(" | " + DisplayModeBegin + "Code : " + message.getErrCode() + DisplayModeEnd + " | " + " Occurences : " + item.getOccurenceCounter() + " | " + item.getErrorCodeAssociatedMessage() );

}




private void handleHardwareMessages(LogMessage message, DiagTreeHardwareItem terminalItem)
{
	boolean currentErrCodeFound = false;
	for (int i=0; i<terminalItem.getChildCount(); i++)
	{
		DiagTreeHardwareItem itemI = (DiagTreeHardwareItem)terminalItem.getChild(i);
		if ( itemI.getErrorCode().equals(message.getErrCode()) )
		{
			currentErrCodeFound = true;
			itemI.incrementOccurenceCounter();
			//itemI.setHTML(" Errcode : " + message.getErrCode() + " | " + " Occurences : " + itemI.getOccurenceCounter() + " | " + itemI.getErrorCodeAssociatedMessage() );
			buildHardwareTreeTerminalNodeDisplay(message, itemI);
		}
	}
	if (currentErrCodeFound == false)
	{
		DiagTreeHardwareItem errorCodeItem = new DiagTreeHardwareItem("ErrCode " + message.getErrCode());
		errorCodeItem.incrementOccurenceCounter();
		errorCodeItem.setErrorCodeAssociatedMessage(message.getMessage());
		errorCodeItem.setErrorCode(message.getErrCode());
		//errorCodeItem.setHTML(" Errcode : " + message.getErrCode() + " | " + " Occurences : " + errorCodeItem.getOccurenceCounter() + " | " + errorCodeItem.getErrorCodeAssociatedMessage() );
		buildHardwareTreeTerminalNodeDisplay(message, errorCodeItem);
		terminalItem.addItem(errorCodeItem);
	}
}









private int updateTable(LogMessage message) {
  



  FlexTable.FlexCellFormatter cf = ft.getFlexCellFormatter();


numberOfLogsInTable++;
if (numberOfLogsInTable > MAX_NUMBER_OF_LOGS_IN_TABLE)
{
int rowToRemove = ft.getRowCount();
	ft.removeRow(rowToRemove-1);
numberOfLogsInTable--;
}


//  int row = ft.getRowCount();
    int row = ft.insertRow(Defs.HEADER_ROW + 1);
  
  
  // update the watch list with the new values
  ft.setText(row, Defs.LEVEL_COL, message.getLevel());
  cf.setWordWrap(row, Defs.LEVEL_COL, false);



  String hexString = Integer.toHexString((int) Integer.valueOf(message.getErrCode()));
  String decString = Integer.toString((int) Integer.valueOf(message.getErrCode()));
  String errCodeString = "(Dec:)" + decString + " -- (Hex)" + hexString;
  ft.setText(row, Defs.ERRCODE_COL, errCodeString);
  cf.setWordWrap(row, Defs.ERRCODE_COL, false);

  ft.setText(row, Defs.MSG_COL, message.getMessage());
  cf.setWordWrap(row, Defs.MSG_COL, false);

  ft.setText(row, Defs.TS_COL, message.getTimestamp());
  cf.setWordWrap(row, Defs.TS_COL, false);




String extendedSource = message.getSource();
//Format getNestedClassPath name for futur tree-like display
if ( (message.getNestedClassPath().equals("")) || (message.getNestedClassPath().equals("NA")) || (message.getNestedClassPath().equals("SELF")) )
{
	message.setNestedClassPath("SELF");
}

//if ( (message.getNestedClassPath() != "") && (message.getNestedClassPath() != "NA") )
//{
	if (message.getNestedClassPath().equals("SELF"))
	{
	}
	else
	{
		extendedSource = extendedSource + "." + message.getNestedClassPath();
	}

//	if ( (message.getNestedFileName() != "") && (message.getNestedFileName() != "NA") )
	if ( (message.getNestedFileName().equals("")) || (message.getNestedFileName().equals("NA")) )
	{
	}
	else
	{
		extendedSource = extendedSource + "(SourceFile:" + message.getNestedFileName() + ")";
//		if ( (message.getNestedLineNumber() != "") && (message.getNestedLineNumber() != "NA") && (message.getNestedLineNumber() != "0") )
		if ( (message.getNestedLineNumber().equals("")) || (message.getNestedLineNumber().equals("NA")) || (message.getNestedLineNumber().equals("0")) )
		{
		}
		else
		{
			extendedSource = extendedSource + "(LineNumber:" + message.getNestedLineNumber() + ")";
		}
	}
//}

/*
  ft.setText(row, Defs.SOURCE_COL, message.getSource());
  cf.setWordWrap(row, Defs.SOURCE_COL, false);
*/
  ft.setText(row, Defs.SOURCE_COL, extendedSource);
  cf.setWordWrap(row, Defs.SOURCE_COL, false);



  ft.setText(row, Defs.SYSID_COL, message.getSystemId());
  cf.setWordWrap(row, Defs.SYSID_COL, false);

  ft.setText(row, Defs.SUBSYSID_COL, message.getSubSystemId());
  cf.setWordWrap(row, Defs.SUBSYSID_COL, false);



  ft.setText(row, Defs.XTRABUFF_COL, message.getExtraBuffer());
  cf.setWordWrap(row, Defs.XTRABUFF_COL, false);

/*

String cated = "fechardid=" + message.getFecHardId() + " -- ";
cated = cated + "ring=" + message.getRing() + " -- ";
cated = cated + "ccu=" + message.getCcu() + " -- ";
cated = cated + "i2cchannel=" + message.getI2cChannel() + " -- ";
cated = cated + "i2caddress=" + message.getI2cAddress() + " -- ";
cated = cated + "fedid=" + message.getFedId() + " -- ";
cated = cated + "fedchannel=" + message.getFedChannel() + " -- ";
cated = cated + "crate=" + message.getCrate() + " -- ";
cated = cated + "slot=" + message.getSlot() + " -- ";
cated = cated + "nestedclasspath=" + message.getNestedClassPath() + " -- ";
cated = cated + "nestedfilename=" + message.getNestedFileName() + " -- ";
cated = cated + "nestedlinenumber=" + message.getNestedLineNumber() + " -- ";

  ft.setText(row, Defs.XTRABUFF_COL, cated);
//  cf.setWordWrap(row, Defs.XTRABUFF_COL, false);
*/

  ft.setText(row, Defs.MACHINE_COL, message.getMachine());
  cf.setWordWrap(row, Defs.MACHINE_COL, false);

  ft.setText(row, Defs.PORT_COL, message.getPort());
  cf.setWordWrap(row, Defs.PORT_COL, false);

  ft.setText(row, Defs.PROCNAME_COL, message.getProcName());
  cf.setWordWrap(row, Defs.PROCNAME_COL, false);

  ft.setText(row, Defs.PROCINST_COL, message.getProcInstance());
  cf.setWordWrap(row, Defs.PROCINST_COL, false);

  ft.setText(row, Defs.LOGNUM_COL, message.getLogNumber());
  cf.setWordWrap(row, Defs.LOGNUM_COL, false);




if (!((message.getFecHardId().equals("")) || (message.getFecHardId().equals("NA"))))
{
	message.setHwType("FEC");
	//Window.alert("Got a FEC message where FecHardId = " + message.getFecHardId());
}
else
{
	if (!((message.getFedId().equals("")) || (message.getFedId().equals("NA"))))
	{
		message.setHwType("FED");
		//Window.alert("Got a FED message");
	}
	else
	{
		message.setHwType("SOFT");
		//Window.alert("Got a SOFT message");
	}
}





  hideShowOneRowWithCriticity(row, ft.getText(row, Defs.LEVEL_COL), message);
  hideShowOneElementInColumn(row);





  //Now take care of the tracker items tree

//Create the tree items related to the message, they will be necessary if the node(s) does not exists


//Create hardWareType level item
boolean detectorExists = false;
DiagTreeHardwareItem detectorItem;
detectorExists = true;
detectorItem = new DiagTreeHardwareItem(Defs.HARDWARE_SUBDETECTOR_NAME);
detectorItem.setNodeProperties( Defs.HARDWARE_SUBDETECTOR_NAME );



//Create hardWareType level item
boolean hwtypeExists = false;
DiagTreeHardwareItem hwtypeItem = new DiagTreeHardwareItem(message.getHwType());
if (!( (message.getHwType().equals("")) || (message.getHwType().equals("NA")) ))
{
	hwtypeExists = true;
//	hwtypeItem = new DiagTreeHardwareItem(message.getHwType());
	hwtypeItem.setNodeProperties(	Defs.HARDWARE_SUBDETECTOR_NAME,
						message.getHwType());
}



//Create crate level item
boolean crateExists = false;
DiagTreeHardwareItem crateItem = new DiagTreeHardwareItem(Defs.CRATE_PREFIX + message.getCrate());
if (!( (message.getCrate().equals("")) || (message.getCrate().equals("NA")) ))
{
	crateExists = true;
//	crateItem = new DiagTreeHardwareItem(message.getCrate());
	crateItem.setNodeProperties(	Defs.HARDWARE_SUBDETECTOR_NAME,
						message.getHwType(),
						message.getCrate());
}


//Create slot level item
boolean slotExists = false;
DiagTreeHardwareItem slotItem = new DiagTreeHardwareItem(Defs.SLOT_PREFIX + message.getSlot());
if (!( (message.getSlot().equals("")) || (message.getSlot().equals("NA")) ))
{
	slotExists = true;
//	slotItem = new DiagTreeHardwareItem(message.getSlot());
	slotItem.setNodeProperties(	Defs.HARDWARE_SUBDETECTOR_NAME,
						message.getHwType(),
						message.getCrate(),
						message.getSlot());
}


//Create ring level item
boolean ringExists = false;
DiagTreeHardwareItem ringItem = new DiagTreeHardwareItem(Defs.RING_PREFIX + message.getRing());
if (!( (message.getRing().equals("")) || (message.getRing().equals("NA")) ))
{
	ringExists = true;
//	ringItem = new DiagTreeHardwareItem(message.getRing());
	ringItem.setNodeProperties(	Defs.HARDWARE_SUBDETECTOR_NAME,
						message.getHwType(),
						message.getCrate(),
						message.getSlot(),
						message.getRing());
}




//FED channel level item
boolean fedchannelExists = false;
DiagTreeHardwareItem fedchannelItem = new DiagTreeHardwareItem(Defs.FEDCHANNEL_PREFIX + message.getFedChannel());
if (!( (message.getFedChannel().equals("")) || (message.getFedChannel().equals("NA")) ))
{
	fedchannelExists = true;
//	ringItem = new DiagTreeHardwareItem(message.getRing());
	fedchannelItem.setNodeProperties(	Defs.HARDWARE_SUBDETECTOR_NAME,
						message.getHwType(),
						message.getCrate(),
						message.getSlot(),
						message.getFedChannel());
}


//Create ccu level item
boolean ccuExists = false;
DiagTreeHardwareItem ccuItem = new DiagTreeHardwareItem(Defs.CCU_PREFIX + message.getCcu());
if (!( (message.getCcu().equals("")) || (message.getCcu().equals("NA")) ))
{
	ccuExists = true;
//	ccuItem = new DiagTreeHardwareItem(message.getCcu());
	ccuItem.setNodeProperties(	Defs.HARDWARE_SUBDETECTOR_NAME,
						message.getHwType(),
						message.getCrate(),
						message.getSlot(),
						message.getRing(),
						message.getCcu());
}


//Create i2cchannel level item
boolean i2cChannelExists = false;
DiagTreeHardwareItem i2cChannelItem = new DiagTreeHardwareItem(Defs.I2CCHANNEL_PREFIX + message.getI2cChannel());
if (!( (message.getI2cChannel().equals("")) || (message.getI2cChannel().equals("NA")) ))
{
	i2cChannelExists = true;
//	i2cChannelItem = new DiagTreeHardwareItem(message.getI2cChannel());
	i2cChannelItem.setNodeProperties(	Defs.HARDWARE_SUBDETECTOR_NAME,
						message.getHwType(),
						message.getCrate(),
						message.getSlot(),
						message.getRing(),
						message.getCcu(),
						message.getI2cChannel());
}

//Create i2caddress level item
boolean i2cAddressExists = false;
DiagTreeHardwareItem i2cAddressItem = new DiagTreeHardwareItem(Defs.I2CADDRESS_PREFIX + message.getI2cAddress());
if (!( (message.getI2cAddress().equals("")) || (message.getI2cAddress().equals("NA")) ))
{
	i2cAddressExists = true;
//	i2cAddressItem = new DiagTreeHardwareItem(message.getI2cAddress());
	i2cAddressItem.setNodeProperties(	Defs.HARDWARE_SUBDETECTOR_NAME,
						message.getHwType(),
						message.getCrate(),
						message.getSlot(),
						message.getRing(),
						message.getCcu(),
						message.getI2cChannel(),
						message.getI2cAddress());
}







//Beging FEC hardware case
if ( (hwtypeExists == true) && (message.getHwType().equals("FEC")) )
{

///////////////////////////////////////////////////////////////////////   DETECTOR BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

//first treeItem is Detector
boolean detectorFound = false;
for (int i=0; i<hardwareErrorsTree.getItemCount(); i++)
{
	DiagTreeHardwareItem itemI = (DiagTreeHardwareItem)hardwareErrorsTree.getItem(i);
	if ( itemI.treeItemName.equals(Defs.HARDWARE_SUBDETECTOR_NAME) )
	{
	detectorFound = true;
	buildHardwareTreeNodeDisplay(message, itemI);
	if (hwtypeExists == false) {handleHardwareMessages(message, itemI);}

///////////////////////////////////////////////////////////////////////   HWTYPE BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

		//Si on a trouve la sous-branche Detector, on parse la branche hardwaretype
		boolean hwtypeFound = false;
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeHardwareItem itemJ = (DiagTreeHardwareItem)itemI.getChild(j);
			if ( itemJ.treeItemName.equals(message.getHwType()) )			{
				hwtypeFound = true;
				buildHardwareTreeNodeDisplay(message, itemJ);
				if (crateExists == false) {handleHardwareMessages(message, itemJ);}

///////////////////////////////////////////////////////////////////////   CRATE BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

				//Si on a trouve la sous-branche hardwaretype, on parse la branche crate
				boolean crateFound = false;
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeHardwareItem itemK = (DiagTreeHardwareItem)itemJ.getChild(k);
					if ( itemK.treeItemName.equals(Defs.CRATE_PREFIX + message.getCrate()) )
					{
						crateFound = true;
						buildHardwareTreeNodeDisplay(message, itemK);
						if (slotExists == false) {handleHardwareMessages(message, itemK);}

///////////////////////////////////////////////////////////////////////   SLOT BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

						//Si on a trouve la sous-branche crate, on parse la branche slot
						boolean slotFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeHardwareItem itemL = (DiagTreeHardwareItem)itemK.getChild(l);
							if ( itemL.treeItemName.equals(Defs.SLOT_PREFIX + message.getSlot()) )
							{
								slotFound = true;
								buildHardwareTreeNodeDisplay(message, itemL);
								if (ringExists == false) {handleHardwareMessages(message, itemL);}

///////////////////////////////////////////////////////////////////////   RING BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

								//Si on a trouve la sous-branche slot, on parse la branche ring
								boolean ringFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeHardwareItem itemM = (DiagTreeHardwareItem)itemL.getChild(m);
									if (itemM.treeItemName.equals(Defs.RING_PREFIX + message.getRing()) )
									{
										ringFound = true;
										buildHardwareTreeNodeDisplay(message, itemM);
										if (ccuExists == false) {handleHardwareMessages(message, itemM);}
										
										
///////////////////////////////////////////////////////////////////////   CCU BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

										//Si on a trouve la sous-branche ring, on parse la branche ccu
										boolean ccuFound = false;
										for (int n=0; n<itemM.getChildCount(); n++)
										{
											DiagTreeHardwareItem itemN = (DiagTreeHardwareItem)itemM.getChild(n);
											if (itemN.treeItemName.equals(Defs.CCU_PREFIX + message.getCcu()) )
											{
												ccuFound = true;
												buildHardwareTreeNodeDisplay(message, itemN);
												if (i2cChannelExists == false) {handleHardwareMessages(message, itemN);}

///////////////////////////////////////////////////////////////////////   I2C CHANNEL BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

												//Si on a trouve la sous-branche ccu, on parse la branche i2cchannel
												boolean i2cchannelFound = false;
												for (int o=0; o<itemN.getChildCount(); o++)
												{
													DiagTreeHardwareItem itemO = (DiagTreeHardwareItem)itemN.getChild(o);
													if (itemO.treeItemName.equals(Defs.I2CCHANNEL_PREFIX + message.getI2cChannel()) )
													{
														i2cchannelFound = true;
														buildHardwareTreeNodeDisplay(message, itemO);
														if (i2cAddressExists == false) {handleHardwareMessages(message, itemO);}

///////////////////////////////////////////////////////////////////////   I2C ADDRESS BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////
														//Si on a trouve la sous-branche i2cchannel, on parse la branchei2caddress
														boolean i2caddressFound = false;
														for (int p=0; p<itemO.getChildCount(); p++)
														{
															DiagTreeHardwareItem itemP = (DiagTreeHardwareItem)itemO.getChild(p);
															if (itemP.treeItemName.equals(Defs.I2CADDRESS_PREFIX + message.getI2cAddress()) )
															{
																i2caddressFound = true;
																buildHardwareTreeNodeDisplay(message, itemP);
																handleHardwareMessages(message, itemP);
															}
														}

														//Si on n'a pas trouve la branche i2caddress, on la rajoute
														if (i2caddressFound == false)
														{
															boolean msgAdded = false;
															if (i2cAddressExists == true)
															{
																handleHardwareMessages(message, i2cAddressItem); msgAdded = true;
																itemO.addItem(i2cAddressItem);
																buildHardwareTreeNodeDisplay(message, i2cAddressItem);
															}
														}
/////////////////////////////////////////////////////////////////////////   END OF I2C ADDRESS BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

													}
												}
												//Si on n'a pas trouve la branche i2cchannel, on la rajoute
												if (i2cchannelFound == false)
												{
													boolean msgAdded = false;
													if (i2cChannelExists == true)
													{
														if (i2cAddressExists == true)
														{
															handleHardwareMessages(message, i2cAddressItem); msgAdded = true;
															i2cChannelItem.addItem(i2cAddressItem);
															buildHardwareTreeNodeDisplay(message, i2cAddressItem);
														}
														if (msgAdded == false) { handleHardwareMessages(message, i2cChannelItem); msgAdded = true; }
														itemN.addItem(i2cChannelItem);
														buildHardwareTreeNodeDisplay(message, i2cChannelItem);
													}
												}

///////////////////////////////////////////////////////////////////////   END OF I2C CHANNEL BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

												
												
											}
										}
										//Si on n'a pas trouve la branche ccu, on la rajoute
										if (ccuFound == false)
										{
											boolean msgAdded = false;
											if (ccuExists == true)
											{
												if (i2cChannelExists == true)
												{
													if (i2cAddressExists == true)
													{
														handleHardwareMessages(message, i2cAddressItem); msgAdded = true;
														i2cChannelItem.addItem(i2cAddressItem);
														buildHardwareTreeNodeDisplay(message, i2cAddressItem);
													}
													if (msgAdded == false) { handleHardwareMessages(message, i2cChannelItem); msgAdded = true; }
													ccuItem.addItem(i2cChannelItem);
													buildHardwareTreeNodeDisplay(message, i2cChannelItem);
												}
												if (msgAdded == false) { handleHardwareMessages(message, ccuItem); msgAdded = true; }
												itemM.addItem(ccuItem);
												buildHardwareTreeNodeDisplay(message, ccuItem);
											}
										}

///////////////////////////////////////////////////////////////////////   END OF CCU BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

										
									}
								}
								//Si on n'a pas trouve la branche ring, on la rajoute
								if (ringFound == false)
								{
									boolean msgAdded = false;
									if (ringExists == true)
									{
										if (ccuExists == true)
										{
											if (i2cChannelExists == true)
											{
												if (i2cAddressExists == true)
												{
													handleHardwareMessages(message, i2cAddressItem); msgAdded = true;
													i2cChannelItem.addItem(i2cAddressItem);
													buildHardwareTreeNodeDisplay(message, i2cAddressItem);
												}
												if (msgAdded == false) { handleHardwareMessages(message, i2cChannelItem); msgAdded = true; }
												ccuItem.addItem(i2cChannelItem);
												buildHardwareTreeNodeDisplay(message, i2cChannelItem);
											}
											if (msgAdded == false) { handleHardwareMessages(message, ccuItem); msgAdded = true; }
											ringItem.addItem(ccuItem);
											buildHardwareTreeNodeDisplay(message, ccuItem);
										}
										if (msgAdded == false) { handleHardwareMessages(message, ringItem); msgAdded = true; }
										itemL.addItem(ringItem);
										buildHardwareTreeNodeDisplay(message, ringItem);
									}
								}

///////////////////////////////////////////////////////////////////////   END OF RING BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////





							}
						}
						//Si on n'a pas trouve la branche slot, on la rajoute
						if (slotFound == false)
						{
							boolean msgAdded = false;
							if (slotExists == true)
							{

								if (ringExists == true)
								{
									if (ccuExists == true)
									{
										if (i2cChannelExists == true)
										{
											if (i2cAddressExists == true)
											{
												handleHardwareMessages(message, i2cAddressItem); msgAdded = true;
												i2cChannelItem.addItem(i2cAddressItem);
												buildHardwareTreeNodeDisplay(message, i2cAddressItem);
											}
											if (msgAdded == false) { handleHardwareMessages(message, i2cChannelItem); msgAdded = true; }
											ccuItem.addItem(i2cChannelItem);
											buildHardwareTreeNodeDisplay(message, i2cChannelItem);
										}
										if (msgAdded == false) { handleHardwareMessages(message, ccuItem); msgAdded = true; }
										ringItem.addItem(ccuItem);
										buildHardwareTreeNodeDisplay(message, ccuItem);
									}
									if (msgAdded == false) { handleHardwareMessages(message, ringItem); msgAdded = true; }
									slotItem.addItem(ringItem);
									buildHardwareTreeNodeDisplay(message, ringItem);
								}
								if (msgAdded == false) { handleHardwareMessages(message, slotItem); msgAdded = true; }
								itemK.addItem(slotItem);
								buildHardwareTreeNodeDisplay(message, slotItem);
							}
						}

///////////////////////////////////////////////////////////////////////   END OF SLOT BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////


					}
					
				}
				//Si on n'a pas trouve la branche crate, on la rajoute
				if (crateFound == false)
				{
					boolean msgAdded = false;
					if (crateExists == true)
					{

						if (slotExists == true)
						{
							if (ringExists == true)
							{
								if (ccuExists == true)
								{
									if (i2cChannelExists == true)
									{
										if (i2cAddressExists == true)
										{
											handleHardwareMessages(message, i2cAddressItem); msgAdded = true;
											i2cChannelItem.addItem(i2cAddressItem);
											buildHardwareTreeNodeDisplay(message, i2cAddressItem);
										}
										if (msgAdded == false) { handleHardwareMessages(message, i2cChannelItem); msgAdded = true; }
										ccuItem.addItem(i2cChannelItem);
										buildHardwareTreeNodeDisplay(message, i2cChannelItem);
									}
									if (msgAdded == false) { handleHardwareMessages(message, ccuItem); msgAdded = true; }
									ringItem.addItem(ccuItem);
									buildHardwareTreeNodeDisplay(message, ccuItem);
								}
								if (msgAdded == false) { handleHardwareMessages(message, ringItem); msgAdded = true; }
								slotItem.addItem(ringItem);
								buildHardwareTreeNodeDisplay(message, ringItem);
							}
							if (msgAdded == false) { handleHardwareMessages(message, slotItem); msgAdded = true; }
							crateItem.addItem(slotItem);
							buildHardwareTreeNodeDisplay(message, slotItem);
						}
						if (msgAdded == false) { handleHardwareMessages(message, crateItem); msgAdded = true; }
						itemJ.addItem(crateItem);
						buildHardwareTreeNodeDisplay(message, crateItem);
					}
				}

///////////////////////////////////////////////////////////////////////   END OF CRATE BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

				//break;
			}

		}
		//Si on n'a pas trouve la branche hardware type, on la rajoute
		if (hwtypeFound == false)
		{
			boolean msgAdded = false;
			if (hwtypeExists == true)
			{
				if (crateExists == true)
				{
					if (slotExists == true)
					{
						if (ringExists == true)
						{
							if (ccuExists == true)
							{
								if (i2cChannelExists == true)
								{
									if (i2cAddressExists == true)
									{
										handleHardwareMessages(message, i2cAddressItem); msgAdded = true;
										i2cChannelItem.addItem(i2cAddressItem);
										buildHardwareTreeNodeDisplay(message, i2cAddressItem);
									}
									if (msgAdded == false) { handleHardwareMessages(message, i2cChannelItem); msgAdded = true; }
									ccuItem.addItem(i2cChannelItem);
									buildHardwareTreeNodeDisplay(message, i2cChannelItem);
								}
								if (msgAdded == false) { handleHardwareMessages(message, ccuItem); msgAdded = true; }
								ringItem.addItem(ccuItem);
								buildHardwareTreeNodeDisplay(message, ccuItem);
							}
							if (msgAdded == false) { handleHardwareMessages(message, ringItem); msgAdded = true; }
							slotItem.addItem(ringItem);
							buildHardwareTreeNodeDisplay(message, ringItem);
						}
						if (msgAdded == false) { handleHardwareMessages(message, slotItem); msgAdded = true; }
						crateItem.addItem(slotItem);
						buildHardwareTreeNodeDisplay(message, slotItem);
					}
					if (msgAdded == false) { handleHardwareMessages(message, crateItem); msgAdded = true; }
					hwtypeItem.addItem(crateItem);
					buildHardwareTreeNodeDisplay(message, crateItem);
				}
				if (msgAdded == false) { handleHardwareMessages(message, hwtypeItem); msgAdded = true; }
				itemI.addItem(hwtypeItem);
				buildHardwareTreeNodeDisplay(message, hwtypeItem);
			}
		}

///////////////////////////////////////////////////////////////////////   END OF HWTYPE BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////


		
		
	}//else Window.alert("Sub Detector " + errorsTree.getItem(i).getText() + " NOT found");

}
//Si on n'a pas trouve la branche detecteur, on la rajoute
if (detectorFound == false)
{
boolean msgAdded = false;
	if (detectorExists == true)
	{
		if (hwtypeExists == true)
		{
			if (crateExists == true)
			{
				if (slotExists == true)
				{
					if (ringExists == true)
					{
						if (ccuExists == true)
						{
							if (i2cChannelExists == true)
							{
								if (i2cAddressExists == true)
								{
									handleHardwareMessages(message, i2cAddressItem); msgAdded = true;
									i2cChannelItem.addItem(i2cAddressItem);
									//Window.alert("Added i2cAddressItem node : " + i2cAddressItem.treeItemName );
									//i2cAddressItem.addItem("LogNumber " + message.getLogNumber() + " : " + message.getMessage());
									//msgAdded = true;
									buildHardwareTreeNodeDisplay(message, i2cAddressItem);
								}
								if (msgAdded == false) { handleHardwareMessages(message, i2cChannelItem); msgAdded = true; }
								ccuItem.addItem(i2cChannelItem);
								//Window.alert("Added i2cChannelItem node : " + i2cChannelItem.treeItemName );
								//msgAdded = true;
								buildHardwareTreeNodeDisplay(message, i2cChannelItem);
							}
							if (msgAdded == false) { handleHardwareMessages(message, ccuItem); msgAdded = true; }
							ringItem.addItem(ccuItem);
							//Window.alert("Added ccuItem node : " + ccuItem.treeItemName );
							//msgAdded = true;
							buildHardwareTreeNodeDisplay(message, ccuItem);
						}
						if (msgAdded == false) { handleHardwareMessages(message, ringItem); msgAdded = true; }
						slotItem.addItem(ringItem);
						//Window.alert("Added ringItem node : " + ringItem.treeItemName );
						//msgAdded = true;
						buildHardwareTreeNodeDisplay(message, ringItem);

					}
					if (msgAdded == false) { handleHardwareMessages(message, slotItem); msgAdded = true; }
					crateItem.addItem(slotItem);
					//Window.alert("Added slotItem node : " + slotItem.treeItemName );
					//msgAdded = true;
					buildHardwareTreeNodeDisplay(message, slotItem);

				}
				if (msgAdded == false) { handleHardwareMessages(message, crateItem); msgAdded = true; }
				hwtypeItem.addItem(crateItem);
				//Window.alert("Added crateItem node : " + crateItem.treeItemName );
				//msgAdded = true;
				buildHardwareTreeNodeDisplay(message, crateItem);

			}
			if (msgAdded == false) { handleHardwareMessages(message, hwtypeItem); msgAdded = true; }
			detectorItem.addItem(hwtypeItem);
			//Window.alert("Added hwtypeItem node : " + hwtypeItem.treeItemName );
			//msgAdded = true;
			buildHardwareTreeNodeDisplay(message, hwtypeItem);
			
		}
		if (msgAdded == false) { handleHardwareMessages(message, detectorItem); msgAdded = true; }
		hardwareErrorsTree.addItem(detectorItem);
		//Window.alert("Added detectorItem node : " + detectorItem.treeItemName );
		//msgAdded = true;
		buildHardwareTreeNodeDisplay(message, detectorItem);
	}
}

///////////////////////////////////////////////////////////////////////   END OF DETECTOR BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

} //End of FEC hardware case











//Beging FED hardware case
if ( (hwtypeExists == true) && (message.getHwType().equals("FED")) )
{

///////////////////////////////////////////////////////////////////////   DETECTOR BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

//first treeItem is Detector
boolean detectorFound = false;
for (int i=0; i<hardwareErrorsTree.getItemCount(); i++)
{
	DiagTreeHardwareItem itemI = (DiagTreeHardwareItem)hardwareErrorsTree.getItem(i);
	if ( itemI.treeItemName.equals(Defs.HARDWARE_SUBDETECTOR_NAME) )
	{
	detectorFound = true;
	buildHardwareTreeNodeDisplay(message, itemI);
	if (hwtypeExists == false) {handleHardwareMessages(message, itemI);}

///////////////////////////////////////////////////////////////////////   HWTYPE BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

		//Si on a trouve la sous-branche Detector, on parse la branche hardwaretype
		boolean hwtypeFound = false;
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeHardwareItem itemJ = (DiagTreeHardwareItem)itemI.getChild(j);
			if ( itemJ.treeItemName.equals(message.getHwType()) )			{
				hwtypeFound = true;
				buildHardwareTreeNodeDisplay(message, itemJ);
				if (crateExists == false) {handleHardwareMessages(message, itemJ);}

///////////////////////////////////////////////////////////////////////   CRATE BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

				//Si on a trouve la sous-branche hardwaretype, on parse la branche crate
				boolean crateFound = false;
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeHardwareItem itemK = (DiagTreeHardwareItem)itemJ.getChild(k);
					if ( itemK.treeItemName.equals(Defs.CRATE_PREFIX + message.getCrate()) )
					{
						crateFound = true;
						buildHardwareTreeNodeDisplay(message, itemK);
						if (slotExists == false) {handleHardwareMessages(message, itemK);}

///////////////////////////////////////////////////////////////////////   SLOT BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

						//Si on a trouve la sous-branche crate, on parse la branche slot
						boolean slotFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeHardwareItem itemL = (DiagTreeHardwareItem)itemK.getChild(l);
							if ( itemL.treeItemName.equals(Defs.SLOT_PREFIX + message.getSlot()) )
							{
								slotFound = true;
								buildHardwareTreeNodeDisplay(message, itemL);
								if (fedchannelExists == false) {handleHardwareMessages(message, itemL);}

///////////////////////////////////////////////////////////////////////   CHANNEL BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

								//Si on a trouve la sous-branche slot, on parse la branche channel
								boolean fedchannelFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeHardwareItem itemM = (DiagTreeHardwareItem)itemL.getChild(m);
									if (itemM.treeItemName.equals(Defs.FEDCHANNEL_PREFIX + message.getFedChannel()) )
									{
										fedchannelFound = true;
										buildHardwareTreeNodeDisplay(message, itemM);
										handleHardwareMessages(message, itemM);

										
									}
								}								
								//Si on n'a pas trouve la branche channel, on la rajoute
								if (fedchannelFound == false)
								{
									boolean msgAdded = false;
									if (fedchannelExists == true)
									{
										handleHardwareMessages(message, fedchannelItem); msgAdded = true;
										itemL.addItem(fedchannelItem);
										buildHardwareTreeNodeDisplay(message, fedchannelItem);
									}
								}

///////////////////////////////////////////////////////////////////////   END OF CHANNEL BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////
							}
						}
						//Si on n'a pas trouve la branche slot, on la rajoute
						if (slotFound == false)
						{
							boolean msgAdded = false;
							if (slotExists == true)
							{
								if (fedchannelExists == true)
								{
									if (msgAdded == false) { handleHardwareMessages(message, fedchannelItem); msgAdded = true; }
									slotItem.addItem(fedchannelItem);
									buildHardwareTreeNodeDisplay(message, fedchannelItem);
								}
								if (msgAdded == false) { handleHardwareMessages(message, slotItem); msgAdded = true; }
								itemK.addItem(slotItem);
								buildHardwareTreeNodeDisplay(message, slotItem);
							}
						}

///////////////////////////////////////////////////////////////////////   END OF SLOT BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////


					}
					
				}
				//Si on n'a pas trouve la branche crate, on la rajoute
				if (crateFound == false)
				{
					boolean msgAdded = false;
					if (crateExists == true)
					{

						if (slotExists == true)
						{
							if (fedchannelExists == true);
							{
								if (msgAdded == false) { handleHardwareMessages(message, fedchannelItem); msgAdded = true; }
								slotItem.addItem(fedchannelItem);
								buildHardwareTreeNodeDisplay(message, fedchannelItem);
							}
							if (msgAdded == false) { handleHardwareMessages(message, slotItem); msgAdded = true; }
							crateItem.addItem(slotItem);
							buildHardwareTreeNodeDisplay(message, slotItem);
						}
						if (msgAdded == false) { handleHardwareMessages(message, crateItem); msgAdded = true; }
						itemJ.addItem(crateItem);
						buildHardwareTreeNodeDisplay(message, crateItem);
					}
				}

///////////////////////////////////////////////////////////////////////   END OF CRATE BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

				//break;
			}

		}
		//Si on n'a pas trouve la branche hardware type, on la rajoute
		if (hwtypeFound == false)
		{
			boolean msgAdded = false;
			if (hwtypeExists == true)
			{
				if (crateExists == true)
				{
					if (slotExists == true)
					{
						if (fedchannelExists == true);
						{
							if (msgAdded == false) { handleHardwareMessages(message, fedchannelItem); msgAdded = true; }
							slotItem.addItem(fedchannelItem);
							buildHardwareTreeNodeDisplay(message, fedchannelItem);
						}
						if (msgAdded == false) { handleHardwareMessages(message, slotItem); msgAdded = true; }
						crateItem.addItem(slotItem);
						buildHardwareTreeNodeDisplay(message, slotItem);
					}
					if (msgAdded == false) { handleHardwareMessages(message, crateItem); msgAdded = true; }
					hwtypeItem.addItem(crateItem);
					buildHardwareTreeNodeDisplay(message, crateItem);
				}
				if (msgAdded == false) { handleHardwareMessages(message, hwtypeItem); msgAdded = true; }
				itemI.addItem(hwtypeItem);
				buildHardwareTreeNodeDisplay(message, hwtypeItem);
			}
		}

///////////////////////////////////////////////////////////////////////   END OF HWTYPE BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////


		
		
	}//else Window.alert("Sub Detector " + errorsTree.getItem(i).getText() + " NOT found");

}
//Si on n'a pas trouve la branche detecteur, on la rajoute
if (detectorFound == false)
{
boolean msgAdded = false;
	if (detectorExists == true)
	{
		if (hwtypeExists == true)
		{
			if (crateExists == true)
			{
				if (slotExists == true)
				{
					if (fedchannelExists == true);
					{
						if (msgAdded == false) { handleHardwareMessages(message, fedchannelItem); msgAdded = true; }
						slotItem.addItem(fedchannelItem);
						buildHardwareTreeNodeDisplay(message, fedchannelItem);
					}
					if (msgAdded == false) { handleHardwareMessages(message, slotItem); msgAdded = true; }
					crateItem.addItem(slotItem);
					//Window.alert("Added slotItem node : " + slotItem.treeItemName );
					//msgAdded = true;
					buildHardwareTreeNodeDisplay(message, slotItem);

				}
				if (msgAdded == false) { handleHardwareMessages(message, crateItem); msgAdded = true; }
				hwtypeItem.addItem(crateItem);
				//Window.alert("Added crateItem node : " + crateItem.treeItemName );
				//msgAdded = true;
				buildHardwareTreeNodeDisplay(message, crateItem);

			}
			if (msgAdded == false) { handleHardwareMessages(message, hwtypeItem); msgAdded = true; }
			detectorItem.addItem(hwtypeItem);
			//Window.alert("Added hwtypeItem node : " + hwtypeItem.treeItemName );
			//msgAdded = true;
			buildHardwareTreeNodeDisplay(message, hwtypeItem);
			
		}
		if (msgAdded == false) { handleHardwareMessages(message, detectorItem); msgAdded = true; }
		hardwareErrorsTree.addItem(detectorItem);
		//Window.alert("Added detectorItem node : " + detectorItem.treeItemName );
		//msgAdded = true;
		buildHardwareTreeNodeDisplay(message, detectorItem);
	}
}

///////////////////////////////////////////////////////////////////////   END OF DETECTOR BLOCK   ////////////////////////////////////////////////////////////////////////////////////////////////////

} //End of FED hardware case












































//DEBUGME
//if ( message.getLevel().equals("FATAL") ) Window.alert("Now processing log FATAL at Tracker tree level");
  //Now take care of the tracker items tree

//first treeItem is tracker
boolean trackerFound = false;
for (int i=0; i<errorsTree.getItemCount(); i++)
{
//	if ( errorsTree.getItem(i).getText().equals(Defs.SUBDETECTOR_NAME) )

	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
	if ( itemI.treeItemName.equals(Defs.SUBDETECTOR_NAME) )
	{
	trackerFound = true;
	//Manage Tree Local counters
	buildTreeNodeDisplay(message, itemI);
	handleMessagesMaskingForIncomingLog(message, itemI);
												

		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		boolean machineFound = false;
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			if ( itemJ.treeItemName.equals(message.getMachine()) )			{
				machineFound = true;
				//Manage Tree Local counters
				buildTreeNodeDisplay(message, itemJ);
				handleMessagesMaskingForIncomingLog(message, itemJ);
//DEBUGME
//if ( message.getLevel().equals("FATAL") ) Window.alert("Machine found ; node.hideInLogsTable = " +  itemJ.hideInLogsTable + ", message.showInTable = " + message.showInTable);

				//....


				//Si on a trouve la sous-branche machine, on parse la branche port
				boolean portFound = false;
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					if ( itemK.treeItemName.equals(message.getPort()) )
					{
						portFound = true;

						//Manage Tree Local counters
						buildTreeNodeDisplay(message, itemK);
						handleMessagesMaskingForIncomingLog(message, itemK);
//DEBUGME
//if ( message.getLevel().equals("FATAL") ) Window.alert("Port found ; node.hideInLogsTable = " +  itemK.hideInLogsTable + ", message.showInTable = " + message.showInTable);





						//Si on a trouve la sous-branche port, on parse la branche procname
						boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							if ( itemL.treeItemName.equals(message.getProcName()) )
							{
								procnameFound = true;
								//Manage Tree Local counters
								buildTreeNodeDisplay(message, itemL);
								handleMessagesMaskingForIncomingLog(message, itemL);
//DEBUGME
//if ( message.getLevel().equals("FATAL") ) Window.alert("ProcName found ; node.hideInLogsTable = " +  itemL.hideInLogsTable + ", message.showInTable = " + message.showInTable);



								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									if (itemM.treeItemName.equals("Instance " + message.getProcInstance()) )
									{
										procinstanceFound = true;
										//Manage Tree Local counters
										buildTreeNodeDisplay(message,itemM);
										handleMessagesMaskingForIncomingLog(message, itemM);
//DEBUGME
//if ( message.getLevel().equals("FATAL") ) Window.alert("Instance found ; node.hideInLogsTable = " +  itemM.hideInLogsTable + ", message.showInTable = " + message.showInTable);





										//Arrived at the SubClasses branch, try to check how deep in the branch we have to go
										//Don't dig the hierarchy for top level process (SELF and NA)
										String subClassPath = message.getNestedClassPath();
										String regex = ":";
										//if (subClassPath.equals("SELF")
										subClassesList = subClassPath.split(regex);
										//Window.alert("SubClass is composed of " + subClassesList.length + " sub pathes");
										//Window.alert("String 0 = " + subClassesList[0]);
										currentSubClassesToProcessInTree = subClassesList.length;
										if (subClassesList[0].equals("SELF")) currentSubClassesToProcessInTree = 0;

										

										if (currentSubClassesToProcessInTree > 0)
										{

										//Deja dans tous les cas, Si on a trouve la sous-branche procinstance on process la branche subClassName de niveau 1
										boolean subclasspathFound = false;
										for (int n=0; n<itemM.getChildCount(); n++)
										{
											DiagTreeItem itemN = (DiagTreeItem)itemM.getChild(m);
											if ( itemN.treeItemName.equals(subClassesList[0]) )
											{
												subclasspathFound = true;
												//Manage Tree Local counters
												buildNamedTreeNodeDisplay(message, itemN, subClassesList[0]);
												//handleMessagesMaskingForIncomingLog(message, (DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m).getChild(n));

												//SI on a besoin de processer un niveau 2 de sub-class (le process lui-m�me)
												if (currentSubClassesToProcessInTree > 1)
												{
													boolean subclasspathLvl2Found = false;
													for (int o=0; o<itemN.getChildCount(); o++)
													{
														DiagTreeItem itemO = (DiagTreeItem)itemN.getChild(m);
														if ( itemO.treeItemName.equals(subClassesList[1]) )
														{
															subclasspathLvl2Found = true;
															//Manage Tree Local counters
															buildNamedTreeNodeDisplay(message, itemO, subClassesList[1]);
															//handleMessagesMaskingForIncomingLog(message, (DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m).getChild(n).getChild(o));



															//SI on a besoin de processer un niveau 3 ou plus de sub-class
															if (currentSubClassesToProcessInTree > 2)
															{
																boolean subclasspathLvl3Found = false;
																for (int p=0; p<itemO.getChildCount(); p++)
																{
																	DiagTreeItem itemP = (DiagTreeItem)itemO.getChild(m);
																	if ( itemP.getText().equals(subClassesList[2]) )
																	{
																		subclasspathLvl3Found = true;
																		//Manage Tree Local counters
																		buildNamedTreeNodeDisplay(message, itemP, subClassesList[2]);
																		//handleMessagesMaskingForIncomingLog(message, (DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m).getChild(n).getChild(o).getChild(p));

																	}
																}
																//Si on n'a pas trouve le subClassNameLvl3, on le rajoute
																if (subclasspathLvl3Found == false)
																{
																	DiagTreeItem item = new DiagTreeItem(subClassesList[2]);
																	itemO.addItem(item);
																	//Manage Tree Local counters
																	buildNamedTreeNodeDisplay(message, item, subClassesList[2]);
																	//DYNTREEDEBUGRELATED
																	//item.nodeListBox.addItem(message.getLogNumber());
																	item.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1], subClassesList[2]);
																}
															}



														}
													}
													//Si on n'a pas trouve le subClassNameLvl2, on le rajoute + on ajoute les infos additionnelles
													if (subclasspathLvl2Found == false)
													{
														DiagTreeItem item = new DiagTreeItem(subClassesList[1]);
														itemN.addItem(item);
														//Manage Tree Local counters
														buildNamedTreeNodeDisplay(message, item, subClassesList[1]);
														//DYNTREEDEBUGRELATED
														//item.nodeListBox.addItem(message.getLogNumber());
														item.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1]);

														if (currentSubClassesToProcessInTree > 2)
														{
															DiagTreeItem item1 = new DiagTreeItem(subClassesList[2]);
															item.addItem(item1);
															//Manage Tree Local counters
															buildNamedTreeNodeDisplay(message, item1, subClassesList[1]);
															//DYNTREEDEBUGRELATED
															//item1.nodeListBox.addItem(message.getLogNumber());
															item1.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1], subClassesList[2]);

														}



													}
												}



											}
										}
										//Si on n'a pas trouve le subClassName, on le rajoute
										if (subclasspathFound == false)
										{
											DiagTreeItem item = new DiagTreeItem(subClassesList[0]);
											itemM.addItem(item);
											//Manage Tree Local counters
											buildNamedTreeNodeDisplay(message, item, subClassesList[0]);
											//DYNTREEDEBUGRELATED
											//item.nodeListBox.addItem(message.getLogNumber());
											item.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0]);

											DiagTreeItem item1;
											if (currentSubClassesToProcessInTree > 1)
											{

												item1 = new DiagTreeItem(subClassesList[1]);
												item.addItem(item1);
												//Manage Tree Local counters
												buildNamedTreeNodeDisplay(message, item1, subClassesList[1]);
												//DYNTREEDEBUGRELATED
												//item1.nodeListBox.addItem(message.getLogNumber());
												item1.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1]);

												if (currentSubClassesToProcessInTree > 2)
												{
													DiagTreeItem item2 = new DiagTreeItem(subClassesList[2]);
													item1.addItem(item2);
													//Manage Tree Local counters
													buildNamedTreeNodeDisplay(message, item2, subClassesList[1]);
													//DYNTREEDEBUGRELATED
													//item2.nodeListBox.addItem(message.getLogNumber());
													item2.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1], subClassesList[2]);

												}
											}

										}

/////
//ICI
										}
										
										
										
									}
								}
								//Si on n'a pas trouve le procinstance, on le rajoute
								if (procinstanceFound == false)
								{
									DiagTreeItem item = new DiagTreeItem("Instance " + message.getProcInstance());
									itemL.addItem(item);
									//Manage Tree Local counters
									buildTreeNodeDisplay(message, item);
									//DYNTREEDEBUGRELATED
									//item.nodeListBox.addItem(message.getLogNumber());
									item.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance());

									if (currentSubClassesToProcessInTree > 0)
									{
										DiagTreeItem item20 = new DiagTreeItem(subClassesList[0]);
										item.addItem(item20);
										//Manage Tree Local counters
										buildNamedTreeNodeDisplay(message, item20, subClassesList[0]);
										//DYNTREEDEBUGRELATED
										//item20.nodeListBox.addItem(message.getLogNumber());
										item20.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0]);

										if (currentSubClassesToProcessInTree > 1)
										{
											DiagTreeItem item21 = new DiagTreeItem(subClassesList[1]);
											item20.addItem(item21);
											//Manage Tree Local counters
											buildNamedTreeNodeDisplay(message, item21, subClassesList[1]);
											//DYNTREEDEBUGRELATED
											//item21.nodeListBox.addItem(message.getLogNumber());
											item21.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1]);

											if (currentSubClassesToProcessInTree > 2)
											{
												DiagTreeItem item22 = new DiagTreeItem(subClassesList[2]);
												item21.addItem(item22);
												//Manage Tree Local counters
												buildNamedTreeNodeDisplay(message, item22, subClassesList[1]);
												//DYNTREEDEBUGRELATED
												//item22.nodeListBox.addItem(message.getLogNumber());
												item22.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1], subClassesList[2]);

											}
										}
									}

								}





							}
						}
						//Si on n'a pas trouve le procname, on le rajoute + on ajoute les infos additionnelles
						if (procnameFound == false)
						{
							DiagTreeItem item = new DiagTreeItem(message.getProcName());
							itemK.addItem(item);
							//Manage Tree Local counters
							buildTreeNodeDisplay(message, item);
							//DYNTREEDEBUGRELATED
							//item.nodeListBox.addItem(message.getLogNumber());
							item.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName());

							DiagTreeItem item1 = new DiagTreeItem("Instance " + message.getProcInstance());
							item.addItem(item1);
							//Manage Tree Local counters
							buildTreeNodeDisplay(message, item1);
							//DYNTREEDEBUGRELATED
							//item1.nodeListBox.addItem(message.getLogNumber());
							item1.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance());

									if (currentSubClassesToProcessInTree > 0)
									{
										DiagTreeItem item20 = new DiagTreeItem(subClassesList[0]);
										item1.addItem(item20);
										//Manage Tree Local counters
										buildNamedTreeNodeDisplay(message, item20, subClassesList[0]);
										//DYNTREEDEBUGRELATED
										//item20.nodeListBox.addItem(message.getLogNumber());
										item20.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0]);

										if (currentSubClassesToProcessInTree > 1)
										{
											DiagTreeItem item21 = new DiagTreeItem(subClassesList[1]);
											item20.addItem(item21);
											//Manage Tree Local counters
											buildNamedTreeNodeDisplay(message, item21, subClassesList[1]);
											//DYNTREEDEBUGRELATED
											//item21.nodeListBox.addItem(message.getLogNumber());
											item21.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1]);

											if (currentSubClassesToProcessInTree > 2)
											{
												DiagTreeItem item22 = new DiagTreeItem(subClassesList[2]);
												item21.addItem(item22);
												//Manage Tree Local counters
												buildNamedTreeNodeDisplay(message, item22, subClassesList[1]);
												//DYNTREEDEBUGRELATED
												//item22.nodeListBox.addItem(message.getLogNumber());
												item22.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1], subClassesList[2]);

											}
										}
									}

						}








						//break;
					}
					
				}
				//Si on n'a pas trouve le port, on le rajoute + on ajoute les infos additionnelles
				if (portFound == false)
				{
					DiagTreeItem item = new DiagTreeItem(message.getPort());
					itemJ.addItem(item);
					//Manage Tree Local counters
					buildTreeNodeDisplay(message, item);
					//DYNTREEDEBUGRELATED
					//item.nodeListBox.addItem(message.getLogNumber());
					item.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort());

					DiagTreeItem item1 = new DiagTreeItem(message.getProcName());
					item.addItem(item1);
					//Manage Tree Local counters
					buildTreeNodeDisplay(message, item1);
					//DYNTREEDEBUGRELATED
					//item1.nodeListBox.addItem(message.getLogNumber());
					item1.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName());

					DiagTreeItem item2 = new DiagTreeItem("Instance " + message.getProcInstance());
					item1.addItem(item2);			
					//Manage Tree Local counters
					buildTreeNodeDisplay(message, item2);
					//DYNTREEDEBUGRELATED
					//item2.nodeListBox.addItem(message.getLogNumber());
					item2.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance());


									if (currentSubClassesToProcessInTree > 0)
									{
										DiagTreeItem item20 = new DiagTreeItem(subClassesList[0]);
										item2.addItem(item20);
										//Manage Tree Local counters
										buildNamedTreeNodeDisplay(message, item20, subClassesList[0]);
										//DYNTREEDEBUGRELATED
										//item20.nodeListBox.addItem(message.getLogNumber());
										item20.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0]);

										if (currentSubClassesToProcessInTree > 1)
										{
											DiagTreeItem item21 = new DiagTreeItem(subClassesList[1]);
											item20.addItem(item21);
											//Manage Tree Local counters
											buildNamedTreeNodeDisplay(message, item21, subClassesList[1]);
											//DYNTREEDEBUGRELATED
											//item21.nodeListBox.addItem(message.getLogNumber());
											item21.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1]);

											if (currentSubClassesToProcessInTree > 2)
											{
												DiagTreeItem item22 = new DiagTreeItem(subClassesList[2]);
												item21.addItem(item22);
												//Manage Tree Local counters
												buildNamedTreeNodeDisplay(message, item22, subClassesList[1]);
												//DYNTREEDEBUGRELATED
												//item22.nodeListBox.addItem(message.getLogNumber());
												item22.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1], subClassesList[2]);

											}
										}
									}

				}




				//break;
			}

		}
		//Si on n'a pas trouve la machine, on la rajoute + on ajoute les infos additionnelles
		if (machineFound == false)
		{
			DiagTreeItem item = new DiagTreeItem(message.getMachine());
			itemI.addItem(item);
			//Manage Tree Local counters
			buildTreeNodeDisplay(message, item);
			//DYNTREEDEBUGRELATED
			//item.nodeListBox.addItem(message.getLogNumber());
			item.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine());


			DiagTreeItem item1 = new DiagTreeItem(message.getPort());
			item.addItem(item1);
			//Manage Tree Local counters
			buildTreeNodeDisplay(message, item1);
			//DYNTREEDEBUGRELATED
			//item1.nodeListBox.addItem(message.getLogNumber());
			item1.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort());

			DiagTreeItem item2 = new DiagTreeItem(message.getProcName());
			item1.addItem(item2);
			//Manage Tree Local counters
			buildTreeNodeDisplay(message, item2);
			//DYNTREEDEBUGRELATED
			//item2.nodeListBox.addItem(message.getLogNumber());
			item2.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName());

			DiagTreeItem item3 = new DiagTreeItem("Instance " + message.getProcInstance());
			item2.addItem(item3);			
			//Manage Tree Local counters
			buildTreeNodeDisplay(message, item3);
			//DYNTREEDEBUGRELATED
			//item3.nodeListBox.addItem(message.getLogNumber());
			item3.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance());


									if (currentSubClassesToProcessInTree > 0)
									{
										DiagTreeItem item20 = new DiagTreeItem(subClassesList[0]);
										item3.addItem(item20);
										//Manage Tree Local counters
										buildNamedTreeNodeDisplay(message, item20, subClassesList[0]);
										//DYNTREEDEBUGRELATED
										//item20.nodeListBox.addItem(message.getLogNumber());
										item20.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0]);

										if (currentSubClassesToProcessInTree > 1)
										{
											DiagTreeItem item21 = new DiagTreeItem(subClassesList[1]);
											item20.addItem(item21);
											//Manage Tree Local counters
											buildNamedTreeNodeDisplay(message, item21, subClassesList[1]);
											//DYNTREEDEBUGRELATED
											//item21.nodeListBox.addItem(message.getLogNumber());
											item21.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1]);

											if (currentSubClassesToProcessInTree > 2)
											{
												DiagTreeItem item22 = new DiagTreeItem(subClassesList[2]);
												item21.addItem(item22);
												//Manage Tree Local counters
												buildNamedTreeNodeDisplay(message, item22, subClassesList[1]);
												//DYNTREEDEBUGRELATED
												//item22.nodeListBox.addItem(message.getLogNumber());
												item22.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1], subClassesList[2]);

											}
										}
									}

		}
		

//}


//trackerFound


		
		
	} //else Window.alert("Sub Detector " + errorsTree.getItem(i).getText() + " NOT found");

}




		//Si on n'a pas trouve sous d�tecteur, on le rajoute + on ajoute les infos additionnelles
		if (trackerFound == false)
		{
			    DiagTreeItem tracker = new DiagTreeItem(Defs.SUBDETECTOR_NAME);
			    errorsTree.addItem(tracker);
				buildTreeNodeDisplay(message, tracker);
				tracker.setNodeProperties(Defs.SUBDETECTOR_NAME);

			DiagTreeItem item = new DiagTreeItem(message.getMachine());
			tracker.addItem(item);
			//Manage Tree Local counters
			buildTreeNodeDisplay(message, item);
			//DYNTREEDEBUGRELATED
			//item.nodeListBox.addItem(message.getLogNumber());
			item.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine());


			DiagTreeItem item1 = new DiagTreeItem(message.getPort());
			item.addItem(item1);
			//Manage Tree Local counters
			buildTreeNodeDisplay(message, item1);
			//DYNTREEDEBUGRELATED
			//item1.nodeListBox.addItem(message.getLogNumber());
			item1.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort());

			DiagTreeItem item2 = new DiagTreeItem(message.getProcName());
			item1.addItem(item2);
			//Manage Tree Local counters
			buildTreeNodeDisplay(message, item2);
			//DYNTREEDEBUGRELATED
			//item2.nodeListBox.addItem(message.getLogNumber());
			item2.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName());

			DiagTreeItem item3 = new DiagTreeItem("Instance " + message.getProcInstance());
			item2.addItem(item3);			
			//Manage Tree Local counters
			buildTreeNodeDisplay(message, item3);
			//DYNTREEDEBUGRELATED
			//item3.nodeListBox.addItem(message.getLogNumber());
			item3.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance());


									if (currentSubClassesToProcessInTree > 0)
									{
										DiagTreeItem item20 = new DiagTreeItem(subClassesList[0]);
										item3.addItem(item20);
										//Manage Tree Local counters
										buildNamedTreeNodeDisplay(message, item20, subClassesList[0]);
										//DYNTREEDEBUGRELATED
										//item20.nodeListBox.addItem(message.getLogNumber());
										item20.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0]);

										if (currentSubClassesToProcessInTree > 1)
										{
											DiagTreeItem item21 = new DiagTreeItem(subClassesList[1]);
											item20.addItem(item21);
											//Manage Tree Local counters
											buildNamedTreeNodeDisplay(message, item21, subClassesList[1]);
											//DYNTREEDEBUGRELATED
											//item21.nodeListBox.addItem(message.getLogNumber());
											item21.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1]);

											if (currentSubClassesToProcessInTree > 2)
											{
												DiagTreeItem item22 = new DiagTreeItem(subClassesList[2]);
												item21.addItem(item22);
												//Manage Tree Local counters
												buildNamedTreeNodeDisplay(message, item22, subClassesList[1]);
												//DYNTREEDEBUGRELATED
												//item22.nodeListBox.addItem(message.getLogNumber());
												item22.setNodeProperties(Defs.SUBDETECTOR_NAME, message.getMachine(), message.getPort(), message.getProcName(), message.getProcInstance(), subClassesList[0], subClassesList[1], subClassesList[2]);

											}
										}
									}

		}
		













if (message.showInTable == false)
{
	//Masking Strategy : Do not hide line anymore but delete hidden rows from table
	//RowFormatter rf = ft.getRowFormatter();
	//rf.setVisible(row, false);
	ft.removeRow(row);
	numberOfLogsInTable--;

}
else
{

  if ( message.getLevel().equals("TRACE") )
  {
	if (USE_SOUNDS_FOR_TRACE == true) soundTrace.play();
  	ft.getRowFormatter().setStyleName(row, "gwt-LogsFlexTable-TraceRow");
  }
  else if ( message.getLevel().equals("DEBUG") )
  {
	if (USE_SOUNDS_FOR_DEBUG == true) soundDebug.play();
  	ft.getRowFormatter().setStyleName(row, "gwt-LogsFlexTable-DebugRow");
  }
  else if ( message.getLevel().equals("INFO") )
  {
	if (USE_SOUNDS_FOR_INFO == true) soundInfo.play();
  	ft.getRowFormatter().setStyleName(row, "gwt-LogsFlexTable-InfoRow");
  }
  else if ( message.getLevel().equals("WARN") )
  {
	if (USE_SOUNDS_FOR_WARN == true) soundWarn.play();
  	ft.getRowFormatter().setStyleName(row, "gwt-LogsFlexTable-WarnRow");
  }
  else if ( message.getLevel().equals("USERINFO") )
  {
	if (USE_SOUNDS_FOR_USERINFO == true) soundUserinfo.play();
  	ft.getRowFormatter().setStyleName(row, "gwt-LogsFlexTable-UserinfoRow");
  }
  else if ( message.getLevel().equals("ERROR") )
  {
	if (USE_SOUNDS_FOR_ERROR == true) soundError.play();
  	ft.getRowFormatter().setStyleName(row, "gwt-LogsFlexTable-ErrorRow");
  }
  else if ( message.getLevel().equals("FATAL") )
  {
	if (USE_SOUNDS_FOR_FATAL == true) soundFatal.play();
  	ft.getRowFormatter().setStyleName(row, "gwt-LogsFlexTable-FatalRow");
  }

}


return 0;
} //End of Method




private void updateTable(JSONArray array) {
  //ArrayList<StockPrice> stockPrices = new ArrayList<StockPrice>();
  ArrayList<LogMessage> logsList = new ArrayList<LogMessage>();

  JSONValue jsonValue;
  
  for (int i=0; i<array.size(); i++) {
    JSONObject jsLogMessage;

    JSONString jsLevel;
    JSONString jsErrCode;
    JSONString jsMessage;
    JSONString jsTimestamp;
    JSONString jsSource;

    JSONString jsSysId;
    JSONString jsSubSysId;
    JSONString jsExtraBuffer;



    JSONString jsMachine;
    JSONString jsPort;
    JSONString jsProcName;
    JSONString jsProcInstance;

    JSONString jsLogNumber;

    JSONString jsFechardid;
    JSONString jsRing;
    JSONString jsCcu;
    JSONString jsI2cchannel;
    JSONString jsI2caddress;
    JSONString jsFedid;
    JSONString jsFedchannel;
    JSONString jsCrate;
    JSONString jsSlot;
    JSONString jsNestedclasspath;
    JSONString jsNestedfilename;
    JSONString jsNestedlinenumber;

//MMDEBUG
    JSONString jsErrorUnregisteredApplet;




//Recuperer les infos JSON additionnelles ++ patcher la mise en forme des data du tableau dans le updateTable unitaire
    
    if ((jsLogMessage = array.get(i).isObject()) == null) continue;
    
    if ((jsonValue = jsLogMessage.get("level")) == null) continue;
    if ((jsLevel = jsonValue.isString()) == null) continue;
    
    if ((jsonValue = jsLogMessage.get("errcode")) == null) continue;
    if ((jsErrCode = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("message")) == null) continue;
    if ((jsMessage = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("timestamp")) == null) continue;
    if ((jsTimestamp = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("source")) == null) continue;
    if ((jsSource = jsonValue.isString()) == null) continue;



    if ((jsonValue = jsLogMessage.get("systemid")) == null) continue;
    if ((jsSysId = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("subsystemid")) == null) continue;
    if ((jsSubSysId = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("extraBuffer")) == null) continue;
    if ((jsExtraBuffer = jsonValue.isString()) == null) continue;




    if ((jsonValue = jsLogMessage.get("machine")) == null) continue;
    if ((jsMachine = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("port")) == null) continue;
    if ((jsPort = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("procname")) == null) continue;
    if ((jsProcName = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("procinstance")) == null) continue;
    if ((jsProcInstance = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("lognumber")) == null) continue;
    if ((jsLogNumber = jsonValue.isString()) == null) continue;





    if ((jsonValue = jsLogMessage.get("fechardid")) == null) continue;
    if ((jsFechardid = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("ring")) == null) continue;
    if ((jsRing = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("ccu")) == null) continue;
    if ((jsCcu = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("i2cchannel")) == null) continue;
    if ((jsI2cchannel = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("i2caddress")) == null) continue;
    if ((jsI2caddress = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("fedid")) == null) continue;
    if ((jsFedid = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("fedchannel")) == null) continue;
    if ((jsFedchannel = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("crate")) == null) continue;
    if ((jsCrate = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("slot")) == null) continue;
    if ((jsSlot = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("nestedclasspath")) == null) continue;
    if ((jsNestedclasspath = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("nestedfilename")) == null) continue;
    if ((jsNestedfilename = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsLogMessage.get("nestedlinenumber")) == null) continue;
    if ((jsNestedlinenumber = jsonValue.isString()) == null) continue;



//MMDEBUG
    if ((jsonValue = jsLogMessage.get("APP_REG_ERROR")) == null) continue;
    if ((jsErrorUnregisteredApplet = jsonValue.isString()) == null) continue;

    String errorUnregisteredApplet = jsErrorUnregisteredApplet.stringValue();


    if (errorUnregisteredApplet.equals("TRUE"))
    {
		refreshTimer.cancel();
		timerIsOn = false;
		systemStatusPanel.refreshTimerInfos(this);
//		if (autoReconnectWhenXdaqStops.equals("TRUE"))
		if (Defs.FORCE_EXPLICIT_RECONNECTION_WHEN_XDAQ_STOPS == true)
		{
			Window.alert("ERROR! This applet is no longer registered as valid in the AjaxLogReader server process.<b>Please close this applet and open a new one OR reconnect via the Control Pannel button.");
		}
		else
		{
			findXdaqJsonServer();
		}
    }
    else
    {


/*
    stockPrices.add(new StockPrice(jsSymbol.stringValue(),
        jsPrice.getValue(),
        jsChange.getValue()));
*/
	logsList.add(new LogMessage( jsLevel.stringValue(),
								jsErrCode.stringValue(),
								jsMessage.stringValue(),
								jsTimestamp.stringValue(),
								jsSource.stringValue(),

								jsSysId.stringValue(),
								jsSubSysId.stringValue(),
								jsExtraBuffer.stringValue(),

								jsMachine.stringValue(),
								jsPort.stringValue(),
								jsProcName.stringValue(),
								jsProcInstance.stringValue(),
								
								jsLogNumber.stringValue(),
								 
								jsFechardid.stringValue(),
								jsRing.stringValue(),
								jsCcu.stringValue(),
								jsI2cchannel.stringValue(),
								jsI2caddress.stringValue(),
								jsFedid.stringValue(),
								jsFedchannel.stringValue(),
								jsCrate.stringValue(),
								jsSlot.stringValue(),
								jsNestedclasspath.stringValue(),
								jsNestedfilename.stringValue(),
								jsNestedlinenumber.stringValue()  ));
  }
  }

//  updateTable(stockPrices.toArray(new StockPrice[0]));
  updateTable(logsList.toArray(new LogMessage[0]));
}









private void updateJsonConnectionParams(JSONArray array) {
  //ArrayList<StockPrice> stockPrices = new ArrayList<StockPrice>();
//  ArrayList<LogMessage> logsList = new ArrayList<LogMessage>();






  JSONValue jsonValue;

//displayError("AAAAAAAAAAAAAAAAAAAAAAAAAAAaa");

  for (int i=0; i<array.size(); i++) {
    JSONObject jsMessage;

	JSONString jsProcName;
	JSONString jsProcLid;
	JSONString jsLogsBurstLength;
//	JSONNumber jsLogsBurstLength;
	JSONString jsAppletUid;



    
    if ((jsMessage = array.get(i).isObject()) == null) continue;
    
    if ((jsonValue = jsMessage.get("PROC_NAME")) == null) continue;
    if ((jsProcName = jsonValue.isString()) == null) continue;
    
    if ((jsonValue = jsMessage.get("PROC_LID")) == null) continue;
    if ((jsProcLid = jsonValue.isString()) == null) continue;


    if ((jsonValue = jsMessage.get("LOGS_BURST_LENGTH")) == null) continue;
    if ((jsLogsBurstLength = jsonValue.isString()) == null) continue;

    if ((jsonValue = jsMessage.get("APPLET_UID")) == null) continue;
    if ((jsAppletUid = jsonValue.isString()) == null) continue;
    appletUid = jsAppletUid.stringValue();

    JSON_URL = "http://" + Window.Location.getHost() + "/urn:xdaq-application:lid=" + jsProcLid.stringValue() + "/getJSONDataList";

//HWXDEPS
xdaqServerLid = jsProcLid.stringValue();

}


//Window.alert("I have been served applet UID : " + appletUid);
//MMDEBUG
//appletUid = appletUid + "__TEST";
}













private void updateJsJsonConnectionParams(JSONArray array) {
  JSONValue jsonValue;
  for (int i=0; i<array.size(); i++) {

    JSONObject jsMessage;

	JSONString jsLogsBurstLength;
	JSONString jsAppletUid;

    if ((jsMessage = array.get(i).isObject()) == null) continue;

    if ((jsonValue = jsMessage.get("LOGS_BURST_LENGTH")) == null) continue;
    if ((jsLogsBurstLength = jsonValue.isString()) == null) continue;


    if ((jsonValue = jsMessage.get("APPLET_UID")) == null) continue;
    if ((jsAppletUid = jsonValue.isString()) == null) continue;

//	logsBurstLength = Integer.valueOf(jsLogsBurstLength.stringValue());
	appletUid = jsAppletUid.stringValue();

}

//	Window.alert("I have been served applet UID : " + appletUid);
//MMDEBUG
//appletUid = appletUid + "__TEST";
}










public void findXdaqJsonServer()
{
// displayError("entering findXdaqJsonServer");
//AAAAAAAa
isRunningXsiteScript = false;
hasAttemptedOneConnection = false;
hasFindJsonServerSource = false;
/*
if ( (USER_DEFINED_REFRESH_INTERVAL != Defs.STANDARD_REFRESH_INTERVAL) && (USER_DEFINED_REFRESH_INTERVAL != Defs.QUICK_REFRESH_INTERVAL) )
{
  CURRENT_REFRESH_INTERVAL = USER_DEFINED_REFRESH_INTERVAL;
}
else
{
  CURRENT_REFRESH_INTERVAL = Defs.STANDARD_REFRESH_INTERVAL;
}
*/

if (CURRENT_REFRESH_INTERVAL != Defs.STANDARD_REFRESH_INTERVAL)
{
	CURRENT_REFRESH_INTERVAL = Defs.STANDARD_REFRESH_INTERVAL;
}
systemStatusPanel.refreshTimeIntervalInfos(this);

JSON_URL = "";

refreshTimer.scheduleRepeating(CURRENT_REFRESH_INTERVAL);
timerIsOn = true;
systemStatusPanel.refreshTimerInfos(this);


//displayError("Starting to peek json server  --  ");
	for (int i=Defs.LID_MIN_POLL_LIMIT; i<=Defs.LID_MAX_POLL_LIMIT; i++)
	{
		String url;
//		int res;
//		peekJsonUrl = "http://" + Window.Location.getHost() + "/urn:xdaq-application:lid=" + i + "/getJSONDataList";
		url = "http://" + Window.Location.getHost() + "/urn:xdaq-application:lid=" + i + "/getJSONConnectionParam";
		refreshWatchListOnStartup(url);
//		displayError("Returned value : " + res + " -- ");

	}
}


/*

private void displayError(String error) {

//  errorMsgLabel.setText("Last system log : " + Window.Location.getHost());
//  errorMsgLabel.setText("Last system log : ");
//  errorMsgLabel.setText("Last system log : " + Window.Location.getHref());

	
  errorMsgLabel.setText("Last system log : " + DateTimeFormat.getMediumDateTimeFormat().format(new Date()) + ":" + error);


//errorMsgLabel.setText(errorMsgLabel.getText() + "\n" + error);
  errorMsgLabel.setVisible(true);
}

*/




public void refreshWatchList() {
 
   // add watch list stock symbols to URL
 String url = JSON_URL;// + "?TOTO=43&TITI=52";

 if (hasAttemptedOneConnection == false)
 {

 hasAttemptedOneConnection = true;
// systemStatusPanel.refreshInfos(this);
//   lastUpdatedLabel.setText("(Update rate : " + CURRENT_REFRESH_INTERVAL/1000 + " seconds) Last update : " + DateTimeFormat.getMediumDateTimeFormat().format(new Date()) + " from data source : " + JSON_URL);
//showHeartBeatLabel();


  
  if (JSON_URL.equals("") )
  {
		hasFindJsonServerSource = false;
		if (isRunningXsiteScript == false)
		{
			Window.alert("No AjaxLogReader xdaq application seems to run on your local HTTP server.\n You will have to define manually the connection parameters in the CONTROL PANNEL interface if you want to connect to an external AjaxLogReader application.");
		}
		else
		{
			Window.alert("No AjaxLogReader xdaq application seems to run on the distant HTTP server you choose.\n You will have to modify manually the connection parameters in the CONTROL PANNEL interface if you want to connect to this external AjaxLogReader application.");
		}
		refreshTimer.cancel();
		timerIsOn = false;
		systemStatusPanel.refreshConnectionStatusInfos(this);
		systemStatusPanel.refreshTimerInfos(this);

//		connectionParametersPannel.cleanFieldsOnAutoDetectError();
  }
  else
  {
		hasFindJsonServerSource = true;
//	  connectionParametersPannel.setFieldsOnAutoDetectSuccess(Window.Location.getHost(), xdaqLID, JSON_URL);
	  //systemStatusPanel.refreshInfos(this);
		systemStatusPanel.refreshConnectionStatusInfos(this);

  }

}


  //Manage Applet UID transmission to cpp process
  if (fileParsingCommand.equals(""))
  {
//  	fileParsingCommand = "APPLET_UID=" + appletUid;
  	fileParsingCommand = "APPLET_UID=" + appletUid + "&LOGS_BURST_LENGTH=" + logsBurstLength;
  }
  else fileParsingCommand = fileParsingCommand + "&APPLET_UID=" + appletUid;


/*

  if (fileParsingCommand.equals(""))
  {
  	fileParsingCommand = "LOGS_BURST_LENGTH=" + logsBurstLength;
  }
  else fileParsingCommand = fileParsingCommand + "&LOGS_BURST_LENGTH=" + logsBurstLength;

*/



/*
Window.alert("Internal logs burst length is " + logsBurstLength + " logs length");
Window.alert("Using URL : " + fileParsingCommand);
*/

if (isRunningXsiteScript == false)
{

//fileParsingCommand = "DO_REWIND=TRUE";
//fileParsingCommand = "LOGS_BURST_LENGTH=" + logsBurstLength;

  url = url + "?" + fileParsingCommand;
  
  
  url = URL.encode(url);


  RequestBuilder builder = new RequestBuilder(RequestBuilder.GET, url);


  
  try {
    Request request = builder.sendRequest(null, new RequestCallback() {
      public void onError(Request request, Throwable exception) {
         //displayError("Couldn't retrieve JSON 1");         
      }

      public void onResponseReceived(Request request, Response response) {
        if (200 == response.getStatusCode()) {

          try {
            // parse the response text into JSON
            JSONValue jsonValue = JSONParser.parse(response.getText());
            JSONArray jsonArray = jsonValue.isArray();
            
            if (jsonArray != null)
			{
              updateTable(jsonArray);
            }
			else
			{
				//throw new JSONException();
			}
          } catch (JSONException e) {
            //displayError("Could not parse JSON -- " + response.getText());
          }
        } else {
          //displayError("Couldn't retrieve JSON 2 (" + response.getStatusText() + ")");
        }
      }       
    });
  } catch (RequestException e) {
    //displayError("Couldn't retrieve JSON 3 - " + e.getMessage());         
  }

	fileParsingCommand = "";

}//end of condition on xdaq scriting
else
{
//fileParsingCommand = "LOGS_BURST_LENGTH=" + logsBurstLength;

	getDataThroughXSiteConnection();
	fileParsingCommand = "";

}

}







private void refreshWatchListOnStartup(String paramUrl)
{
// displayError("entering refreshWatchListOnStartup");
  // add watch list stock symbols to URL
//  String url = JSON_URL;
//  String url = URL.encode(peekJsonUrl);


  String url = URL.encode(paramUrl);
  
  RequestBuilder builder = new RequestBuilder(RequestBuilder.GET, url);
  
  try
  {
     Request request = builder.sendRequest(null, new RequestCallback()
	 {
        public void onError(Request request, Throwable exception)
		{
        }

        public void onResponseReceived(Request request, Response response)
		{
           if (200 == response.getStatusCode()) 
		   {
              try {
                    // parse the response text into JSON
                   JSONValue jsonValue = JSONParser.parse(response.getText());
                   JSONArray jsonArray = jsonValue.isArray();
            
                   if (jsonArray != null)
				   {
			updateJsonConnectionParams(jsonArray);

			//Prepare URL criticity level filters for next timer tick
			reparseLogsFile();

                    }
/*
		  		    else
			        {
                    }
*/
                  }
				  catch (JSONException e)
				  {
                  }
           }
/*
		   else
		   {
           }
*/
      }
    } );
  }
  catch (RequestException e)
  {
  }
}





/*

//getRowFormatter() 
public void hideShowMessagesWithCriticity(	boolean showTrace,
											boolean showDebug,
											boolean showInfo,
											boolean showWarn,
											boolean showUserinfo,
											boolean showError,
											boolean showFatal)
{
RowFormatter rf = ft.getRowFormatter();

for (int rowCounter=0; rowCounter<ft.getRowCount(); rowCounter++)
{
  String criticityLevel = ft.getText(rowCounter, Defs.LEVEL_COL);

  if ( criticityLevel.equals("TRACE")) {
		if (showTrace == true) { rf.setVisible(rowCounter, true); }
		else rf.setVisible(rowCounter, false); }
  
  if ( criticityLevel.equals("DEBUG")) {
		if (showDebug == true) { rf.setVisible(rowCounter, true); }
		else rf.setVisible(rowCounter, false); }

  if ( criticityLevel.equals("INFO")) {
		if (showInfo == true) { rf.setVisible(rowCounter, true); }
		else rf.setVisible(rowCounter, false); }

  if ( criticityLevel.equals("WARN")) {
		if (showWarn == true) { rf.setVisible(rowCounter, true); }
		else rf.setVisible(rowCounter, false); }

  if ( criticityLevel.equals("USERINFO")) {
		if (showUserinfo == true) { rf.setVisible(rowCounter, true); }
		else rf.setVisible(rowCounter, false); }

  if ( criticityLevel.equals("ERROR")) {
		if (showError == true) { rf.setVisible(rowCounter, true); }
		else rf.setVisible(rowCounter, false); }

  if ( criticityLevel.equals("FATAL")) {
		if (showFatal == true) { rf.setVisible(rowCounter, true); }
		else rf.setVisible(rowCounter, false); }


}

}

*/


public void hideShowOneRowWithCriticity(int rowNumber, String criticityLevel, LogMessage message)
{

RowFormatter rf = ft.getRowFormatter();

  if ( criticityLevel.equals("TRACE")) {
		if (controlCriticityPannel.rbTraceChecked == true) { rf.setVisible(rowNumber, true); }
		else {rf.setVisible(rowNumber, false); message.showInTable=false;} }
  
  if ( criticityLevel.equals("DEBUG")) {
		if (controlCriticityPannel.rbDebugChecked == true) { rf.setVisible(rowNumber, true); }
		else {rf.setVisible(rowNumber, false); message.showInTable=false;} }

  if ( criticityLevel.equals("INFO")) {
		if (controlCriticityPannel.rbInfoChecked == true) { rf.setVisible(rowNumber, true); }
		else {rf.setVisible(rowNumber, false); message.showInTable=false;} }

  if ( criticityLevel.equals("WARN")) {
		if (controlCriticityPannel.rbWarnChecked == true) { rf.setVisible(rowNumber, true); }
		else {rf.setVisible(rowNumber, false); message.showInTable=false;} }

  if ( criticityLevel.equals("USERINFO")) {
		if (controlCriticityPannel.rbUserinfoChecked == true) { rf.setVisible(rowNumber, true); }
		else {rf.setVisible(rowNumber, false); message.showInTable=false;} }

  if ( criticityLevel.equals("ERROR")) {
		if (controlCriticityPannel.rbErrorChecked == true) { rf.setVisible(rowNumber, true); }
		else {rf.setVisible(rowNumber, false); message.showInTable=false;} }

  if ( criticityLevel.equals("FATAL")) {
		if (controlCriticityPannel.rbFatalChecked == true) { rf.setVisible(rowNumber, true); }
		else {rf.setVisible(rowNumber, false); message.showInTable=false;} }


}









public void hideShowFlexTableColumn(boolean showColumn, int columnIndex)
{
	CellFormatter cf = ft.getCellFormatter();

	if (showColumn == true)
	{
		for (int rowCounter=0; rowCounter<ft.getRowCount(); rowCounter++)
		{
			cf.setVisible(rowCounter, columnIndex, true);
		}
	}

	if (showColumn == false)
	{
		for (int rowCounter=0; rowCounter<ft.getRowCount(); rowCounter++)
		{
			cf.setVisible(rowCounter, columnIndex, false);
		}
	}

}





public void hideShowOneElementInColumn(int rowIndex)
{
		CellFormatter cf = ft.getCellFormatter();

		if (columnsManagementPannel.showLbLevel == true) {cf.setVisible(rowIndex, Defs.LEVEL_COL, true);} else {cf.setVisible(rowIndex, Defs.LEVEL_COL, false);}
		if (columnsManagementPannel.showLbErrCode == true) {cf.setVisible(rowIndex, Defs.ERRCODE_COL, true);} else {cf.setVisible(rowIndex, Defs.ERRCODE_COL, false);}
		if (columnsManagementPannel.showLbMessage == true) {cf.setVisible(rowIndex, Defs.MSG_COL, true);} else {cf.setVisible(rowIndex, Defs.MSG_COL, false);}
		if (columnsManagementPannel.showLbTimestamp == true) {cf.setVisible(rowIndex, Defs.TS_COL, true);} else {cf.setVisible(rowIndex, Defs.TS_COL, false);}
		if (columnsManagementPannel.showLbSource == true) {cf.setVisible(rowIndex, Defs.SOURCE_COL, true);} else {cf.setVisible(rowIndex, Defs.SOURCE_COL, false);}
		if (columnsManagementPannel.showLbSysid == true) {cf.setVisible(rowIndex, Defs.SYSID_COL, true);} else {cf.setVisible(rowIndex, Defs.SYSID_COL, false);}
		if (columnsManagementPannel.showLbSubsysid == true) {cf.setVisible(rowIndex, Defs.SUBSYSID_COL, true);} else {cf.setVisible(rowIndex, Defs.SUBSYSID_COL, false);}
		if (columnsManagementPannel.showLbXtrabuff == true) {cf.setVisible(rowIndex, Defs.XTRABUFF_COL, true);} else {cf.setVisible(rowIndex, Defs.XTRABUFF_COL, false);}
		if (columnsManagementPannel.showLbMachine == true) {cf.setVisible(rowIndex, Defs.MACHINE_COL, true);} else {cf.setVisible(rowIndex, Defs.MACHINE_COL, false);}
		if (columnsManagementPannel.showLbPort == true) {cf.setVisible(rowIndex, Defs.PORT_COL, true);} else {cf.setVisible(rowIndex, Defs.PORT_COL, false);}
		if (columnsManagementPannel.showLbProcess == true) {cf.setVisible(rowIndex, Defs.PROCNAME_COL, true);} else {cf.setVisible(rowIndex, Defs.PROCNAME_COL, false);}
		if (columnsManagementPannel.showLbInstance == true) {cf.setVisible(rowIndex, Defs.PROCINST_COL, true);} else {cf.setVisible(rowIndex, Defs.PROCINST_COL, false);}
		if (columnsManagementPannel.showLbLogNumber == true) {cf.setVisible(rowIndex, Defs.LOGNUM_COL, true);} else {cf.setVisible(rowIndex, Defs.LOGNUM_COL, false);}

}



/*


public void detected()
{
Window.alert("In detected");
}



public void undetected()
{
Window.alert("In undetected");

}


*/


//Used to wrap calls to refreshInfos() method in forceCrossSiteConnection() javascript methods
public void refreshStatusPannel()
{
systemStatusPanel.refreshInfos(this);
}


//Used to wrap calls to refreshInfos() method in forceCrossSiteConnection() javascript methods
public void refreshTimerInfoInStatusPannel()
{
systemStatusPanel.refreshTimerInfos(this);
}

public void refreshTimerIntervalInfoInStatusPannel()
{
systemStatusPanel.refreshTimeIntervalInfos(this);
}


public void refreshConnectionInfoInStatusPannel()
{
systemStatusPanel.refreshConnectionStatusInfos(this);
}


public void forceCrossSiteConnection()
{

  //If a connection to new CrossSite reference is requested, then :
  //Stop the timer ; no more auto-refresh for now
  refreshTimer.cancel();
  timerIsOn = false;
  systemStatusPanel.refreshTimerInfos(this);
  //Notify that we will try to run CrossSite scripting
  isRunningXsiteScript = true;
  //Reset connection status
  hasAttemptedOneConnection = false;
  //Reset JSON_URL to empty until connection confirmation
  JSON_URL = "";
  //Update general status pannel
//  systemStatusPanel.refreshInfos(this);

  

  JSONExternalWrapper MyJSONExternalWrapper = new JSONExternalWrapper();
  String lclURL = "http://" + xsiteConnectionUrl + "/urn:xdaq-application:lid=" + xsiteConnectionLid + "/"+"getJsJSONConnectionParam?alt=json-in-script&callback=";

  JSONExternalWrapper.makeJSONConnectionRequest(lclURL, new JSONExternalWrapper.JSONConnectionHandler()

  {
    public void handleJSONConnection(JavaScriptObject obj)
    {
      JSONObject resp= new JSONObject(obj);
      JSONArray jsonArray = resp.get("Connection").isArray();
      if (jsonArray != null)
      {
		//Si on a un array non nul, on considere que c'est bon - on est sur un serveur JSON

		//MOD TO ADD FOR AUTOMATED BUFFER SIZE FIXING
		//Basically get buffer length as defined in AjaxLogReader.cc
        updateJsJsonConnectionParams(jsonArray);


		//Update JSON_URL avec l'adresse du DATA_SERVER
		JSON_URL = "http://" + xsiteConnectionUrl + "/urn:xdaq-application:lid=" + xsiteConnectionLid + "/"+"getJsJSONDataList?alt=json-in-script&callback=";
		//As we will get data for first time, send levels filters to xdaq application
		reparseLogsFile();

		//Validate connection status, pas rester en mode "display polling..."
		hasAttemptedOneConnection = true;
        //Re-enable timer auto-refresh
		refreshTimer.scheduleRepeating(CURRENT_REFRESH_INTERVAL);
        timerIsOn = true;
        //JsonServer has been found
        hasFindJsonServerSource = true;
		//Update general status pannel
		refreshTimerInfoInStatusPannel();
		refreshConnectionInfoInStatusPannel();

      }
      else
      {
        //sinon, c'est pas bon - pas de connexion ou c'est pas un process qui sers du JSON
		//Validate connection status, pas rester en mode "display polling..."
		hasAttemptedOneConnection = true;
        //JsonServer has not been found
        hasFindJsonServerSource = false;
		//Update general status pannel
		refreshConnectionInfoInStatusPannel();
      }

    }
  }	
  );

  //By default, consider that when exiting the asynchronous method the JsonServer has not yet been found
  hasFindJsonServerSource = false;
  //Validate connection status, pas rester en mode "display polling..."
  hasAttemptedOneConnection = true;
  //Update general status pannel
	refreshConnectionInfoInStatusPannel();


}



public void getDataThroughXSiteConnection()
{
//  Window.alert("In main, launching JSON XSiterequest");
  JSONExternalWrapper MyJSONExternalWrapper = new JSONExternalWrapper();
/*
  JSONExternalWrapper.makeJSONRequest("http://cmstkint11.cern.ch:14000/urn:xdaq-application:lid=21/"+"getJsJSONDataList?alt=json-in-script&callback=",
										new JSONExternalWrapper.JSONHandler()
*/



//fileParsingCommand = "DO_REWIND=TRUE";

  JSONExternalWrapper.makeJSONRequest("&" + fileParsingCommand, JSON_URL, new JSONExternalWrapper.JSONHandler()

  {
    public void handleJSON(JavaScriptObject obj)
    {
      JSONObject resp= new JSONObject(obj);
      JSONArray jsonArray = resp.get("Logs").isArray();
         
      if (jsonArray != null)
      {
        updateTable(jsonArray);
      }
      else
      {
        //throw new JSONException();
      }

    }
  }	
  );
}



public void updateRefreshRate()
{


refreshTimer.cancel();
timerIsOn = false;
systemStatusPanel.refreshTimerInfos(this);
CURRENT_REFRESH_INTERVAL = Integer.valueOf(userdefinedRefreshInterval);
USER_DEFINED_REFRESH_INTERVAL = CURRENT_REFRESH_INTERVAL;

refreshTimer.scheduleRepeating(CURRENT_REFRESH_INTERVAL);
timerIsOn = true;
//lastUpdatedLabel.setText("(Update rate : " + CURRENT_REFRESH_INTERVAL/1000 + " seconds) Last update : " + DateTimeFormat.getMediumDateTimeFormat().format(new Date()) + " from data source : " + JSON_URL);
systemStatusPanel.refreshTimeIntervalInfos(this);
systemStatusPanel.refreshTimerInfos(this);



}







public void updateStreamingRefreshRate()
{

Defs.QUICK_REFRESH_INTERVAL = Integer.valueOf(userdefinedStreamingRefreshInterval);
systemStatusPanel.refreshStreamingTimeIntervalInfos(this);

}






public void handleMessagesMaskingForIncomingLog(LogMessage message, DiagTreeItem myIem)
{
//if (myIem.hideInLogsTable == true) {Window.alert("Message must be MASKED");} else Window.alert("Message must be DISPLAYED");
	if (myIem.hideInLogsTable == true) message.showInTable=false;
/*
message.showInTable=false;
if (myIem.hideInLogsTable == false) message.showInTable=true;
*/
}








public int handleMessagesMaskingForExistingLog(DiagTreeItem myIem)
{
	if (myIem.hideInLogsTable == true)
	{
		return(1);
	}
	else return(0);
}


















public boolean isLogViewableInLogsTableAccordingToCriticityMaskingBis(int criticityLevel)
{
//  String criticityLevel = ft.getText(rowCounter, Defs.LEVEL_COL);

  if ( criticityLevel==0) {
		if (controlCriticityPannel.rbTraceChecked == true) { return true; }
		else return false; }
  
  else if ( criticityLevel==1) {
		if (controlCriticityPannel.rbDebugChecked == true) { return true; }
		else return false; }

  else if ( criticityLevel==2) {
		if (controlCriticityPannel.rbInfoChecked == true) { return true; }
		else return false; }

  else if ( criticityLevel==3) {
		if (controlCriticityPannel.rbWarnChecked == true) { return true; }
		else return false; }

  else if ( criticityLevel==4) {
		if (controlCriticityPannel.rbUserinfoChecked == true) { return true; }
		else return false; }

  else if ( criticityLevel==5) {
		if (controlCriticityPannel.rbErrorChecked == true) { return true; }
		else return false; }

  else if ( criticityLevel==6) {
		if (controlCriticityPannel.rbFatalChecked == true) { return true; }
		else return false; }


return true;

}












public boolean isLogViewableInLogsTableAccordingToTreeMaskingBis(String p_machine, String p_port, String p_procname, String p_procinstance)
{

//first treeItem is tracker
for (int i=0; i<errorsTree.getItemCount(); i++)
{
	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
	if ( itemI.treeItemName.equals(Defs.SUBDETECTOR_NAME) )
	{
		//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i));
		if (itemI.hideInLogsTable == true) return false;
		
		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		boolean machineFound = false;
		//for (int j=0; j<errorsTree.getItem(i).getChildCount(); j++)
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			//if ( errorsTree.getItem(i).getChild(j).getText().equals(p_machine) )
			if ( itemJ.treeItemName.equals(p_machine) )
			{
				machineFound = true;
				//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j));
				if (itemJ.hideInLogsTable == true) return false;
				
				//Si on a trouve la sous-branche machine, on parse la branche port
				boolean portFound = false;
				//for (int k=0; k<errorsTree.getItem(i).getChild(j).getChildCount(); k++)
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					//if ( errorsTree.getItem(i).getChild(j).getChild(k).getText().equals(p_port) )
					if ( itemK.treeItemName.equals(p_port) )
					{
						portFound = true;
						//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k));
						if (itemK.hideInLogsTable == true) return false;
						
						//Si on a trouve la sous-branche port, on parse la branche procname
						boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							//if ( errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getText().equals(p_procname) )
							if ( itemL.treeItemName.equals(p_procname) )
							{
								procnameFound = true;
								//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l));
								if (itemL.hideInLogsTable == true) return false;
								
								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									if ( itemM.treeItemName.equals("Instance " + p_procinstance) )
									{
										procinstanceFound = true;
										//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m));										
										if (itemM.hideInLogsTable == true) return false;
									}
								}
							}
						}
					}
				}
			}
		}
	}
}


return true;

}





















public void drawExclusionBoxesInTree()
{
//boolean isViewable = true;
//first treeItem is tracker
for (int i=0; i<errorsTree.getItemCount(); i++)
{
	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
//	if ( itemI.treeItemName.equals(Defs.SUBDETECTOR_NAME) )
//	{
		//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i));
		if (itemI.hideInLogsTable == true)
		{
			//isViewable = false;
			itemI.setStyleName("gwt-TreeItem-Masked-Item");
		}
		else itemI.setStyleName("gwt-TreeItem-Standard-Item");
		
/*
		itemI.setHTML("<span style=\"color: rgb(0, 153, 0);\">" 
		+ "<b>" + itemI.getTreeItemName() 	+ " -- " + "T:" + itemI.getTraceCounter() 
												+ " D:"	+ itemI.getDebugCounter()
												+ " I:"	+ itemI.getInfoCounter()
												+ " W:"	+ itemI.getWarnCounter()
												+ " U:"	+ itemI.getUserinfoCounter()
												+ " E:"	+ itemI.getErrorCounter()
												+ " F:"	+ itemI.getFatalCounter()
												+ "</b>"
												+ "</body>");
*/
		
		
		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		//boolean machineFound = false;
		//for (int j=0; j<errorsTree.getItem(i).getChildCount(); j++)
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			//if ( errorsTree.getItem(i).getChild(j).getText().equals(p_machine) )
			//if ( itemJ.treeItemName.equals(p_machine) )
			//{
				//machineFound = true;
				//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j));
				if (itemJ.hideInLogsTable == true)
				{
					//isViewable = false;
					itemJ.setStyleName("gwt-TreeItem-Masked-Item");
				}
				else itemJ.setStyleName("gwt-TreeItem-Standard-Item");

				
				//Si on a trouve la sous-branche machine, on parse la branche port
				//boolean portFound = false;
				//for (int k=0; k<errorsTree.getItem(i).getChild(j).getChildCount(); k++)
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					//if ( errorsTree.getItem(i).getChild(j).getChild(k).getText().equals(p_port) )
					//if ( itemK.treeItemName.equals(p_port) )
					//{
						//portFound = true;
						//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k));
						if (itemK.hideInLogsTable == true)
						{
							//isViewable = false;
							itemK.setStyleName("gwt-TreeItem-Masked-Item");
						}
						else itemK.setStyleName("gwt-TreeItem-Standard-Item");

						//Si on a trouve la sous-branche port, on parse la branche procname
						//boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							//if ( errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getText().equals(p_procname) )
							//if ( itemL.treeItemName.equals(p_procname) )
							//{
								//procnameFound = true;
								//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l));
								if (itemL.hideInLogsTable == true)
								{
									//isViewable = false;
									itemL.setStyleName("gwt-TreeItem-Masked-Item");
								}
								else itemL.setStyleName("gwt-TreeItem-Standard-Item");

								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								//boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									//if ( itemM.treeItemName.equals("Instance " + p_procinstance) )
									//{
										//procinstanceFound = true;
										//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m));										
										if (itemM.hideInLogsTable == true)
										{
											//isViewable = false;
											itemM.setStyleName("gwt-TreeItem-Masked-Item");
										}
										else itemM.setStyleName("gwt-TreeItem-Standard-Item");
									//}
								}
							//}
						}
					//}
				}
			//}
		}
	//}
}
}



public void redrawFlexTableAccordingToTreeMasking()
{
//Window.alert("I have been called");
	RowFormatter rf = ft.getRowFormatter();
	boolean displayLogFromTree = true;
	boolean displayLogFromPannel = true;

	for (int row=1; row<ft.getRowCount(); row++)
	{
//		displayLogFromTree = isLogViewableInLogsTableAccordingToTreeMasking(ft.getText(row, Defs.MACHINE_COL), ft.getText(row, Defs.PORT_COL), ft.getText(row, Defs.PROCNAME_COL), ft.getText(row, Defs.PROCINST_COL));
//		displayLogFromTree = isLogViewableInLogsTableAccordingToTreeMaskingBis(ft.getText(row, Defs.MACHINE_COL), ft.getText(row, Defs.PORT_COL), ft.getText(row, Defs.PROCNAME_COL), ft.getText(row, Defs.PROCINST_COL));
		displayLogFromTree = isLogViewableInLogsTableAccordingToTreeMaskingBis(ft.getText(row, Defs.MACHINE_COL), ft.getText(row, Defs.PORT_COL), ft.getText(row, Defs.PROCNAME_COL), ft.getText(row, Defs.PROCINST_COL));


//		displayLogFromPannel = isLogViewableInLogsTableAccordingToCriticityMasking(ft.getText(row, Defs.LEVEL_COL));
		displayLogFromPannel = isLogViewableInLogsTableAccordingToCriticityMaskingBis(criticityLevelToInt(ft.getText(row, Defs.LEVEL_COL)));
		if ((displayLogFromTree == true) && (displayLogFromPannel == true))
		{
			rf.setVisible(row, true);
		}
		else
		{
			//Masking Strategy : Do not hide line anymore but delete hidden rows from table
			//rf.setVisible(row, false);
			ft.removeRow(row);
			row--;
			numberOfLogsInTable--;
		}
	}

//Now redraw tree
drawExclusionBoxesInTree();


}




public int criticityLevelToInt(String criticityLevel)
{
  if ( criticityLevel.equals("TRACE")) {return 0;}
  
  else if ( criticityLevel.equals("DEBUG")) {return 1;}

  else if ( criticityLevel.equals("INFO")) {return 2;}

  else if ( criticityLevel.equals("WARN")) {return 3;}

  else if ( criticityLevel.equals("USERINFO")) {return 4;}

  else if ( criticityLevel.equals("ERROR")) {return 5;}

  else if ( criticityLevel.equals("FATAL")) {return 6;}

return -1;
}







public void manageFocusRequest(String machine, String port, String procname, String instance)
{
if (machine.equals(Defs.INIT_TREENODE_VALUE)) {setFocusPropertiesAtNodeLevel0();}
else if (port.equals(Defs.INIT_TREENODE_VALUE)) {setFocusPropertiesAtNodeLevel1(machine);}
else if (procname.equals(Defs.INIT_TREENODE_VALUE)) {setFocusPropertiesAtNodeLevel2(machine, port);}
else if (instance.equals(Defs.INIT_TREENODE_VALUE)) {setFocusPropertiesAtNodeLevel3(machine, port, procname);}
else setFocusPropertiesAtNodeLevel4(machine, port, procname, instance);

}







public void manageShowHideRequest(String machine, String port, String procname, String instance, boolean show)
{
if (machine.equals(Defs.INIT_TREENODE_VALUE)) {setShowHidePropertiesAtNodeLevel0(show);}
else if (port.equals(Defs.INIT_TREENODE_VALUE)) {setShowHidePropertiesAtNodeLevel1(machine, show);}
else if (procname.equals(Defs.INIT_TREENODE_VALUE)) {setShowHidePropertiesAtNodeLevel2(machine, port, show);}
else if (instance.equals(Defs.INIT_TREENODE_VALUE)) {setShowHidePropertiesAtNodeLevel3(machine, port, procname, show);}
else setShowHidePropertiesAtNodeLevel4(machine, port, procname, instance, show);
}








//public void setFocusPropertiesAtNodeLevel0(String p_machine, String p_port, String p_procname, String p_procinstance)
public void setFocusPropertiesAtNodeLevel0()
{
boolean hideNodeWhenDisplayed = true;
boolean showNodeWhenDisplayed = false;

//first treeItem is tracker
for (int i=0; i<errorsTree.getItemCount(); i++)
{
	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
	//if ( itemI.getText().equals(Defs.SUBDETECTOR_NAME) )
	//{
		//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i));
		itemI.hideInLogsTable = showNodeWhenDisplayed;
		itemI.showInLogsTable = !showNodeWhenDisplayed;
		itemI.focusInLogsTable = false;

		
		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		//boolean machineFound = false;
		//for (int j=0; j<errorsTree.getItem(i).getChildCount(); j++)
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			//if ( errorsTree.getItem(i).getChild(j).getText().equals(p_machine) )
			//if ( itemJ.getText().equals(p_machine) )
			//{
				//machineFound = true;
				//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j));
				itemJ.hideInLogsTable = showNodeWhenDisplayed;
				itemJ.showInLogsTable = !showNodeWhenDisplayed;
				itemJ.focusInLogsTable = false;

				//Si on a trouve la sous-branche machine, on parse la branche port
				//boolean portFound = false;
				//for (int k=0; k<errorsTree.getItem(i).getChild(j).getChildCount(); k++)
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					//if ( errorsTree.getItem(i).getChild(j).getChild(k).getText().equals(p_port) )
					//if ( itemK.getText().equals(p_port) )
					//{
						//portFound = true;
						//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k));
						itemK.hideInLogsTable = showNodeWhenDisplayed;
						itemK.showInLogsTable = !showNodeWhenDisplayed;
						itemK.focusInLogsTable = false;

						//Si on a trouve la sous-branche port, on parse la branche procname
						//boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							//if ( errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getText().equals(p_procname) )
							//if ( itemL.getText().equals(p_procname) )
							//{
								//procnameFound = true;
								//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l));
								itemL.hideInLogsTable = showNodeWhenDisplayed;
								itemL.showInLogsTable = !showNodeWhenDisplayed;
								itemL.focusInLogsTable = false;

								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								//boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									//if ( itemM.getText().equals(p_procinstance) )
									//{
										//procinstanceFound = true;
										//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m));										
										itemM.hideInLogsTable = showNodeWhenDisplayed;
										itemM.showInLogsTable = !showNodeWhenDisplayed;
										itemM.focusInLogsTable = false;

									//}
								}
							//}
						}
					//}
				}
			//}
		}
	//}
}




}














//public void setFocusPropertiesAtNodeLevel0(String p_machine, String p_port, String p_procname, String p_procinstance)
public void setFocusPropertiesAtNodeLevel1(String p_machine)
{

boolean hideNodeWhenDisplayed = true;
boolean showNodeWhenDisplayed = false;
boolean nodeDisplayValueToUse;

//first treeItem is tracker
for (int i=0; i<errorsTree.getItemCount(); i++)
{
	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
	//if ( itemI.getText().equals(Defs.SUBDETECTOR_NAME) )
	//{
		//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i));
		nodeDisplayValueToUse = showNodeWhenDisplayed;
		itemI.hideInLogsTable = nodeDisplayValueToUse;
		itemI.showInLogsTable = !nodeDisplayValueToUse;
		itemI.focusInLogsTable = false;
		
		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		//boolean machineFound = false;
		//for (int j=0; j<errorsTree.getItem(i).getChildCount(); j++)
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			//if ( errorsTree.getItem(i).getChild(j).getText().equals(p_machine) )

			if ( itemJ.treeItemName.equals(p_machine) )
			{
				nodeDisplayValueToUse = showNodeWhenDisplayed;
			}
			else nodeDisplayValueToUse = hideNodeWhenDisplayed;
				//machineFound = true;
				//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j));
				itemJ.hideInLogsTable = nodeDisplayValueToUse;
				itemJ.showInLogsTable = !nodeDisplayValueToUse;
				itemJ.focusInLogsTable = false;

				//Si on a trouve la sous-branche machine, on parse la branche port
				//boolean portFound = false;
				//for (int k=0; k<errorsTree.getItem(i).getChild(j).getChildCount(); k++)
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					//if ( errorsTree.getItem(i).getChild(j).getChild(k).getText().equals(p_port) )
					//if ( itemK.getText().equals(p_port) )
					//{
						//portFound = true;
						//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k));
						itemK.hideInLogsTable = nodeDisplayValueToUse;
						itemK.showInLogsTable = !nodeDisplayValueToUse;
						itemK.focusInLogsTable = false;

						//Si on a trouve la sous-branche port, on parse la branche procname
						//boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							//if ( errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getText().equals(p_procname) )
							//if ( itemL.getText().equals(p_procname) )
							//{
								//procnameFound = true;
								//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l));
								itemL.hideInLogsTable = nodeDisplayValueToUse;
								itemL.showInLogsTable = !nodeDisplayValueToUse;
								itemL.focusInLogsTable = false;

								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								//boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									//if ( itemM.getText().equals(p_procinstance) )
									//{
										//procinstanceFound = true;
										//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m));										
										itemM.hideInLogsTable = nodeDisplayValueToUse;
										itemM.showInLogsTable = !nodeDisplayValueToUse;
										itemM.focusInLogsTable = false;

									//}
								}
							//}
						}
					//}
				}
			//}
		}
	//}
}

}







//public void setFocusPropertiesAtNodeLevel0(String p_machine, String p_port, String p_procname, String p_procinstance)
public void setFocusPropertiesAtNodeLevel2(String p_machine, String p_port)
{

boolean hideNodeWhenDisplayed = true;
boolean showNodeWhenDisplayed = false;
boolean nodeDisplayValueToUse;

//first treeItem is tracker
for (int i=0; i<errorsTree.getItemCount(); i++)
{
	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
	//if ( itemI.getText().equals(Defs.SUBDETECTOR_NAME) )
	//{
		//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i));
		nodeDisplayValueToUse = showNodeWhenDisplayed;
		itemI.hideInLogsTable = nodeDisplayValueToUse;
		itemI.showInLogsTable = !nodeDisplayValueToUse;
		itemI.focusInLogsTable = false;
		
		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		//boolean machineFound = false;
		//for (int j=0; j<errorsTree.getItem(i).getChildCount(); j++)
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			//if ( errorsTree.getItem(i).getChild(j).getText().equals(p_machine) )

			if ( itemJ.treeItemName.equals(p_machine) )
			{
				nodeDisplayValueToUse = showNodeWhenDisplayed;
			}
			else nodeDisplayValueToUse = hideNodeWhenDisplayed;
				//machineFound = true;
				//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j));
				itemJ.hideInLogsTable = nodeDisplayValueToUse;
				itemJ.showInLogsTable = !nodeDisplayValueToUse;
				itemJ.focusInLogsTable = false;

				//Si on a trouve la sous-branche machine, on parse la branche port
				//boolean portFound = false;
				//for (int k=0; k<errorsTree.getItem(i).getChild(j).getChildCount(); k++)
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					//if ( errorsTree.getItem(i).getChild(j).getChild(k).getText().equals(p_port) )
					//if ( itemK.getText().equals(p_port) )

					if ( ( itemK.treeItemName.equals(p_port)  ) && ( itemJ.treeItemName.equals(p_machine) ) )
					{
						nodeDisplayValueToUse = showNodeWhenDisplayed;
					}
					else nodeDisplayValueToUse = hideNodeWhenDisplayed;

					//{
						//portFound = true;
						//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k));
						itemK.hideInLogsTable = nodeDisplayValueToUse;
						itemK.showInLogsTable = !nodeDisplayValueToUse;
						itemK.focusInLogsTable = false;

						//Si on a trouve la sous-branche port, on parse la branche procname
						//boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							//if ( errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getText().equals(p_procname) )
							//if ( itemL.getText().equals(p_procname) )
							//{
								//procnameFound = true;
								//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l));
								itemL.hideInLogsTable = nodeDisplayValueToUse;
								itemL.showInLogsTable = !nodeDisplayValueToUse;
								itemL.focusInLogsTable = false;

								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								//boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									//if ( itemM.getText().equals(p_procinstance) )
									//{
										//procinstanceFound = true;
										//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m));										
										itemM.hideInLogsTable = nodeDisplayValueToUse;
										itemM.showInLogsTable = !nodeDisplayValueToUse;
										itemM.focusInLogsTable = false;

									//}
								}
							//}
						}
					//}
				}
			//}
		}
	//}
}

}









//public void setFocusPropertiesAtNodeLevel0(String p_machine, String p_port, String p_procname, String p_procinstance)
public void setFocusPropertiesAtNodeLevel3(String p_machine, String p_port, String p_procname)
{

boolean hideNodeWhenDisplayed = true;
boolean showNodeWhenDisplayed = false;
boolean nodeDisplayValueToUse;

//first treeItem is tracker
for (int i=0; i<errorsTree.getItemCount(); i++)
{
	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
	//if ( itemI.getText().equals(Defs.SUBDETECTOR_NAME) )
	//{
		//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i));
		nodeDisplayValueToUse = showNodeWhenDisplayed;
		itemI.hideInLogsTable = nodeDisplayValueToUse;
		itemI.showInLogsTable = !nodeDisplayValueToUse;
		itemI.focusInLogsTable = false;
		
		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		//boolean machineFound = false;
		//for (int j=0; j<errorsTree.getItem(i).getChildCount(); j++)
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			//if ( errorsTree.getItem(i).getChild(j).getText().equals(p_machine) )

			if ( itemJ.treeItemName.equals(p_machine) )
			{
				nodeDisplayValueToUse = showNodeWhenDisplayed;
			}
			else nodeDisplayValueToUse = hideNodeWhenDisplayed;
				//machineFound = true;
				//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j));
				itemJ.hideInLogsTable = nodeDisplayValueToUse;
				itemJ.showInLogsTable = !nodeDisplayValueToUse;
				itemJ.focusInLogsTable = false;

				//Si on a trouve la sous-branche machine, on parse la branche port
				//boolean portFound = false;
				//for (int k=0; k<errorsTree.getItem(i).getChild(j).getChildCount(); k++)
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					//if ( errorsTree.getItem(i).getChild(j).getChild(k).getText().equals(p_port) )
					//if ( itemK.getText().equals(p_port) )

					if ( ( itemK.treeItemName.equals(p_port)  ) && ( itemJ.treeItemName.equals(p_machine) ) )
					{
						nodeDisplayValueToUse = showNodeWhenDisplayed;
					}
					else nodeDisplayValueToUse = hideNodeWhenDisplayed;

					//{
						//portFound = true;
						//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k));
						itemK.hideInLogsTable = nodeDisplayValueToUse;
						itemK.showInLogsTable = !nodeDisplayValueToUse;
						itemK.focusInLogsTable = false;

						//Si on a trouve la sous-branche port, on parse la branche procname
						//boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							//if ( errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getText().equals(p_procname) )
							//if ( itemL.getText().equals(p_procname) )

					if ( ( itemL.treeItemName.equals(p_procname) ) && ( itemK.treeItemName.equals(p_port)  ) && ( itemJ.treeItemName.equals(p_machine) ) )
					{
						nodeDisplayValueToUse = showNodeWhenDisplayed;
					}
					else nodeDisplayValueToUse = hideNodeWhenDisplayed;

							//{
								//procnameFound = true;
								//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l));
								itemL.hideInLogsTable = nodeDisplayValueToUse;
								itemL.showInLogsTable = !nodeDisplayValueToUse;
								itemL.focusInLogsTable = false;

								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								//boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									//if ( itemM.getText().equals(p_procinstance) )
									//{
										//procinstanceFound = true;
										//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m));										
										itemM.hideInLogsTable = nodeDisplayValueToUse;
										itemM.showInLogsTable = !nodeDisplayValueToUse;
										itemM.focusInLogsTable = false;

									//}
								}
							//}
						}
					//}
				}
			//}
		}
	//}
}

}












public void setFocusPropertiesAtNodeLevel4(String p_machine, String p_port, String p_procname, String p_procinstance)
//public void setFocusPropertiesAtNodeLevel3(String p_machine, String p_port, String p_procname)
{

boolean hideNodeWhenDisplayed = true;
boolean showNodeWhenDisplayed = false;
boolean nodeDisplayValueToUse;

//first treeItem is tracker
for (int i=0; i<errorsTree.getItemCount(); i++)
{
	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
	//if ( itemI.getText().equals(Defs.SUBDETECTOR_NAME) )
	//{
		//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i));
		nodeDisplayValueToUse = showNodeWhenDisplayed;
		itemI.hideInLogsTable = nodeDisplayValueToUse;
		itemI.showInLogsTable = !nodeDisplayValueToUse;
		itemI.focusInLogsTable = false;

		
		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		//boolean machineFound = false;
		//for (int j=0; j<errorsTree.getItem(i).getChildCount(); j++)
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			//if ( errorsTree.getItem(i).getChild(j).getText().equals(p_machine) )

			if ( itemJ.treeItemName.equals(p_machine) )
			{
				nodeDisplayValueToUse = showNodeWhenDisplayed;
			}
			else nodeDisplayValueToUse = hideNodeWhenDisplayed;
				//machineFound = true;
				//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j));
				itemJ.hideInLogsTable = nodeDisplayValueToUse;
				itemJ.showInLogsTable = !nodeDisplayValueToUse;
				itemJ.focusInLogsTable = false;

				//Si on a trouve la sous-branche machine, on parse la branche port
				//boolean portFound = false;
				//for (int k=0; k<errorsTree.getItem(i).getChild(j).getChildCount(); k++)
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					//if ( errorsTree.getItem(i).getChild(j).getChild(k).getText().equals(p_port) )
					//if ( itemK.getText().equals(p_port) )

					if ( ( itemK.treeItemName.equals(p_port)  ) && ( itemJ.treeItemName.equals(p_machine) ) )
					{
						nodeDisplayValueToUse = showNodeWhenDisplayed;
					}
					else nodeDisplayValueToUse = hideNodeWhenDisplayed;

					//{
						//portFound = true;
						//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k));
						itemK.hideInLogsTable = nodeDisplayValueToUse;
						itemK.showInLogsTable = !nodeDisplayValueToUse;
						itemK.focusInLogsTable = false;

						//Si on a trouve la sous-branche port, on parse la branche procname
						//boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							//if ( errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getText().equals(p_procname) )
							//if ( itemL.getText().equals(p_procname) )

					if ( ( itemL.treeItemName.equals(p_procname) ) && ( itemK.treeItemName.equals(p_port)  ) && ( itemJ.treeItemName.equals(p_machine) ) )
					{
						nodeDisplayValueToUse = showNodeWhenDisplayed;
					}
					else nodeDisplayValueToUse = hideNodeWhenDisplayed;

							//{
								//procnameFound = true;
								//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l));
								itemL.hideInLogsTable = nodeDisplayValueToUse;
								itemL.showInLogsTable = !nodeDisplayValueToUse;
								itemL.focusInLogsTable = false;

								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								//boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									//if ( itemM.getText().equals(p_procinstance) )
									//{
					if ( ( itemM.treeItemName.equals("Instance " + p_procinstance) ) && ( itemL.treeItemName.equals(p_procname) ) && ( itemK.treeItemName.equals(p_port)  ) && ( itemJ.treeItemName.equals(p_machine) ) )
					{
						nodeDisplayValueToUse = showNodeWhenDisplayed;
					}
					else nodeDisplayValueToUse = hideNodeWhenDisplayed;

										//procinstanceFound = true;
										//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m));										
										itemM.hideInLogsTable = nodeDisplayValueToUse;
										itemM.showInLogsTable = !nodeDisplayValueToUse;
										itemM.focusInLogsTable = false;

									//}
								}
							//}
						}
					//}
				}
			//}
		}
	//}
}

}



























































































//public void setFocusPropertiesAtNodeLevel0(String p_machine, String p_port, String p_procname, String p_procinstance)
public void setShowHidePropertiesAtNodeLevel0(boolean show)
{
boolean hideNodeWhenDisplayed = true;
boolean showNodeWhenDisplayed = false;
boolean nodeDisplayValueToUse;


nodeDisplayValueToUse = !show;

//first treeItem is tracker
for (int i=0; i<errorsTree.getItemCount(); i++)
{
	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
	//if ( itemI.getText().equals(Defs.SUBDETECTOR_NAME) )
	//{
		//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i));
		itemI.hideInLogsTable = nodeDisplayValueToUse;
		itemI.showInLogsTable = !nodeDisplayValueToUse;
		itemI.focusInLogsTable = false;

		
		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		//boolean machineFound = false;
		//for (int j=0; j<errorsTree.getItem(i).getChildCount(); j++)
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			//if ( errorsTree.getItem(i).getChild(j).getText().equals(p_machine) )
			//if ( itemJ.getText().equals(p_machine) )
			//{

				//machineFound = true;
				//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j));
				itemJ.hideInLogsTable = nodeDisplayValueToUse;
				itemJ.showInLogsTable = !nodeDisplayValueToUse;
				itemJ.focusInLogsTable = false;

				
				//Si on a trouve la sous-branche machine, on parse la branche port
				//boolean portFound = false;
				//for (int k=0; k<errorsTree.getItem(i).getChild(j).getChildCount(); k++)
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					//if ( errorsTree.getItem(i).getChild(j).getChild(k).getText().equals(p_port) )
					//if ( itemK.getText().equals(p_port) )
					//{
						//portFound = true;
						//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k));
						itemK.hideInLogsTable = nodeDisplayValueToUse;
						itemK.showInLogsTable = !nodeDisplayValueToUse;
						itemK.focusInLogsTable = false;

						
						//Si on a trouve la sous-branche port, on parse la branche procname
						//boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							//if ( errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getText().equals(p_procname) )
							//if ( itemL.getText().equals(p_procname) )
							//{
								//procnameFound = true;
								//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l));
								itemL.hideInLogsTable = nodeDisplayValueToUse;
								itemL.showInLogsTable = !nodeDisplayValueToUse;
								itemL.focusInLogsTable = false;

								
								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								//boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									//if ( itemM.getText().equals(p_procinstance) )
									//{
										//procinstanceFound = true;
										//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m));										
										itemM.hideInLogsTable = nodeDisplayValueToUse;
										itemM.showInLogsTable = !nodeDisplayValueToUse;
										itemM.focusInLogsTable = false;

									//}
								}
							//}
						}
					//}
				}
			//}
		}
	//}
}




}














//public void setFocusPropertiesAtNodeLevel0(String p_machine, String p_port, String p_procname, String p_procinstance)
public void setShowHidePropertiesAtNodeLevel1(String p_machine, boolean show)
{

boolean hideNodeWhenDisplayed = true;
boolean showNodeWhenDisplayed = false;
boolean nodeDisplayValueToUse;

//first treeItem is tracker
for (int i=0; i<errorsTree.getItemCount(); i++)
{
	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
	//if ( itemI.getText().equals(Defs.SUBDETECTOR_NAME) )
	//{
		//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i));
		//itemI.hideInLogsTable = showNodeWhenDisplayed;
		
		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		//boolean machineFound = false;
		//for (int j=0; j<errorsTree.getItem(i).getChildCount(); j++)
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			//if ( errorsTree.getItem(i).getChild(j).getText().equals(p_machine) )

			if ( itemJ.treeItemName.equals(p_machine) )
			{
				nodeDisplayValueToUse = !show;
				itemJ.hideInLogsTable = nodeDisplayValueToUse;
				itemJ.showInLogsTable = !nodeDisplayValueToUse;
				itemJ.focusInLogsTable = false;

			
				//If the command is SHOW then set previous tree path to viewable also
				if (show == true)
				{
					itemI.hideInLogsTable = nodeDisplayValueToUse;
					itemI.showInLogsTable = !nodeDisplayValueToUse;
					itemI.focusInLogsTable = false;
				}

				
				
			//else nodeDisplayValueToUse = hideNodeWhenDisplayed;
				//machineFound = true;
				//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j));
				//itemJ.hideInLogsTable = nodeDisplayValueToUse;
				
				//Si on a trouve la sous-branche machine, on parse la branche port
				//boolean portFound = false;
				//for (int k=0; k<errorsTree.getItem(i).getChild(j).getChildCount(); k++)
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					//if ( errorsTree.getItem(i).getChild(j).getChild(k).getText().equals(p_port) )
					//if ( itemK.getText().equals(p_port) )
					//{
						//portFound = true;
						//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k));
						itemK.hideInLogsTable = nodeDisplayValueToUse;
						itemK.showInLogsTable = !nodeDisplayValueToUse;
						itemK.focusInLogsTable = false;

						
						//Si on a trouve la sous-branche port, on parse la branche procname
						//boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							//if ( errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getText().equals(p_procname) )
							//if ( itemL.getText().equals(p_procname) )
							//{
								//procnameFound = true;
								//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l));
								itemL.hideInLogsTable = nodeDisplayValueToUse;
								itemL.showInLogsTable = !nodeDisplayValueToUse;
								itemL.focusInLogsTable = false;

								
								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								//boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									//if ( itemM.getText().equals(p_procinstance) )
									//{
										//procinstanceFound = true;
										//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m));										
										itemM.hideInLogsTable = nodeDisplayValueToUse;
										itemM.showInLogsTable = !nodeDisplayValueToUse;
										itemM.focusInLogsTable = false;

									//}
								}
							//}
						}
					//}
				}
			}//END OF IF LOOPED
		}
	//}
}

}







//public void setFocusPropertiesAtNodeLevel0(String p_machine, String p_port, String p_procname, String p_procinstance)
public void setShowHidePropertiesAtNodeLevel2(String p_machine, String p_port, boolean show)
{

boolean hideNodeWhenDisplayed = true;
boolean showNodeWhenDisplayed = false;
boolean nodeDisplayValueToUse;

//first treeItem is tracker
for (int i=0; i<errorsTree.getItemCount(); i++)
{
	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
	//if ( itemI.getText().equals(Defs.SUBDETECTOR_NAME) )
	//{
		//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i));
		//itemI.hideInLogsTable = showNodeWhenDisplayed;
		
		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		//boolean machineFound = false;
		//for (int j=0; j<errorsTree.getItem(i).getChildCount(); j++)
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			//if ( errorsTree.getItem(i).getChild(j).getText().equals(p_machine) )
/*
			if ( itemJ.getText().equals(p_machine) )
			{
				nodeDisplayValueToUse = showNodeWhenDisplayed;
			}
			else nodeDisplayValueToUse = hideNodeWhenDisplayed;
*/
				//machineFound = true;
				//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j));
				//itemJ.hideInLogsTable = nodeDisplayValueToUse;
				
				//Si on a trouve la sous-branche machine, on parse la branche port
				//boolean portFound = false;
				//for (int k=0; k<errorsTree.getItem(i).getChild(j).getChildCount(); k++)
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					//if ( errorsTree.getItem(i).getChild(j).getChild(k).getText().equals(p_port) )
					//if ( itemK.getText().equals(p_port) )

					if ( ( itemK.treeItemName.equals(p_port)  ) && ( itemJ.treeItemName.equals(p_machine) ) )
					{
						nodeDisplayValueToUse = !show;

					//{
						//portFound = true;
						//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k));
						itemK.hideInLogsTable = nodeDisplayValueToUse;
						itemK.showInLogsTable = !nodeDisplayValueToUse;
						itemK.focusInLogsTable = false;

						
						//If the command is SHOW then set previous tree path to viewable also
						if (show == true)
						{
							itemI.hideInLogsTable = nodeDisplayValueToUse;
							itemI.showInLogsTable = !nodeDisplayValueToUse;
							itemI.focusInLogsTable = false;

							itemJ.hideInLogsTable = nodeDisplayValueToUse;
							itemJ.showInLogsTable = !nodeDisplayValueToUse;
							itemJ.focusInLogsTable = false;

						}

						
						//Si on a trouve la sous-branche port, on parse la branche procname
						//boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							//if ( errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getText().equals(p_procname) )
							//if ( itemL.getText().equals(p_procname) )
							//{
								//procnameFound = true;
								//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l));
								itemL.hideInLogsTable = nodeDisplayValueToUse;
								itemL.showInLogsTable = !nodeDisplayValueToUse;
								itemL.focusInLogsTable = false;

								
								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								//boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									//if ( itemM.getText().equals(p_procinstance) )
									//{
										//procinstanceFound = true;
										//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m));										
										itemM.hideInLogsTable = nodeDisplayValueToUse;
										itemM.showInLogsTable = !nodeDisplayValueToUse;
										itemM.focusInLogsTable = false;

									//}
								}
							//}
						}
					}//END OF IF LLOOPED
				}
			//}
		}
	//}
}

}









//public void setFocusPropertiesAtNodeLevel0(String p_machine, String p_port, String p_procname, String p_procinstance)
public void setShowHidePropertiesAtNodeLevel3(String p_machine, String p_port, String p_procname, boolean show)
{

boolean hideNodeWhenDisplayed = true;
boolean showNodeWhenDisplayed = false;
boolean nodeDisplayValueToUse;

//first treeItem is tracker
for (int i=0; i<errorsTree.getItemCount(); i++)
{
	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
	//if ( itemI.getText().equals(Defs.SUBDETECTOR_NAME) )
	//{
		//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i));
		//itemI.hideInLogsTable = showNodeWhenDisplayed;
		
		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		//boolean machineFound = false;
		//for (int j=0; j<errorsTree.getItem(i).getChildCount(); j++)
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			//if ( errorsTree.getItem(i).getChild(j).getText().equals(p_machine) )
/*
			if ( itemJ.getText().equals(p_machine) )
			{
				nodeDisplayValueToUse = showNodeWhenDisplayed;
			}
			else nodeDisplayValueToUse = hideNodeWhenDisplayed;
*/
				//machineFound = true;
				//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j));
				//itemJ.hideInLogsTable = nodeDisplayValueToUse;
				
				//Si on a trouve la sous-branche machine, on parse la branche port
				//boolean portFound = false;
				//for (int k=0; k<errorsTree.getItem(i).getChild(j).getChildCount(); k++)
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					//if ( errorsTree.getItem(i).getChild(j).getChild(k).getText().equals(p_port) )
					//if ( itemK.getText().equals(p_port) )
/*
					if ( ( itemK.getText().equals(p_port)  ) && ( itemJ.getText().equals(p_machine) ) )
					{
						nodeDisplayValueToUse = showNodeWhenDisplayed;
					}
					else nodeDisplayValueToUse = hideNodeWhenDisplayed;
*/
					//{
						//portFound = true;
						//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k));
						//itemK.hideInLogsTable = nodeDisplayValueToUse;
						
						//Si on a trouve la sous-branche port, on parse la branche procname
						//boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							//if ( errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getText().equals(p_procname) )
							//if ( itemL.getText().equals(p_procname) )

					if ( ( itemL.treeItemName.equals(p_procname) ) && ( itemK.treeItemName.equals(p_port)  ) && ( itemJ.treeItemName.equals(p_machine) ) )
					{
						nodeDisplayValueToUse = !show;

							//{
								//procnameFound = true;
								//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l));
								itemL.hideInLogsTable = nodeDisplayValueToUse;
								itemL.showInLogsTable = !nodeDisplayValueToUse;
								itemL.focusInLogsTable = false;


								//If the command is SHOW then set previous tree path to viewable also
								if (show == true)
								{
									itemI.hideInLogsTable = nodeDisplayValueToUse;
									itemI.showInLogsTable = !nodeDisplayValueToUse;
									itemI.focusInLogsTable = false;
									
									itemJ.hideInLogsTable = nodeDisplayValueToUse;
									itemJ.showInLogsTable = !nodeDisplayValueToUse;
									itemJ.focusInLogsTable = false;

									itemK.hideInLogsTable = nodeDisplayValueToUse;
									itemK.showInLogsTable = !nodeDisplayValueToUse;
									itemK.focusInLogsTable = false;

								}



								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								//boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									//if ( itemM.getText().equals(p_procinstance) )
									//{
										//procinstanceFound = true;
										//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m));										
										itemM.hideInLogsTable = nodeDisplayValueToUse;
										itemM.showInLogsTable = !nodeDisplayValueToUse;
										itemM.focusInLogsTable = false;

									//}
								}
							//}
						}
					}//END OF IF LOOPED
				}
			//}
		}
	//}
}

}










public void setShowHidePropertiesAtNodeLevel4(String p_machine, String p_port, String p_procname, String p_procinstance, boolean show)
//public void setFocusPropertiesAtNodeLevel3(String p_machine, String p_port, String p_procname)
{

boolean hideNodeWhenDisplayed = true;
boolean showNodeWhenDisplayed = false;
boolean nodeDisplayValueToUse;

//first treeItem is tracker
for (int i=0; i<errorsTree.getItemCount(); i++)
{
	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
	//if ( itemI.getText().equals(Defs.SUBDETECTOR_NAME) )
	//{
		//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i));
		//itemI.hideInLogsTable = showNodeWhenDisplayed;
		
		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		//boolean machineFound = false;
		//for (int j=0; j<errorsTree.getItem(i).getChildCount(); j++)
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			//if ( errorsTree.getItem(i).getChild(j).getText().equals(p_machine) )
/*
			if ( itemJ.getText().equals(p_machine) )
			{
				nodeDisplayValueToUse = showNodeWhenDisplayed;
			}
			else nodeDisplayValueToUse = hideNodeWhenDisplayed;
*/
				//machineFound = true;
				//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j));
				//itemJ.hideInLogsTable = nodeDisplayValueToUse;
				
				//Si on a trouve la sous-branche machine, on parse la branche port
				//boolean portFound = false;
				//for (int k=0; k<errorsTree.getItem(i).getChild(j).getChildCount(); k++)
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					//if ( errorsTree.getItem(i).getChild(j).getChild(k).getText().equals(p_port) )
					//if ( itemK.getText().equals(p_port) )
/*
					if ( ( itemK.getText().equals(p_port)  ) && ( itemJ.getText().equals(p_machine) ) )
					{
						nodeDisplayValueToUse = showNodeWhenDisplayed;
					}
					else nodeDisplayValueToUse = hideNodeWhenDisplayed;
*/
					//{
						//portFound = true;
						//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k));
						//itemK.hideInLogsTable = nodeDisplayValueToUse;
						
						//Si on a trouve la sous-branche port, on parse la branche procname
						//boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							//if ( errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getText().equals(p_procname) )
							//if ( itemL.getText().equals(p_procname) )
/*
					if ( ( itemL.getText().equals(p_procname) ) && ( itemK.getText().equals(p_port)  ) && ( itemJ.getText().equals(p_machine) ) )
					{
						nodeDisplayValueToUse = showNodeWhenDisplayed;
					}
					else nodeDisplayValueToUse = hideNodeWhenDisplayed;
*/
							//{
								//procnameFound = true;
								//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l));
								//itemL.hideInLogsTable = nodeDisplayValueToUse;
								
								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								//boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									//if ( itemM.getText().equals(p_procinstance) )
									//{
									if ( ( itemM.treeItemName.equals("Instance " + p_procinstance) ) && ( itemL.treeItemName.equals(p_procname) ) && ( itemK.treeItemName.equals(p_port)  ) && ( itemJ.treeItemName.equals(p_machine) ) )
									{
										nodeDisplayValueToUse = !show;

										//procinstanceFound = true;
										//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m));										
										itemM.hideInLogsTable = nodeDisplayValueToUse;
										itemM.showInLogsTable = !nodeDisplayValueToUse;
										itemM.focusInLogsTable = false;

										//If the command is SHOW then set previous tree path to viewable also
										if (show == true)
										{
											itemI.hideInLogsTable = nodeDisplayValueToUse;
											itemI.showInLogsTable = !nodeDisplayValueToUse;
											itemI.focusInLogsTable = false;

											itemJ.hideInLogsTable = nodeDisplayValueToUse;
											itemJ.showInLogsTable = !nodeDisplayValueToUse;
											itemJ.focusInLogsTable = false;
												
											itemK.hideInLogsTable = nodeDisplayValueToUse;
											itemK.showInLogsTable = !nodeDisplayValueToUse;
											itemK.focusInLogsTable = false;

											itemL.hideInLogsTable = nodeDisplayValueToUse;
											itemL.showInLogsTable = !nodeDisplayValueToUse;
											itemL.focusInLogsTable = false;

										}


									}//END OF IF LLOOPED
								}
							//}
						}
					//}
				}
			//}
		}
	//}
}

}

















public boolean cleanupErrorTreeButKeepFiltersActivated()
{

//first treeItem is tracker
for (int i=0; i<errorsTree.getItemCount(); i++)
{
	DiagTreeItem itemI = (DiagTreeItem)errorsTree.getItem(i);
	resetTreeItemCounters(itemI);
	//if ( itemI.treeItemName.equals(Defs.SUBDETECTOR_NAME) )
	//{
		//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i));
		//if (itemI.hideInLogsTable == true) return false;
		
		//Si on a trouve la sous-branche Tracker, on parse la branche machines
		//boolean machineFound = false;
		//for (int j=0; j<errorsTree.getItem(i).getChildCount(); j++)
		for (int j=0; j<itemI.getChildCount(); j++)
		{
			DiagTreeItem itemJ = (DiagTreeItem)itemI.getChild(j);
			resetTreeItemCounters(itemJ);
			//if ( errorsTree.getItem(i).getChild(j).getText().equals(p_machine) )
			//if ( itemJ.treeItemName.equals(p_machine) )
			//{
				//machineFound = true;
				//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j));
				//if (itemJ.hideInLogsTable == true) return false;
				
				//Si on a trouve la sous-branche machine, on parse la branche port
				//boolean portFound = false;
				//for (int k=0; k<errorsTree.getItem(i).getChild(j).getChildCount(); k++)
				for (int k=0; k<itemJ.getChildCount(); k++)
				{
					DiagTreeItem itemK = (DiagTreeItem)itemJ.getChild(k);
					resetTreeItemCounters(itemK);
					//if ( errorsTree.getItem(i).getChild(j).getChild(k).getText().equals(p_port) )
					//if ( itemK.treeItemName.equals(p_port) )
					//{
						//portFound = true;
						//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k));
						//if (itemK.hideInLogsTable == true) return false;
						
						//Si on a trouve la sous-branche port, on parse la branche procname
						//boolean procnameFound = false;
						for (int l=0; l<itemK.getChildCount(); l++)
						{
							DiagTreeItem itemL = (DiagTreeItem)itemK.getChild(l);
							resetTreeItemCounters(itemL);
							//if ( errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getText().equals(p_procname) )
							//if ( itemL.treeItemName.equals(p_procname) )
							//{
								//procnameFound = true;
								//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l));
								//if (itemL.hideInLogsTable == true) return false;
								
								//Si on a trouve la sous-branche procname, on parse la branche procinstance
								//boolean procinstanceFound = false;
								for (int m=0; m<itemL.getChildCount(); m++)
								{
									DiagTreeItem itemM = (DiagTreeItem)itemL.getChild(m);
									resetTreeItemCounters(itemM);
									//if ( itemM.treeItemName.equals("Instance " + p_procinstance) )
									//{
										//procinstanceFound = true;
										//isViewable = isViewable + handleMessagesMaskingForExistingLog((DiagTreeItem)errorsTree.getItem(i).getChild(j).getChild(k).getChild(l).getChild(m));										
										//if (itemM.hideInLogsTable == true) return false;
									//}
								}
							//}
						}
					//}
				}
			//}
		}
	//}
}


return true;

}






public void resetTreeItemCounters(DiagTreeItem lclItem)
{
	lclItem.setTraceCounter(0);
	lclItem.setDebugCounter(0);
	lclItem.setInfoCounter(0);
	lclItem.setWarnCounter(0);
	lclItem.setUserinfoCounter(0);
	lclItem.setErrorCounter(0);
	lclItem.setFatalCounter(0);
}







//HWXDEPS
public void getHwDependancies()
{
 String url = "http://" + Window.Location.getHost() + "/urn:xdaq-application:lid=" + xdaqServerLid + "/getFedCrossedHardwareInfos";


if (isRunningXsiteScript == false)
{

//  url = url + "?" + fileParsingCommand;  
//URL must be modified here to embedd all the fec related informations
  url = URL.encode(url);


  RequestBuilder builder = new RequestBuilder(RequestBuilder.GET, url);


  
  try {
    Request request = builder.sendRequest(null, new RequestCallback() {
      public void onError(Request request, Throwable exception) {
         //displayError("Couldn't retrieve JSON 1");         
      }

      public void onResponseReceived(Request request, Response response) {
        if (200 == response.getStatusCode()) {

          try {
            // parse the response text into JSON
            JSONValue jsonValue = JSONParser.parse(response.getText());
            JSONArray jsonArray = jsonValue.isArray();
            
            if (jsonArray != null)
			{
              			//updateTable(jsonArray);
				//Update crossed array here
            		}
			else
			{
				//throw new JSONException();
			}
          } catch (JSONException e) {
            //displayError("Could not parse JSON -- " + response.getText());
          }
        } else {
          //displayError("Couldn't retrieve JSON 2 (" + response.getStatusText() + ")");
        }
      }       
    });
  } catch (RequestException e) {
    //displayError("Couldn't retrieve JSON 3 - " + e.getMessage());         
  }

	//fileParsingCommand = "";

}//end of condition on xdaq scriting
else
{
//fileParsingCommand = "LOGS_BURST_LENGTH=" + logsBurstLength;

	//getDataThroughXSiteConnection();
	//fileParsingCommand = "";
	getCrossedHwInfosThroughXSiteConnection();
}


}



public void getCrossedHwInfosThroughXSiteConnection()
{

String lclUrl = "http://" + xsiteConnectionUrl + "/urn:xdaq-application:lid=" + xsiteConnectionLid + "/"+"getJsFedCrossedHardwareInfos?alt=json-in-script&callback=";

//  Window.alert("In main, launching JSON XSiterequest");
  JSONExternalWrapper MyJSONExternalWrapper = new JSONExternalWrapper();
/*
  JSONExternalWrapper.makeJSONRequest("http://cmstkint11.cern.ch:14000/urn:xdaq-application:lid=21/"+"getJsJSONDataList?alt=json-in-script&callback=",
										new JSONExternalWrapper.JSONHandler()
*/



//fileParsingCommand = "DO_REWIND=TRUE";

//  JSONExternalWrapper.makeJSONHwInfoRequest("&" + fileParsingCommand, lclUrl, new JSONExternalWrapper.JSONHwInfoHandler()
  JSONExternalWrapper.makeJSONHwInfoRequest("", lclUrl, new JSONExternalWrapper.JSONHwInfoHandler()

  {
    public void handleJSONHwInfo(JavaScriptObject obj)
    {
      JSONObject resp= new JSONObject(obj);
      JSONArray jsonArray = resp.get("HwInfo").isArray();
         
      if (jsonArray != null)
      {
        //updateTable(jsonArray);
	//Update crossed array here
      }
      else
      {
        //throw new JSONException();
      }

    }
  }	
  );
}










}//END OF CLASS
