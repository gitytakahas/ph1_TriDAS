package com.cern.client;

import com.google.gwt.user.client.rpc.IsSerializable;

public class LogMessage implements IsSerializable
{
  
  private String level;
  private String errCode;
  private String message;
  private String timestamp;
  private String source;
  
  private String systemid;
  private String subsystemid;
  private String extraBuffer;


  private String machine;
  private String port;
  private String procname;
  private String procinstance;
  
  private String lognumber;
  



  private String fechardid;
  private String ring;
  private String ccu;
  private String i2cchannel;
  private String i2caddress;
  private String fedid;
  private String fedchannel;
  private String crate;
  private String slot;
  private String nestedclasspath;
  private String nestedfilename;
  private String nestedlinenumber;

  private String hwType;


  public boolean showInTable = true;;
  
  public LogMessage() {
  }
  
  
  
    public LogMessage(	String level,
  						String errCode,
						String message,
						String timestamp,
						String source,
						String systemid,
						String subsystemid,
						String extraBuffer,
						String machine,
						String port,
						String procname,
						String procinstance,
						String lognumber,

						String fechardid,
						String ring,
						String ccu,
						String i2cchannel,
						String i2caddress,
						String fedid,
						String fedchannel,
						String crate,
						String slot,
						String nestedclasspath,
						String nestedfilename,
						String nestedlinenumber) {
    this.level = level;
    this.errCode = errCode;
    this.message = message;
    this.timestamp = timestamp;
    this.source = source;
    this.systemid = systemid;
    this.subsystemid = subsystemid;
    this.extraBuffer = extraBuffer;
    this.machine = machine;
    this.port = port;
    this.procname = procname;
    this.procinstance = procinstance;
    this.lognumber = lognumber;

    this.fechardid = fechardid;
    this.ring = ring;
    this.ccu = ccu;
    this.i2cchannel = i2cchannel;
    this.i2caddress = i2caddress;
    this.fedid = fedid;
    this.fedchannel = fedchannel;
    this.crate = crate;
    this.slot = slot;
    this.nestedclasspath = nestedclasspath;
    this.nestedfilename = nestedfilename;
    this.nestedlinenumber = nestedlinenumber;


  }
  
  
  
  public LogMessage(	String level,
  						String errCode,
						String message,
						String timestamp,
						String source,
						String systemid,
						String subsystemid,
						String extraBuffer,
						String machine,
						String port,
						String procname,
						String procinstance,
						String lognumber ) {
    this.level = level;
    this.errCode = errCode;
    this.message = message;
    this.timestamp = timestamp;
    this.source = source;
    this.systemid = systemid;
    this.subsystemid = subsystemid;
    this.extraBuffer = extraBuffer;
    this.machine = machine;
    this.port = port;
    this.procname = procname;
    this.procinstance = procinstance;
    this.lognumber = lognumber;

    this.fechardid = "";
    this.ring = "";
    this.ccu = "";
    this.i2cchannel = "";
    this.i2caddress = "";
    this.fedid = "";
    this.fedchannel = "";
    this.crate = "";
    this.slot = "";
    this.nestedclasspath = "";
    this.nestedfilename = "";
    this.nestedlinenumber = "";


  }
      
  public String getLevel() {
    return this.level;
  }
  
  public String getErrCode() {
    return this.errCode;
  }
  
  public String getMessage() {
    return this.message;
  }

  public String getTimestamp() {
    return this.timestamp;
  }

  public String getSource() {
    return this.source;
  }

  public String getSystemId() {
    return this.systemid;
  }

  public String getSubSystemId() {
    return this.subsystemid;
  }

  public String getExtraBuffer() {
    return this.extraBuffer;
  }

  public String getMachine() {
    return this.machine;
  }

  public String getPort() {
    return this.port;
  }

  public String getProcName() {
    return this.procname;
  }

  public String getProcInstance() {
    return this.procinstance;
  }

  public String getLogNumber() {
    return this.lognumber;
  }




  public String getFecHardId() {
    return this.fechardid;
  }
  
  public String getRing() {
    return this.ring;
  }
  
  public String getCcu() {
    return this.ccu;
  }
  
  public String getI2cChannel() {
    return this.i2cchannel;
  }

  public String getI2cAddress() {
    return this.i2caddress;
  }
  
  public String getFedId() {
    return this.fedid;
  }
  
  public String getFedChannel() {
    return this.fedchannel;
  }
  
  public String getCrate() {
    return this.crate;
  }
  
  public String getSlot() {
    return this.slot;
  }

  public String getNestedClassPath() {
    return this.nestedclasspath;
  }
  
  public String getNestedFileName() {
    return this.nestedfilename;
  }
  
  public String getNestedLineNumber() {
    return this.nestedlinenumber;
  }
  
  public String getHwType() {
    return this.hwType;
  }



  
  public void setLevel(String level) {
    this.level = level;
  }
  
  public void setErrCode(String errCode) {
    this.errCode = errCode;
  }
  
  public void setMessage(String message) {
    this.message = message;
  }
  
  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }
  
  public void setSource(String source) {
    this.source = source;
  }

  public void setSystemId(String systemid) {
    this.systemid = systemid;
  }

  public void setSubSystemId(String subsystemid) {
    this.subsystemid = subsystemid;
  }

  public void setExtraBuffer(String extraBuffer) {
    this.extraBuffer = extraBuffer;
  }

  public void setMachine(String machine) {
    this.machine = machine;
  }

  public void setPort(String port) {
    this.port = port;
  }

  public void setProcName(String procname) {
    this.procname = procname;
  }

  public void setProcInstance(String procinstance) {
    this.procinstance = procinstance;
  }

  public void setLogNumber(String lognumber) {
    this.lognumber = lognumber;
  }




  public void setFecHardId(String fechardid) {
    this.fechardid = fechardid;
  }
  
  public void setRing(String ring) {
    this.ring = ring;
  }
  
  public void setCcu(String ccu) {
    this.ccu = ccu;
  }
  
  public void setI2cChannel(String i2cchannel) {
    this.i2cchannel = i2cchannel;
  }

  public void setI2cAddress(String i2caddress) {
    this.i2caddress = i2caddress;
  }
  
  public void setFedId(String fedid) {
    this.fedid = fedid;
  }
  
  public void setFedChannel(String fedchannel) {
    this.fedchannel = fedchannel;
  }
  
  public void setCrate(String crate) {
    this.crate = crate;
  }
  
  public void setSlot(String slot) {
    this.slot = slot;
  }

  public void setNestedClassPath(String nestedclasspath) {
    this.nestedclasspath = nestedclasspath;
  }
  
  public void setNestedFileName(String nestedfilename) {
    this.nestedfilename = nestedfilename;
  }
  
  public void setNestedLineNumber(String nestedlinenumber) {
    this.nestedlinenumber = nestedlinenumber;
  }

  public void setHwType(String hwtype) {
    this.hwType = hwtype;
  }



}
