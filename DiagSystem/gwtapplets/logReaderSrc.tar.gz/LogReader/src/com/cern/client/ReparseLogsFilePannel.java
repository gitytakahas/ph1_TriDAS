package com.cern.client;

import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RadioButton;

import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;

import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.Window;


public class ReparseLogsFilePannel extends HorizontalPanel
{
public Defines Defs = new Defines();
Button reparseAllButton = new Button(Defs.REPARSE_ALL_BUTTON);
Button reparseAllButKeepTreeActiveButton = new Button(Defs.REPARSE_ALL_BUTTON_BUT_KEEP_TREE_FILTERS);

public Label parserPannelTitle = new Label("Logs Parser Pannel");


//Define a pannel that will be used for partial reparse/erase tree filters
private VerticalPanel partialParsePanel = new VerticalPanel();
private HorizontalPanel partialParseUserParametersPanel = new HorizontalPanel();
public Label partialParseLowerLimitLabel = new Label("N = ");
public TextBox partialParseLowerLimitTextBox = new TextBox();
Button partialParseButton = new Button(Defs.PARTIAL_PARSE_BUTTON);
public Label partialParseUserInformation = new Label("Enter -1 to switch to full file parsing");



  public ReparseLogsFilePannel(final LogReader logReader) {


//Prepare pannel that will be used for partial reparse/erase tree filters
partialParseLowerLimitLabel.setStyleName("gwt-Label-reparsePannel");
partialParseUserParametersPanel.add(partialParseLowerLimitLabel);
partialParseLowerLimitTextBox.setText(""+logReader.lastNLogsToParse);
partialParseUserParametersPanel.add(partialParseLowerLimitTextBox);

partialParsePanel.add(partialParseButton);
partialParsePanel.add(partialParseUserParametersPanel);
partialParsePanel.add(partialParseUserInformation);



//Prepare this() pannem
this.add(reparseAllButton);
this.add(reparseAllButKeepTreeActiveButton);
this.add(partialParsePanel);






reparseAllButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {
	logReader.cleanupFlexTable();
	logReader.cleanupErrorTree();
	logReader.cleanupHardwareErrorTree();
  	logReader.reparseLogsFile();
	logReader.refreshWatchList();
  }
} );





reparseAllButKeepTreeActiveButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {
	logReader.cleanupFlexTable();
	logReader.cleanupErrorTreeButKeepFiltersActivated();
	logReader.cleanupHardwareErrorTree();

  	logReader.reparseLogsFile();
	logReader.refreshWatchList();
  }
} );





partialParseButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {
	logReader.lastNLogsToParse = Integer.valueOf(partialParseLowerLimitTextBox.getText());
	if (logReader.lastNLogsToParse > 0)
	{
		Window.alert("System now configured to read only the last " + logReader.lastNLogsToParse + " logs when parsing/reparsing a log file");
	}
	else Window.alert("System now configured to read all logs when parsing/reparsing a log file");

  }
} );


/*

partialParseButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {
	logReader.cleanupFlexTable();
	logReader.cleanupErrorTreeButKeepFiltersActivated();
  	logReader.reparseLogsFile();
	logReader.refreshWatchList();
  }
} );



*/


}


}










