package com.cern.client;

public class Defines{


   //Set to true if you want to have a blocking popup when the AjaxLogReader process stops ; 
   //user will then have to explicitely reconnect to the new AjaxLogReader process via the applet control pannel
   //Set to false if you want to automatically reconnect when the AjaxLogReader process stops then retsarts ; transparent for the user(s)
   public static final boolean FORCE_EXPLICIT_RECONNECTION_WHEN_XDAQ_STOPS = true;



	//Don't modify
	public static final int HEADER_ROW = 0 ;

	//Don't modify
	public static final int TOTAL_COLS_IN_TABLE = 13 ;

    public static final String SUBDETECTOR_NAME = "Tracker";
    public static final String HARDWARE_SUBDETECTOR_NAME = "Detector Hardware View";


	//Order from 0 to 12, 0 will be the left most column appearing in the applet
	public static final int LEVEL_COL = 12 ;
	public static final int ERRCODE_COL = 3 ;
	public static final int MSG_COL = 2 ;
	public static final int TS_COL = 1 ;
	public static final int SOURCE_COL = 4 ;
	public static final int SYSID_COL = 5 ;
	public static final int SUBSYSID_COL = 6 ;
	public static final int XTRABUFF_COL = 7 ;
	public static final int MACHINE_COL = 8 ;
	public static final int PORT_COL = 9 ;
	public static final int PROCNAME_COL = 10 ;
	public static final int PROCINST_COL = 11 ;
	public static final int LOGNUM_COL = 0 ;


	//set to true if the column must appear in the applet, false if it must be hidden
	//Rem : This choice cannot be changed dynamically from the applet
	public static final boolean ONSTARTUP_SHOW_LEVEL_COL = true ;
	public static final boolean ONSTARTUP_SHOW_ERRCODE_COL = true ;
	public static final boolean ONSTARTUP_SHOW_MSG_COL = true ;
	public static final boolean ONSTARTUP_SHOW_TS_COL = true ;
	public static final boolean ONSTARTUP_SHOW_SOURCE_COL = true ;
	public static final boolean ONSTARTUP_SHOW_SYSID_COL = true ;
	public static final boolean ONSTARTUP_SHOW_SUBSYSID_COL = true ;
	public static final boolean ONSTARTUP_SHOW_XTRABUFF_COL = true ;
	public static final boolean ONSTARTUP_SHOW_MACHINE_COL = true ;
	public static final boolean ONSTARTUP_SHOW_PORT_COL = true ;
	public static final boolean ONSTARTUP_SHOW_PROCNAME_COL = true ;
	public static final boolean ONSTARTUP_SHOW_PROCINST_COL = true ;
	public static final boolean ONSTARTUP_SHOW_LOGNUM_COL = true ;


	//Columns Names as appearing in the applet
  public static final String LEVEL_LABEL = "LEVEL";
  public static final String ERRCODE_LABEL = "ERR CODE";
  public static final String MESSAGE_LABEL = "MESSAGE";
  public static final String TIMESTAMP_LABEL = "TIMESTAMP";
  public static final String SOURCE_LABEL = "SOURCE";
  public static final String SYSID_LABEL = "SYSTEM ID";
  public static final String SUBSYSID_LABEL = "SUBSYSTEM ID";
  public static final String XTRABUFF_LABEL = "XTRA BUFFER";
  public static final String MACHINE_LABEL = "MACHINE";
  public static final String PORT_LABEL = "PORT";
  public static final String PROCNAME_LABEL = "PROCESS";
  public static final String PROCINSTANCE_LABEL = "INSTANCE";
  public static final String LOGNUMBER_LABEL = "LOG NUMBER";


	//Don't modify
  public static final String COLUMN_OPERATION_SHOW = "SHOW";
  public static final String COLUMN_OPERATION_HIDE = "HIDE";
  public static final String COLUMN_OPERATION_SORT = "SORT";




	//set to true if logs of loglevel ONSTARTUP_SHOW_BLAH_ must be displayed by default in the applet
	public static final boolean ONSTARTUP_SHOW_TRACE_LOGS = true ;
	public static final boolean ONSTARTUP_SHOW_DEBUG_LOGS = true ;
	public static final boolean ONSTARTUP_SHOW_INFO_LOGS = true ;
	public static final boolean ONSTARTUP_SHOW_WARN_LOGS = true ;
	public static final boolean ONSTARTUP_SHOW_USERINFO_LOGS = true ;
	public static final boolean ONSTARTUP_SHOW_ERROR_LOGS = true ;
	public static final boolean ONSTARTUP_SHOW_FATAL_LOGS = true ;



	//Initial logs table length, in lines -- 1 line == 1 log message
  public static int DEFAULT_MAX_NUMBER_OF_LOGS_IN_TABLE = 1000; // ms

	//Data block length to use when reading data from server (AjaxLogReader), given in number of messages per block
  public static int DEFAULT_LOGS_BURST_LENGTH = 100; // ms


	//Don't modify unless your AjaxLogReader process has a LID not included in [10 .. 100]
  public static final int LID_MIN_POLL_LIMIT = 10 ;
  public static final int LID_MAX_POLL_LIMIT = 100 ;


	//Default poll rate between two requests to server when waiting for data
  public static int STANDARD_REFRESH_INTERVAL = 5000; // ms

	//Default streaming poll rate between two requests to server when getting more than DEFAULT_LOGS_BURST_LENGTH records at a time from server
	  public static int QUICK_REFRESH_INTERVAL = 1000; // ms


	//Don't modify
  public static final String HIDE_CTRL_BUTTON = "Hide control pannel";
  public static final String SHOW_CTRL_BUTTON = "Show control pannel";

	//Don't modify
  public static final String HIDE_LOGS_BUTTON = "Hide applet monitoring pannel";
  public static final String SHOW_LOGS_BUTTON = "Show applet monitoring pannel";

	//Don't modify
  public static final String HIDE_PARSER_BUTTON = "Hide logs parser pannel";
  public static final String SHOW_PARSER_BUTTON = "Show logs parser pannel";

	//Don't modify
  public static final String REPARSE_ALL_BUTTON = "Reparse logs collection<br>Reset tree filters before parsing";
  public static final String REPARSE_ALL_BUTTON_BUT_KEEP_TREE_FILTERS = "Reparse logs collection<br>Keep current tree filters active when parsing";


  public static final String PARTIAL_PARSE_BUTTON = "SET N value to browse only last N logs<br>when parsing or reparsing a log file";






  public static final String TREE_LISTBOX_SHOW = "Show messages in main window";
  public static final String TREE_LISTBOX_HIDE = "Exclude messages from main window";
  public static final String TREE_LISTBOX_FOCUS = "Focus on messages in main window";



  public static final String HARDWARE_TREE_LISTBOX_SHOW = "Show messages in main window";
  public static final String HARDWARE_TREE_LISTBOX_HIDE = "Exclude messages from main window";
  public static final String HARDWARE_TREE_LISTBOX_FOCUS = "Focus on messages in main window";


 public static final String INIT_TREENODE_VALUE = "UNASSIGNED";


 public static final String INIT_HARDWARE_TREENODE_VALUE = "UNASSIGNED";

 public static final String ENABLE_TREE_EVENTS_BUTTON_LABEL = "Enable Software Tree Events";
 public static final String DISABLE_TREE_EVENTS_BUTTON_LABEL = "Disable Software Tree Events";


 public static final String ENABLE_HARDWARE_TREE_EVENTS_BUTTON_LABEL = "Enable Hardware Tree Events";
 public static final String DISABLE_HARDWARE_TREE_EVENTS_BUTTON_LABEL = "Disable Hardware Tree Events";

 public static final boolean USE_SOUNDS_FOR_TRACE = false;
 public static final boolean USE_SOUNDS_FOR_DEBUG = false;
 public static final boolean USE_SOUNDS_FOR_INFO = false;
 public static final boolean USE_SOUNDS_FOR_WARN = false;
 public static final boolean USE_SOUNDS_FOR_USERINFO = false;
 public static final boolean USE_SOUNDS_FOR_ERROR = false;
 public static final boolean USE_SOUNDS_FOR_FATAL = false;



 public static final String DEFAULT_APPLET_UID = "-1";



 public static final String CRATE_PREFIX = "Crate ";
 public static final String SLOT_PREFIX = "Slot ";
 public static final String RING_PREFIX = "Ring ";
 public static final String CCU_PREFIX = "Ccu ";
 public static final String I2CCHANNEL_PREFIX = "I2C channel ";
 public static final String I2CADDRESS_PREFIX = "I2C address ";

 public static final String FEDCHANNEL_PREFIX = "FED channel ";



}




























