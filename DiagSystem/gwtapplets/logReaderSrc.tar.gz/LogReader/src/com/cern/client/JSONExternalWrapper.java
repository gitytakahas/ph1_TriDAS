package com.cern.client;

import com.google.gwt.core.client.JavaScriptObject;

import com.google.gwt.core.client.GWTBridge;

import com.google.gwt.user.client.Window;

import com.google.gwt.core.client.JavaScriptObject;

//import com.google.gwt.core.client.GWTBridge;



public class JSONExternalWrapper 
{


   interface JSONHandler
   {
      public void handleJSON(JavaScriptObject obj);
      
   }


   interface JSONConnectionHandler
   {
      public void handleJSONConnection(JavaScriptObject obj);
      
   }



   interface JSONHwInfoHandler
   {
      public void handleJSONHwInfo(JavaScriptObject obj);
      
   }

   public static native void makeJSONRequest(String urlExtension, String url, JSONHandler handler ) /*-{

       $wnd.jsonCallback = function(jsonObj) {
        @com.cern.client.JSONExternalWrapper::dispatchJSON(Lcom/google/gwt/core/client/JavaScriptObject;Lcom/cern/client/JSONExternalWrapper$JSONHandler;)(jsonObj,handler);



       }


       // create SCRIPT tag, and set SRC attribute equal to JSON feed URL + callback function name
       var script = $wnd.document.createElement("script");
       script.setAttribute("src", url+"jsonCallback"+urlExtension);
       script.setAttribute("type", "text/javascript");
       $wnd.document.getElementsByTagName("head")[0].appendChild(script);
	   
   }-*/;


   public static native void makeJSONConnectionRequest(String url, JSONConnectionHandler handler) /*-{

       $wnd.jsonConnectionCallback = function(jsonObj) {
        @com.cern.client.JSONExternalWrapper::dispatchJSONConnection(Lcom/google/gwt/core/client/JavaScriptObject;Lcom/cern/client/JSONExternalWrapper$JSONConnectionHandler;)(jsonObj,handler);



       }


       // create SCRIPT tag, and set SRC attribute equal to JSON feed URL + callback function name
       var script = $wnd.document.createElement("script");
       script.setAttribute("src", url+"jsonConnectionCallback");
       script.setAttribute("type", "text/javascript");
       $wnd.document.getElementsByTagName("head")[0].appendChild(script);
	   
   }-*/;



   public static native void makeJSONHwInfoRequest(String urlExtension, String url, JSONHwInfoHandler handler ) /*-{

       $wnd.jsonHwInfoCallback = function(jsonObj) {
        @com.cern.client.JSONExternalWrapper::dispatchJSONHwInfo(Lcom/google/gwt/core/client/JavaScriptObject;Lcom/cern/client/JSONExternalWrapper$JSONHwInfoHandler;)(jsonObj,handler);



       }


       // create SCRIPT tag, and set SRC attribute equal to JSON feed URL + callback function name
       var script = $wnd.document.createElement("script");
       script.setAttribute("src", url+"jsonHwInfoCallback"+urlExtension);
       script.setAttribute("type", "text/javascript");
       $wnd.document.getElementsByTagName("head")[0].appendChild(script);
	   
   }-*/;


   public static void dispatchJSON(JavaScriptObject jsonObj, JSONHandler handler)
   {
      handler.handleJSON(jsonObj);
   }

   public static void dispatchJSONConnection(JavaScriptObject jsonObj, JSONConnectionHandler handler)
   {
      handler.handleJSONConnection(jsonObj);
   }


   public static void dispatchJSONHwInfo(JavaScriptObject jsonObj, JSONHwInfoHandler handler)
   {
      handler.handleJSONHwInfo(jsonObj);
   }


}
