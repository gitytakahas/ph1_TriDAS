package com.cern.client;

import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RadioButton;

import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;

import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Button;


public class DataBlockLengthPerReadoutPannel extends HorizontalPanel
{

  private Label dblockSizeLabel = new Label();
  TextBox dblockSizeEntry = new TextBox();


  Button applyButton = new Button("Apply");



  public DataBlockLengthPerReadoutPannel(final LogReader logReader) {

  //*******************************
  //assemble chooseCriticityPanel panel
  //*******************************


dblockSizeLabel.setText( "Number of logs to read from server in one burst  : (currently " + logReader.logsBurstLength + ")" );

this.add(dblockSizeLabel);

  dblockSizeLabel.addStyleDependentName("lineHeaderLabel");
  dblockSizeLabel.setWordWrap(false);


this.add(dblockSizeEntry);



this.add(applyButton);





applyButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {
		int dblockSize = Integer.valueOf(dblockSizeEntry.getText());
		logReader.logsBurstLength = dblockSize;
dblockSizeLabel.setText( "Number of logs to read from server in one burst  : (currently " + logReader.logsBurstLength + ")" );

/*
	logReader.cleanupFlexTable();
	logReader.cleanupErrorTree();
  	logReader.reparseLogsFile();
	logReader.refreshWatchList();
*/

//		logReader.ft.
  }
} );





}







}












