package com.cern.client;

import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
//import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.ListBox;

import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HTMLTable.RowFormatter;

import com.google.gwt.user.client.ui.TreeItem;


//import com.google.gwt.user.client.ui.ClickHandler;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;
//import com.google.gwt.user.client.Window.Location;
import com.google.gwt.user.client.Window;

import com.google.gwt.user.client.ui.ChangeListener;
import com.google.gwt.user.client.ui.Widget;


//import com.google.gwt.user.client.ui.TreeListener;



//public class DiagTreeItem extends TreeItem implements ClickHandler 
public class DiagTreeHardwareItem extends TreeItem 

{

public Defines Defs = new Defines();

public HorizontalPanel shadowMessagesPanel = new HorizontalPanel();

//DYNTREEDEBUGRELATED



    public String treeItemName;

    public String subdetectorNodeLevel;
    //public String machineNodeLevel;
    public String hwtypeNodeLevel;
//    public String portNodeLevel;
    public String crateNodeLevel;
//    public String procnameNodeLevel;
    public String slotnameNodeLevel;
//    public String instanceNodeLevel;
    public String fecringOrfedchannelNodeLevel;

    public String fecccuNodeLevel;
    public String feci2cchannelNodeLevel;
    public String feci2caddressNodeLevel;

//    public String classnameNodeLevel;
//    public String subclassnameNodeLevel;
//    public String subsubclassnameNodeLevel;


    private int traceCounter;
    private int debugCounter;
    private int infoCounter;
    private int warnCounter;
    private int userinfoCounter;
    private int errorCounter;
    private int fatalCounter;


    public boolean showInLogsTable = true;
    public boolean hideInLogsTable = false;
    public boolean focusInLogsTable = false;

  public int errorCodeOccurences = 0;
  
    public String errorCodeAssociatedMessage;


public String errCode;


  public DiagTreeHardwareItem(String namedTreeItem)
  {
	super(namedTreeItem);
	treeItemName = namedTreeItem;
	traceCounter=0;
	debugCounter=0;
	infoCounter=0;
	warnCounter=0;
	userinfoCounter=0;
	errorCounter=0;
	fatalCounter=0;


	subdetectorNodeLevel = Defs.INIT_HARDWARE_TREENODE_VALUE;
	//machineNodeLevel = Defs.INIT_HARDWARE_TREENODE_VALUE;
	hwtypeNodeLevel = Defs.INIT_HARDWARE_TREENODE_VALUE;
	crateNodeLevel = Defs.INIT_HARDWARE_TREENODE_VALUE;
	slotnameNodeLevel = Defs.INIT_HARDWARE_TREENODE_VALUE;
	fecringOrfedchannelNodeLevel = Defs.INIT_HARDWARE_TREENODE_VALUE;
	fecccuNodeLevel = Defs.INIT_HARDWARE_TREENODE_VALUE;
	feci2cchannelNodeLevel = Defs.INIT_HARDWARE_TREENODE_VALUE;
	feci2caddressNodeLevel = Defs.INIT_HARDWARE_TREENODE_VALUE;

  }




  public int getTraceCounter() {
    return this.traceCounter;
  }

  public void setTraceCounter(int value) {
    this.traceCounter = value;
  }




  public int getDebugCounter() {
    return this.debugCounter;
  }

  public void setDebugCounter(int value) {
    this.debugCounter = value;
  }



  public int getInfoCounter() {
    return this.infoCounter;
  }

  public void setInfoCounter(int value) {
    this.infoCounter = value;
  }






  public int getWarnCounter() {
    return this.warnCounter;
  }

  public void setWarnCounter(int value) {
    this.warnCounter = value;
  }


  public int getUserinfoCounter() {
    return this.userinfoCounter;
  }

  public void setUserinfoCounter(int value) {
    this.userinfoCounter = value;
  }


  public int getErrorCounter() {
    return this.errorCounter;
  }

  public void setErrorCounter(int value) {
    this.errorCounter = value;
  }


  public int getFatalCounter() {
    return this.fatalCounter;
  }

  public void setFatalCounter(int value) {
    this.fatalCounter = value;
  }


  public String getTreeItemName() {
    return this.treeItemName;
  }

  public void setTreeItemName(String name) {
    this.treeItemName = name;
  }




  public void setNodeProperties(String p_subdetectorNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
  }



  public void setNodeProperties(String p_subdetectorNodeLevel,
  				String p_hwtypeNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	hwtypeNodeLevel = p_hwtypeNodeLevel;
  }




  public void setNodeProperties(String p_subdetectorNodeLevel,
  				String p_hwtypeNodeLevel,
				String p_crateNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	hwtypeNodeLevel = p_hwtypeNodeLevel;
	crateNodeLevel = p_crateNodeLevel;
  }



  public void setNodeProperties(String p_subdetectorNodeLevel,
  				String p_hwtypeNodeLevel,
				String p_crateNodeLevel,
				String p_slotnameNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	hwtypeNodeLevel = p_hwtypeNodeLevel;
	crateNodeLevel = p_crateNodeLevel;
	slotnameNodeLevel = p_slotnameNodeLevel;
  }



/*
  public void setNodeProperties(String p_subdetectorNodeLevel,
  				String p_hwtypeNodeLevel,
				String p_crateNodeLevel,
				String p_slotnameNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	hwtypeNodeLevel = p_hwtypeNodeLevel;
	crateNodeLevel = p_crateNodeLevel;
	slotnameNodeLevel = p_slotnameNodeLevel;
  }

*/

  public void setNodeProperties(String p_subdetectorNodeLevel,
  				String p_hwtypeNodeLevel,
				String p_crateNodeLevel,
				String p_slotnameNodeLevel,
				String p_fecringOrfedchannelNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	hwtypeNodeLevel = p_hwtypeNodeLevel;
	crateNodeLevel = p_crateNodeLevel;
	slotnameNodeLevel = p_slotnameNodeLevel;
	fecringOrfedchannelNodeLevel = p_fecringOrfedchannelNodeLevel;
  }


  public void setNodeProperties(String p_subdetectorNodeLevel,
  				String p_hwtypeNodeLevel,
				String p_crateNodeLevel,
				String p_slotnameNodeLevel,
				String p_fecringOrfedchannelNodeLevel,
				String p_fecccuNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	hwtypeNodeLevel = p_hwtypeNodeLevel;
	crateNodeLevel = p_crateNodeLevel;
	slotnameNodeLevel = p_slotnameNodeLevel;
	fecringOrfedchannelNodeLevel = p_fecringOrfedchannelNodeLevel;
	fecccuNodeLevel = p_fecccuNodeLevel;
  }




  public void setNodeProperties(String p_subdetectorNodeLevel,
  				String p_hwtypeNodeLevel,
				String p_crateNodeLevel,
				String p_slotnameNodeLevel,
				String p_fecringOrfedchannelNodeLevel,
				String p_fecccuNodeLevel,
				String p_feci2cchannelNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	hwtypeNodeLevel = p_hwtypeNodeLevel;
	crateNodeLevel = p_crateNodeLevel;
	slotnameNodeLevel = p_slotnameNodeLevel;
	fecringOrfedchannelNodeLevel = p_fecringOrfedchannelNodeLevel;
	fecccuNodeLevel = p_fecccuNodeLevel;
	feci2cchannelNodeLevel = p_feci2cchannelNodeLevel;
  }



  public void setNodeProperties(String p_subdetectorNodeLevel,
  				String p_hwtypeNodeLevel,
				String p_crateNodeLevel,
				String p_slotnameNodeLevel,
				String p_fecringOrfedchannelNodeLevel,
				String p_fecccuNodeLevel,
				String p_feci2cchannelNodeLevel,
				String p_feci2caddressNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	hwtypeNodeLevel = p_hwtypeNodeLevel;
	crateNodeLevel = p_crateNodeLevel;
	slotnameNodeLevel = p_slotnameNodeLevel;
	fecringOrfedchannelNodeLevel = p_fecringOrfedchannelNodeLevel;
	fecccuNodeLevel = p_fecccuNodeLevel;
	feci2caddressNodeLevel = p_feci2caddressNodeLevel;
  }








  public void incrementOccurenceCounter()
  {
  	errorCodeOccurences = errorCodeOccurences + 1;
  }


  public void setOccurenceCounter(int occ)
  {
  	errorCodeOccurences = occ;
  }

  public int getOccurenceCounter()
  {
  	return errorCodeOccurences;
  }




  public void setErrorCodeAssociatedMessage(String msg)
  {
  	errorCodeAssociatedMessage = msg;
  }

  public String getErrorCodeAssociatedMessage()
  {
  	return errorCodeAssociatedMessage;
  }




  public void setErrorCode(String code)
  {
  	errCode = code;
  }

  public String getErrorCode()
  {
  	return errCode;
  }











}

















