package com.cern.client;

import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
//import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.ListBox;

import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HTMLTable.RowFormatter;

import com.google.gwt.user.client.ui.TreeItem;


//import com.google.gwt.user.client.ui.ClickHandler;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;
//import com.google.gwt.user.client.Window.Location;
import com.google.gwt.user.client.Window;

import com.google.gwt.user.client.ui.ChangeListener;
import com.google.gwt.user.client.ui.Widget;


//import com.google.gwt.user.client.ui.TreeListener;



//public class DiagTreeItem extends TreeItem implements ClickHandler 
public class DiagTreeItem extends TreeItem 

{

public Defines Defs = new Defines();

public HorizontalPanel shadowMessagesPanel = new HorizontalPanel();

//DYNTREEDEBUGRELATED



    public String treeItemName;

    public String subdetectorNodeLevel;
    public String machineNodeLevel;
    public String portNodeLevel;
    public String procnameNodeLevel;
    public String instanceNodeLevel;
    public String classnameNodeLevel;
    public String subclassnameNodeLevel;
    public String subsubclassnameNodeLevel;


    private int traceCounter;
    private int debugCounter;
    private int infoCounter;
    private int warnCounter;
    private int userinfoCounter;
    private int errorCounter;
    private int fatalCounter;


    public boolean showInLogsTable = true;
    public boolean hideInLogsTable = false;
    public boolean focusInLogsTable = false;

  
  public DiagTreeItem(String namedTreeItem)
  {
	super(namedTreeItem);
	treeItemName = namedTreeItem;
	traceCounter=0;
	debugCounter=0;
	infoCounter=0;
	warnCounter=0;
	userinfoCounter=0;
	errorCounter=0;
	fatalCounter=0;


	subdetectorNodeLevel = Defs.INIT_TREENODE_VALUE;
	machineNodeLevel = Defs.INIT_TREENODE_VALUE;
	portNodeLevel = Defs.INIT_TREENODE_VALUE;
	procnameNodeLevel = Defs.INIT_TREENODE_VALUE;
	instanceNodeLevel = Defs.INIT_TREENODE_VALUE;
	classnameNodeLevel = Defs.INIT_TREENODE_VALUE;
	subclassnameNodeLevel = Defs.INIT_TREENODE_VALUE;
	subsubclassnameNodeLevel = Defs.INIT_TREENODE_VALUE;


  }




  public int getTraceCounter() {
    return this.traceCounter;
  }

  public void setTraceCounter(int value) {
    this.traceCounter = value;
  }




  public int getDebugCounter() {
    return this.debugCounter;
  }

  public void setDebugCounter(int value) {
    this.debugCounter = value;
  }



  public int getInfoCounter() {
    return this.infoCounter;
  }

  public void setInfoCounter(int value) {
    this.infoCounter = value;
  }






  public int getWarnCounter() {
    return this.warnCounter;
  }

  public void setWarnCounter(int value) {
    this.warnCounter = value;
  }


  public int getUserinfoCounter() {
    return this.userinfoCounter;
  }

  public void setUserinfoCounter(int value) {
    this.userinfoCounter = value;
  }


  public int getErrorCounter() {
    return this.errorCounter;
  }

  public void setErrorCounter(int value) {
    this.errorCounter = value;
  }


  public int getFatalCounter() {
    return this.fatalCounter;
  }

  public void setFatalCounter(int value) {
    this.fatalCounter = value;
  }


  public String getTreeItemName() {
    return this.treeItemName;
  }

  public void setTreeItemName(String name) {
    this.treeItemName = name;
  }




  public void setNodeProperties(String p_subdetectorNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
  }


  public void setNodeProperties(String p_subdetectorNodeLevel,
  				String p_machineNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	machineNodeLevel = p_machineNodeLevel;
  }


  public void setNodeProperties(String p_subdetectorNodeLevel,
				String p_machineNodeLevel,
  				String p_portNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	machineNodeLevel = p_machineNodeLevel;
	portNodeLevel = p_portNodeLevel;
  }




  public void setNodeProperties(String p_subdetectorNodeLevel,
				String p_machineNodeLevel,
  				String p_portNodeLevel,
				String p_procnameNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	machineNodeLevel = p_machineNodeLevel;
	portNodeLevel = p_portNodeLevel;
	procnameNodeLevel = p_procnameNodeLevel;
  }



  public void setNodeProperties(String p_subdetectorNodeLevel,
				String p_machineNodeLevel,
  				String p_portNodeLevel,
				String p_procnameNodeLevel,
				String p_instanceNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	machineNodeLevel = p_machineNodeLevel;
	portNodeLevel = p_portNodeLevel;
	procnameNodeLevel = p_procnameNodeLevel;
	instanceNodeLevel = p_instanceNodeLevel;
  }




  public void setNodeProperties(String p_subdetectorNodeLevel,
				String p_machineNodeLevel,
  				String p_portNodeLevel,
				String p_procnameNodeLevel,
				String p_instanceNodeLevel,
				String p_classnameNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	machineNodeLevel = p_machineNodeLevel;
	portNodeLevel = p_portNodeLevel;
	procnameNodeLevel = p_procnameNodeLevel;
	instanceNodeLevel = p_instanceNodeLevel;
	classnameNodeLevel = p_classnameNodeLevel;
  }


  public void setNodeProperties(String p_subdetectorNodeLevel,
				String p_machineNodeLevel,
  				String p_portNodeLevel,
				String p_procnameNodeLevel,
				String p_instanceNodeLevel,
				String p_classnameNodeLevel,
				String p_subclassnameNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	machineNodeLevel = p_machineNodeLevel;
	portNodeLevel = p_portNodeLevel;
	procnameNodeLevel = p_procnameNodeLevel;
	instanceNodeLevel = p_instanceNodeLevel;
	classnameNodeLevel = p_classnameNodeLevel;
	subclassnameNodeLevel = p_subclassnameNodeLevel;
  }



  public void setNodeProperties(String p_subdetectorNodeLevel,
				String p_machineNodeLevel,
  				String p_portNodeLevel,
				String p_procnameNodeLevel,
				String p_instanceNodeLevel,
				String p_classnameNodeLevel,
				String p_subclassnameNodeLevel,
				String p_subsubclassnameNodeLevel) {
	subdetectorNodeLevel = p_subdetectorNodeLevel;
	machineNodeLevel = p_machineNodeLevel;
	portNodeLevel = p_portNodeLevel;
	procnameNodeLevel = p_procnameNodeLevel;
	instanceNodeLevel = p_instanceNodeLevel;
	classnameNodeLevel = p_classnameNodeLevel;
	subclassnameNodeLevel = p_subclassnameNodeLevel;
	subsubclassnameNodeLevel = p_subsubclassnameNodeLevel;
  }








}

















