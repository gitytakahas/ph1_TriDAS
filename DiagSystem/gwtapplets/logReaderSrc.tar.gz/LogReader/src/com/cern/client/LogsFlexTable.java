package com.cern.client;

import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
//import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.ListBox;

import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HTMLTable.RowFormatter;


public class LogsFlexTable extends FlexTable
{
  
public Defines Defs = new Defines();
  
  
  public LogsFlexTable(final LogReader logReader)
  {
	this.setStylePrimaryName("gwt-LogsFlexTable");
  }
  



  public void setColumnsHeaders()
  {

//	this.getRowFormatter().setStyleName(Defs.HEADER_ROW, "gwt-LogsFlexTable-HeaderRow");

FlexTable.FlexCellFormatter cf = this.getFlexCellFormatter();

    // Tables have no explicit size -- they resize automatically on demand.
    // Declare first line of table (row headers) as labels

    this.setText(Defs.HEADER_ROW, Defs.LEVEL_COL, Defs.LEVEL_LABEL);
	cf.setWordWrap(Defs.HEADER_ROW, Defs.LEVEL_COL, false);
	if (Defs.ONSTARTUP_SHOW_LEVEL_COL == false)
	{
		cf.setVisible(Defs.HEADER_ROW, Defs.LEVEL_COL, false);
	}
	else cf.setStyleName(Defs.HEADER_ROW, Defs.LEVEL_COL, "gwt-LogsFlexTable-HeaderRow");


    this.setText(Defs.HEADER_ROW, Defs.ERRCODE_COL, Defs.ERRCODE_LABEL);
	cf.setWordWrap(Defs.HEADER_ROW, Defs.ERRCODE_COL, false);
	if (Defs.ONSTARTUP_SHOW_ERRCODE_COL == false)
	{
		cf.setVisible(Defs.HEADER_ROW, Defs.ERRCODE_COL, false);
	}
	else cf.setStyleName(Defs.HEADER_ROW, Defs.ERRCODE_COL, "gwt-LogsFlexTable-HeaderRow");


    this.setText(Defs.HEADER_ROW, Defs.MSG_COL, Defs.MESSAGE_LABEL);
	cf.setWordWrap(Defs.HEADER_ROW, Defs.MSG_COL, false);
	if (Defs.ONSTARTUP_SHOW_MSG_COL == false)
	{
		cf.setVisible(Defs.HEADER_ROW, Defs.MSG_COL, false);
	}
	else cf.setStyleName(Defs.HEADER_ROW, Defs.MSG_COL, "gwt-LogsFlexTable-HeaderRow");


    this.setText(Defs.HEADER_ROW, Defs.TS_COL, Defs.TIMESTAMP_LABEL);
	cf.setWordWrap(Defs.HEADER_ROW, Defs.TS_COL, false);
	if (Defs.ONSTARTUP_SHOW_TS_COL == false)
	{
		cf.setVisible(Defs.HEADER_ROW, Defs.TS_COL, false);
	}
	else cf.setStyleName(Defs.HEADER_ROW, Defs.TS_COL, "gwt-LogsFlexTable-HeaderRow");


    this.setText(Defs.HEADER_ROW, Defs.SOURCE_COL, Defs.SOURCE_LABEL);
	cf.setWordWrap(Defs.HEADER_ROW, Defs.SOURCE_COL, false);
	if (Defs.ONSTARTUP_SHOW_SOURCE_COL == false)
	{
		cf.setVisible(Defs.HEADER_ROW, Defs.SOURCE_COL, false);
	}
	else cf.setStyleName(Defs.HEADER_ROW, Defs.SOURCE_COL, "gwt-LogsFlexTable-HeaderRow");


    this.setText(Defs.HEADER_ROW, Defs.SYSID_COL, Defs.SYSID_LABEL);
	cf.setWordWrap(Defs.HEADER_ROW, Defs.SYSID_COL, false);
	if (Defs.ONSTARTUP_SHOW_SYSID_COL == false)
	{
		cf.setVisible(Defs.HEADER_ROW, Defs.SYSID_COL, false);
	}
	else cf.setStyleName(Defs.HEADER_ROW, Defs.SYSID_COL, "gwt-LogsFlexTable-HeaderRow");


    this.setText(Defs.HEADER_ROW, Defs.SUBSYSID_COL, Defs.SUBSYSID_LABEL);
	cf.setWordWrap(Defs.HEADER_ROW, Defs.SUBSYSID_COL, false);
	if (Defs.ONSTARTUP_SHOW_SUBSYSID_COL == false)
	{
		cf.setVisible(Defs.HEADER_ROW, Defs.SUBSYSID_COL, false);
	}
	else cf.setStyleName(Defs.HEADER_ROW, Defs.SUBSYSID_COL, "gwt-LogsFlexTable-HeaderRow");


    this.setText(Defs.HEADER_ROW, Defs.XTRABUFF_COL, Defs.XTRABUFF_LABEL);
	cf.setWordWrap(Defs.HEADER_ROW, Defs.XTRABUFF_COL, false);
	if (Defs.ONSTARTUP_SHOW_XTRABUFF_COL == false)
	{
		cf.setVisible(Defs.HEADER_ROW, Defs.XTRABUFF_COL, false);
	}
	else cf.setStyleName(Defs.HEADER_ROW, Defs.XTRABUFF_COL, "gwt-LogsFlexTable-HeaderRow");


    this.setText(Defs.HEADER_ROW, Defs.MACHINE_COL, Defs.MACHINE_LABEL);
	cf.setWordWrap(Defs.HEADER_ROW, Defs.MACHINE_COL, false);
	if (Defs.ONSTARTUP_SHOW_MACHINE_COL == false)
	{
		cf.setVisible(Defs.HEADER_ROW, Defs.MACHINE_COL, false);
	}
	else cf.setStyleName(Defs.HEADER_ROW, Defs.MACHINE_COL, "gwt-LogsFlexTable-HeaderRow");


    this.setText(Defs.HEADER_ROW, Defs.PORT_COL, Defs.PORT_LABEL);
	cf.setWordWrap(Defs.HEADER_ROW, Defs.PORT_COL, false);
	if (Defs.ONSTARTUP_SHOW_PORT_COL == false)
	{
		cf.setVisible(Defs.HEADER_ROW, Defs.PORT_COL, false);
	}
	else cf.setStyleName(Defs.HEADER_ROW, Defs.PORT_COL, "gwt-LogsFlexTable-HeaderRow");


    this.setText(Defs.HEADER_ROW, Defs.PROCNAME_COL, Defs.PROCNAME_LABEL);
	cf.setWordWrap(Defs.HEADER_ROW, Defs.PROCNAME_COL, false);
	if (Defs.ONSTARTUP_SHOW_PROCNAME_COL == false)
	{
		cf.setVisible(Defs.HEADER_ROW, Defs.PROCNAME_COL, false);
	}
	else cf.setStyleName(Defs.HEADER_ROW, Defs.PROCNAME_COL, "gwt-LogsFlexTable-HeaderRow");


    this.setText(Defs.HEADER_ROW, Defs.PROCINST_COL, Defs.PROCINSTANCE_LABEL);
	cf.setWordWrap(Defs.HEADER_ROW, Defs.PROCINST_COL, false);
	if (Defs.ONSTARTUP_SHOW_PROCINST_COL == false)
	{
		cf.setVisible(Defs.HEADER_ROW, Defs.PROCINST_COL, false);
	}
	else cf.setStyleName(Defs.HEADER_ROW, Defs.PROCINST_COL, "gwt-LogsFlexTable-HeaderRow");


    this.setText(Defs.HEADER_ROW, Defs.LOGNUM_COL, Defs.LOGNUMBER_LABEL);
	cf.setWordWrap(Defs.HEADER_ROW, Defs.LOGNUM_COL, false);
	if (Defs.ONSTARTUP_SHOW_LOGNUM_COL == false)
	{
		cf.setVisible(Defs.HEADER_ROW, Defs.LOGNUM_COL, false);
	}
	else cf.setStyleName(Defs.HEADER_ROW, Defs.LOGNUM_COL, "gwt-LogsFlexTable-HeaderRow");

//rbTraceLabel.setWordWrap(false);

  }






}
