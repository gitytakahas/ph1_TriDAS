package com.cern.client;

import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RadioButton;

import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;

import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Button;


public class ConnectionParametersPannel extends HorizontalPanel
{

  private Label connectionLabel = new Label("Connexion parameters : ");


  private Label serverNameLabel = new Label(" ServerName and PortNumber (machine.domain:port) :");
  TextBox serverName = new TextBox();


  private Label lidNumberLabel = new Label(" XDAQ LID number:");
  TextBox lidNumber = new TextBox();
 
//  private Label currentUrlLabel = new Label("");


  Button applyButton = new Button("Apply");


  Button applySwitchToAutomatedButton = new Button("Switch to Auto-Detect mode");


  public ConnectionParametersPannel(final LogReader logReader) {

  //*******************************
  //assemble chooseCriticityPanel panel
  //*******************************

this.add(connectionLabel);

  connectionLabel.addStyleDependentName("lineHeaderLabel");
  connectionLabel.setWordWrap(false);


serverName.setText("127.0.0.1:14000");
this.add(serverNameLabel);
this.add(serverName);


lidNumber.setText("21");
this.add(lidNumberLabel);
this.add(lidNumber);


/*
if ( logReader.JSON_URL.equals("") )
{
  currentUrlLabel.setText(" Current URL in use:NO VALID URL IN USE");
}
else
{
  currentUrlLabel.setText(" Current URL in use:" + logReader.JSON_URL);
}
this.add(currentUrlLabel);
*/

this.add(applyButton);

this.add(applySwitchToAutomatedButton);




applyButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
		logReader.xsiteConnectionUrl = serverName.getText();
		logReader.xsiteConnectionLid = lidNumber.getText();
		logReader.forceCrossSiteConnection();
  }
} );



applySwitchToAutomatedButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
		logReader.findXdaqJsonServer();
  }
} );




}




/*

public void cleanFieldsOnAutoDetectError() {
serverName.setText("");
lidNumber.setText("");
//currentUrlLabel.setText(" Current URL in use:NO VALID URL IN USE");
}

public void setFieldsOnAutoDetectSuccess(String host, String lid, String jsURL) {
serverName.setText(host);
lidNumber.setText(lid);
//currentUrlLabel.setText(" Current URL in use:" + jsURL);
}

*/





}












