package com.cern.client;

import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RadioButton;

import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;
public class ControlCriticityPannel extends HorizontalPanel
{

public Defines Defs = new Defines();


  //Logs Criticity selection related pannel
//  public HorizontalPanel chooseCriticityPanel = new HorizontalPanel();

  private Label chooseCriticityLabel = new Label("Display logs of criticity : ");

  RadioButton rbTrace = new RadioButton("rbTrace");
  private Label rbTraceLabel = new Label("Trace");
  public boolean rbTraceChecked;

  RadioButton rbDebug = new RadioButton("rbDebug");
  private Label rbDebugLabel = new Label("Debug");
  public boolean rbDebugChecked;

  RadioButton rbInfo = new RadioButton("rbInfo");
  private Label rbInfoLabel = new Label("Info");
  public boolean rbInfoChecked;

  RadioButton rbWarn = new RadioButton("rbWarn");
  private Label rbWarnLabel = new Label("Warn");
  public boolean rbWarnChecked;

  RadioButton rbUserinfo = new RadioButton("rbUserinfo");
  private Label rbUserinfoLabel = new Label("Userinfo");
  public boolean rbUserinfoChecked;

  RadioButton rbError = new RadioButton("rbError");
  private Label rbErrorLabel = new Label("Error");
  public boolean rbErrorChecked;

  RadioButton rbFatal = new RadioButton("rbFatal");
  private Label rbFatalLabel = new Label("Fatal");
  public boolean rbFatalChecked;
 

  public ControlCriticityPannel(final LogReader logReader) {

  //*******************************
  //assemble chooseCriticityPanel panel
  //*******************************


 this.add(chooseCriticityLabel);


this.add(rbTrace);
this.add(rbTraceLabel);

this.add(rbDebug);
this.add(rbDebugLabel);

this.add(rbInfo);
this.add(rbInfoLabel);

this.add(rbWarn);
this.add(rbWarnLabel);

this.add(rbUserinfo);
this.add(rbUserinfoLabel);

this.add(rbError);
this.add(rbErrorLabel);

this.add(rbFatal);
this.add(rbFatalLabel);


	rbTrace.setChecked(Defs.ONSTARTUP_SHOW_TRACE_LOGS);
	rbTraceChecked = rbTrace.isChecked();
	rbDebug.setChecked(Defs.ONSTARTUP_SHOW_DEBUG_LOGS);
	rbDebugChecked = rbDebug.isChecked();
	rbInfo.setChecked(Defs.ONSTARTUP_SHOW_INFO_LOGS);
	rbInfoChecked = rbInfo.isChecked();
	rbWarn.setChecked(Defs.ONSTARTUP_SHOW_WARN_LOGS);
	rbWarnChecked = rbWarn.isChecked();
	rbUserinfo.setChecked(Defs.ONSTARTUP_SHOW_USERINFO_LOGS);
	rbUserinfoChecked = rbUserinfo.isChecked();
	rbError.setChecked(Defs.ONSTARTUP_SHOW_ERROR_LOGS);
	rbErrorChecked = rbError.isChecked();
	rbFatal.setChecked(Defs.ONSTARTUP_SHOW_FATAL_LOGS);
	rbFatalChecked = rbFatal.isChecked();


  chooseCriticityLabel.addStyleDependentName("lineHeaderLabel");
  rbTraceLabel.addStyleDependentName("radioButtonLabel");
  rbDebugLabel.addStyleDependentName("radioButtonLabel");
  rbInfoLabel.addStyleDependentName("radioButtonLabel");
  rbWarnLabel.addStyleDependentName("radioButtonLabel");
  rbUserinfoLabel.addStyleDependentName("radioButtonLabel");
  rbErrorLabel.addStyleDependentName("radioButtonLabel");
  rbFatalLabel.addStyleDependentName("radioButtonLabel");


  chooseCriticityLabel.setWordWrap(false);
  rbTraceLabel.setWordWrap(false);
  rbDebugLabel.setWordWrap(false);
  rbInfoLabel.setWordWrap(false);
  rbWarnLabel.setWordWrap(false);
  rbUserinfoLabel.setWordWrap(false);
  rbErrorLabel.setWordWrap(false);
  rbFatalLabel.setWordWrap(false);



rbTrace.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
  /*
    logReader.hideShowMessagesWithCriticity(	isRbTraceChecked(),
												rbDebugChecked,
												rbInfoChecked,
												rbWarnChecked,
												rbUserinfoChecked,
												rbErrorChecked,
												rbFatalChecked );
*/
isRbTraceChecked();
  logReader.redrawFlexTableAccordingToTreeMasking();
  }
} );


rbDebug.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
  /*
    logReader.hideShowMessagesWithCriticity(	rbTraceChecked,
												isRbDebugChecked(),
												rbInfoChecked,
												rbWarnChecked,
												rbUserinfoChecked,
												rbErrorChecked,
												rbFatalChecked );
*/
isRbDebugChecked();
  logReader.redrawFlexTableAccordingToTreeMasking();
  }
} );


rbInfo.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  { 
  /*
    logReader.hideShowMessagesWithCriticity(	rbTraceChecked,
												rbDebugChecked,
												isRbInfoChecked(),
												rbWarnChecked,
												rbUserinfoChecked,
												rbErrorChecked,
												rbFatalChecked );
*/
isRbInfoChecked();
  logReader.redrawFlexTableAccordingToTreeMasking();
  }
} );


rbWarn.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
  /*
    logReader.hideShowMessagesWithCriticity(	rbTraceChecked,
												rbDebugChecked,
												rbInfoChecked,
												isRbWarnChecked(),
												rbUserinfoChecked,
												rbErrorChecked,
												rbFatalChecked );
*/
isRbWarnChecked();
  logReader.redrawFlexTableAccordingToTreeMasking();
  }
} );


rbUserinfo.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  { 
  /*
    logReader.hideShowMessagesWithCriticity(	rbTraceChecked,
												rbDebugChecked,
												rbInfoChecked,
												rbWarnChecked,
												isRbUserinfoChecked(),
												rbErrorChecked,
												rbFatalChecked );
  */
  isRbUserinfoChecked();
  logReader.redrawFlexTableAccordingToTreeMasking();

  }
} );


rbError.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
  /*
    logReader.hideShowMessagesWithCriticity(	rbTraceChecked,
												rbDebugChecked,
												rbInfoChecked,
												rbWarnChecked,
												rbUserinfoChecked,
												isRbErrorChecked(),
												rbFatalChecked );
*/
isRbErrorChecked();
  logReader.redrawFlexTableAccordingToTreeMasking();
  }
} );


rbFatal.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
  /*
    logReader.hideShowMessagesWithCriticity(	rbTraceChecked,
												rbDebugChecked,
												rbInfoChecked,
												rbWarnChecked,
												rbUserinfoChecked,
												rbErrorChecked,
												isRbFatalChecked() );
*/
isRbFatalChecked();
  logReader.redrawFlexTableAccordingToTreeMasking();

  }
} );





  }
  




/*

  public void initializeControlCriticityPannel()
  {
	rbTrace.setChecked(false);
	rbTraceChecked = rbTrace.isChecked();
	rbDebug.setChecked(false);
	rbDebugChecked = rbDebug.isChecked();
	rbInfo.setChecked(false);
	rbInfoChecked = rbInfo.isChecked();
	rbWarn.setChecked(true);
	rbWarnChecked = rbWarn.isChecked();
	rbUserinfo.setChecked(true);
	rbUserinfoChecked = rbUserinfo.isChecked();
	rbError.setChecked(true);
	rbErrorChecked = rbError.isChecked();
	rbFatal.setChecked(true);
	rbFatalChecked = rbFatal.isChecked();
  }
*/


  public boolean isRbTraceChecked()
  {
	if (rbTraceChecked == true)
	{
		rbTrace.setChecked(false);
		rbTraceChecked = false;
		return false;
	}
	else
	{
		rbTrace.setChecked(true);
		rbTraceChecked = true;
		return true;

	}
  }


  public boolean isRbDebugChecked()
  {
	if (rbDebugChecked == true)
	{
		rbDebug.setChecked(false);
		rbDebugChecked = false;
		return false;
	}
	else
	{
		rbDebug.setChecked(true);
		rbDebugChecked = true;
		return true;

	}
  }


  public boolean isRbInfoChecked()
  {
	if (rbInfoChecked == true)
	{
		rbInfo.setChecked(false);
		rbInfoChecked = false;
		return false;
	}
	else
	{
		rbInfo.setChecked(true);
		rbInfoChecked = true;
		return true;

	}
  }




  public boolean isRbWarnChecked()
  {
	if (rbWarnChecked == true)
	{
		rbWarn.setChecked(false);
		rbWarnChecked = false;
		return false;
	}
	else
	{
		rbWarn.setChecked(true);
		rbWarnChecked = true;
		return true;

	}
  }


  public boolean isRbUserinfoChecked()
  {
	if (rbUserinfoChecked == true)
	{
		rbUserinfo.setChecked(false);
		rbUserinfoChecked = false;
		return false;
	}
	else
	{
		rbUserinfo.setChecked(true);
		rbUserinfoChecked = true;
		return true;

	}
  }


  public boolean isRbErrorChecked()
  {
	if (rbErrorChecked == true)
	{
		rbError.setChecked(false);
		rbErrorChecked = false;
		return false;
	}
	else
	{
		rbError.setChecked(true);
		rbErrorChecked = true;
		return true;

	}
  }

  public boolean isRbFatalChecked()
  {
	if (rbFatalChecked == true)
	{
		rbFatal.setChecked(false);
		rbFatalChecked = false;
		return false;
	}
	else
	{
		rbFatal.setChecked(true);
		rbFatalChecked = true;
		return true;

	}
  }












}


















