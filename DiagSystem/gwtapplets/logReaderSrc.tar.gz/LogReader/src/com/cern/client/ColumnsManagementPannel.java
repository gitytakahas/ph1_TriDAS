package com.cern.client;


//import com.google.gwt.user.client.ui;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
//import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.ListBox;

import com.google.gwt.user.client.ui.ChangeListener;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.user.client.Window;




public class ColumnsManagementPannel extends HorizontalPanel
{
public Defines Defs = new Defines();
   //Columns management related pannel
//  public HorizontalPanel columnManagementPanel = new HorizontalPanel();

  private Label columnManagementLabel = new Label("Set LogTable columns properties : ");

//Columns header widgets
ListBox lbLevel = new ListBox();
Label lbLevelLabel = new Label(Defs.LEVEL_LABEL+":");
public boolean showLbLevel;


ListBox lbErrCode = new ListBox();
Label lbErrCodeLabel = new Label(Defs.ERRCODE_LABEL+":");
public boolean showLbErrCode;

ListBox lbMessage = new ListBox();
Label lbMessageLabel = new Label(Defs.MESSAGE_LABEL+":");
public boolean showLbMessage;

ListBox lbTimestamp = new ListBox();
Label lbTimestampLabel = new Label(Defs.TIMESTAMP_LABEL+":");
public boolean showLbTimestamp;

ListBox lbSource = new ListBox();
Label lbSourceLabel = new Label(Defs.SOURCE_LABEL+":");
public boolean showLbSource;

ListBox lbSysid = new ListBox();
Label lbSysidLabel = new Label(Defs.SYSID_LABEL+":");
public boolean showLbSysid;

ListBox lbSubsysid = new ListBox();
Label lbSubsysidLabel = new Label(Defs.SUBSYSID_LABEL+":");
public boolean showLbSubsysid;

ListBox lbXtrabuff = new ListBox();
Label lbXtrabuffLabel = new Label(Defs.XTRABUFF_LABEL+":");
public boolean showLbXtrabuff;

ListBox lbMachine = new ListBox();
Label lbMachineLabel = new Label(Defs.MACHINE_LABEL+":");
public boolean showLbMachine;

ListBox lbPort = new ListBox();
Label lbPortLabel = new Label(Defs.PORT_LABEL+":");
public boolean showLbPort;

ListBox lbProcess = new ListBox();
Label lbProcessLabel = new Label(Defs.PROCNAME_LABEL+":");
public boolean showLbProcess;

ListBox lbInstance = new ListBox();
Label lbInstanceLabel = new Label(Defs.PROCINSTANCE_LABEL+":");
public boolean showLbInstance;

ListBox lbLogNumber = new ListBox();
Label lbLogNumberLabel = new Label(Defs.LOGNUMBER_LABEL+":");
public boolean showLbLogNumber;





  public ColumnsManagementPannel(final LogReader logReader) {

  //*******************************
  //assemble columnsManagement panel
  //*******************************
  this.add(columnManagementLabel);


for (int i=0; i < Defs.TOTAL_COLS_IN_TABLE; i++)
{

if ((Defs.LEVEL_COL == i) && (Defs.ONSTARTUP_SHOW_LEVEL_COL == true))
{
  this.add(lbLevelLabel);
  lbLevel.addItem(Defs.COLUMN_OPERATION_SHOW);
  lbLevel.addItem(Defs.COLUMN_OPERATION_HIDE);
  lbLevel.addItem(Defs.COLUMN_OPERATION_SORT);
  lbLevel.setVisibleItemCount(1);
  this.add(lbLevel);
}


if ((Defs.ERRCODE_COL == i) && (Defs.ONSTARTUP_SHOW_ERRCODE_COL == true))
{
  this.add(lbErrCodeLabel);
  lbErrCode.addItem(Defs.COLUMN_OPERATION_SHOW);
  lbErrCode.addItem(Defs.COLUMN_OPERATION_HIDE);
  lbErrCode.addItem(Defs.COLUMN_OPERATION_SORT);
  lbErrCode.setVisibleItemCount(1);
  this.add(lbErrCode);
}


if ((Defs.MSG_COL == i) && (Defs.ONSTARTUP_SHOW_MSG_COL == true))
{
  this.add(lbMessageLabel);
  lbMessage.addItem(Defs.COLUMN_OPERATION_SHOW);
  lbMessage.addItem(Defs.COLUMN_OPERATION_HIDE);
  lbMessage.addItem(Defs.COLUMN_OPERATION_SORT);
  lbMessage.setVisibleItemCount(1);
  this.add(lbMessage);
}


if ((Defs.TS_COL == i) && (Defs.ONSTARTUP_SHOW_TS_COL == true))
{
  this.add(lbTimestampLabel);
  lbTimestamp.addItem(Defs.COLUMN_OPERATION_SHOW);
  lbTimestamp.addItem(Defs.COLUMN_OPERATION_HIDE);
  lbTimestamp.addItem(Defs.COLUMN_OPERATION_SORT);
  lbTimestamp.setVisibleItemCount(1);
  this.add(lbTimestamp);
}


if ((Defs.SOURCE_COL == i) && (Defs.ONSTARTUP_SHOW_SOURCE_COL == true))
{
  this.add(lbSourceLabel);
  lbSource.addItem(Defs.COLUMN_OPERATION_SHOW);
  lbSource.addItem(Defs.COLUMN_OPERATION_HIDE);
  lbSource.addItem(Defs.COLUMN_OPERATION_SORT);
  lbSource.setVisibleItemCount(1);
  this.add(lbSource);
}


if ((Defs.SYSID_COL == i) && (Defs.ONSTARTUP_SHOW_SYSID_COL == true))
{
  this.add(lbSysidLabel);
  lbSysid.addItem(Defs.COLUMN_OPERATION_SHOW);
  lbSysid.addItem(Defs.COLUMN_OPERATION_HIDE);
  lbSysid.addItem(Defs.COLUMN_OPERATION_SORT);
  lbSysid.setVisibleItemCount(1);
  this.add(lbSysid);
}


if ((Defs.SUBSYSID_COL == i) && (Defs.ONSTARTUP_SHOW_SUBSYSID_COL == true))
{
  this.add(lbSubsysidLabel);
  lbSubsysid.addItem(Defs.COLUMN_OPERATION_SHOW);
  lbSubsysid.addItem(Defs.COLUMN_OPERATION_HIDE);
  lbSubsysid.addItem(Defs.COLUMN_OPERATION_SORT);
  lbSubsysid.setVisibleItemCount(1);
  this.add(lbSubsysid);
}


if ((Defs.XTRABUFF_COL == i) && (Defs.ONSTARTUP_SHOW_XTRABUFF_COL == true))
{
  this.add(lbXtrabuffLabel);
  lbXtrabuff.addItem(Defs.COLUMN_OPERATION_SHOW);
  lbXtrabuff.addItem(Defs.COLUMN_OPERATION_HIDE);
  lbXtrabuff.addItem(Defs.COLUMN_OPERATION_SORT);
  lbXtrabuff.setVisibleItemCount(1);
  this.add(lbXtrabuff);
}



if ((Defs.MACHINE_COL == i) && (Defs.ONSTARTUP_SHOW_MACHINE_COL == true))
{
  this.add(lbMachineLabel);
  lbMachine.addItem(Defs.COLUMN_OPERATION_SHOW);
  lbMachine.addItem(Defs.COLUMN_OPERATION_HIDE);
  lbMachine.addItem(Defs.COLUMN_OPERATION_SORT);
  lbMachine.setVisibleItemCount(1);
  this.add(lbMachine);
}


if ((Defs.PORT_COL == i) && (Defs.ONSTARTUP_SHOW_PORT_COL == true))
{
  this.add(lbPortLabel);
  lbPort.addItem(Defs.COLUMN_OPERATION_SHOW);
  lbPort.addItem(Defs.COLUMN_OPERATION_HIDE);
  lbPort.addItem(Defs.COLUMN_OPERATION_SORT);
  lbPort.setVisibleItemCount(1);
  this.add(lbPort);
}


if ((Defs.PROCNAME_COL == i) && (Defs.ONSTARTUP_SHOW_PROCNAME_COL == true))
{
  this.add(lbProcessLabel);
  lbProcess.addItem(Defs.COLUMN_OPERATION_SHOW);
  lbProcess.addItem(Defs.COLUMN_OPERATION_HIDE);
  lbProcess.addItem(Defs.COLUMN_OPERATION_SORT);
  lbProcess.setVisibleItemCount(1);
  this.add(lbProcess);
}



if ((Defs.PROCINST_COL == i) && (Defs.ONSTARTUP_SHOW_PROCINST_COL == true))
{
  this.add(lbInstanceLabel);
  lbInstance.addItem(Defs.COLUMN_OPERATION_SHOW);
  lbInstance.addItem(Defs.COLUMN_OPERATION_HIDE);
  lbInstance.addItem(Defs.COLUMN_OPERATION_SORT);
  lbInstance.setVisibleItemCount(1);
  this.add(lbInstance);
}


if ((Defs.LOGNUM_COL == i) && (Defs.ONSTARTUP_SHOW_LOGNUM_COL == true))
{
  this.add(lbLogNumberLabel);
  lbLogNumber.addItem(Defs.COLUMN_OPERATION_SHOW);
  lbLogNumber.addItem(Defs.COLUMN_OPERATION_HIDE);
  lbLogNumber.addItem(Defs.COLUMN_OPERATION_SORT);
  lbLogNumber.setVisibleItemCount(1);
  this.add(lbLogNumber);
}

}//End of FOR loop

  columnManagementLabel.setWordWrap(false);
  lbLevelLabel.setWordWrap(false);
  lbErrCodeLabel.setWordWrap(false);
  lbMessageLabel.setWordWrap(false);
  lbTimestampLabel.setWordWrap(false);
  lbSysidLabel.setWordWrap(false);
  lbSourceLabel.setWordWrap(false);
  lbSubsysidLabel.setWordWrap(false);
  lbXtrabuffLabel.setWordWrap(false);
  lbMachineLabel.setWordWrap(false);
  lbPortLabel.setWordWrap(false);
  lbProcessLabel.setWordWrap(false);
  lbInstanceLabel.setWordWrap(false);
  lbLogNumberLabel.setWordWrap(false);



  columnManagementLabel.addStyleDependentName("lineHeaderLabel");
  lbLevelLabel.addStyleDependentName("comboLabel");
  lbErrCodeLabel.addStyleDependentName("comboLabel");
  lbMessageLabel.addStyleDependentName("comboLabel");
  lbTimestampLabel.addStyleDependentName("comboLabel");
  lbSysidLabel.addStyleDependentName("comboLabel");
  lbSourceLabel.addStyleDependentName("comboLabel");
  lbSubsysidLabel.addStyleDependentName("comboLabel");
  lbXtrabuffLabel.addStyleDependentName("comboLabel");
  lbMachineLabel.addStyleDependentName("comboLabel");
  lbPortLabel.addStyleDependentName("comboLabel");
  lbProcessLabel.addStyleDependentName("comboLabel");
  lbInstanceLabel.addStyleDependentName("comboLabel");
  lbLogNumberLabel.addStyleDependentName("comboLabel");


	showLbLevel = Defs.ONSTARTUP_SHOW_LEVEL_COL;
	showLbErrCode = Defs.ONSTARTUP_SHOW_ERRCODE_COL;
	showLbMessage = Defs.ONSTARTUP_SHOW_MSG_COL;
	showLbTimestamp = Defs.ONSTARTUP_SHOW_TS_COL;
	showLbSource = Defs.ONSTARTUP_SHOW_SOURCE_COL;
	showLbSysid = Defs.ONSTARTUP_SHOW_SYSID_COL;
	showLbSubsysid = Defs.ONSTARTUP_SHOW_SUBSYSID_COL;
	showLbXtrabuff = Defs.ONSTARTUP_SHOW_XTRABUFF_COL;
	showLbMachine = Defs.ONSTARTUP_SHOW_MACHINE_COL;
	showLbPort = Defs.ONSTARTUP_SHOW_PORT_COL;
	showLbProcess = Defs.ONSTARTUP_SHOW_PROCNAME_COL;
	showLbInstance = Defs.ONSTARTUP_SHOW_PROCINST_COL;
	showLbLogNumber = Defs.ONSTARTUP_SHOW_LOGNUM_COL;





lbLevel.addChangeListener( new ChangeListener()
{
	public void onChange(Widget sender)
	{

		ListBox listBox = (ListBox)sender;
		int index = listBox.getSelectedIndex();
		String itemText = listBox.getItemText(index);

		if (itemText.equals(Defs.COLUMN_OPERATION_SHOW))
		{
			logReader.hideShowFlexTableColumn(true, Defs.LEVEL_COL);
			showLbLevel = true;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_HIDE))
		{
			logReader.hideShowFlexTableColumn(false, Defs.LEVEL_COL);
			showLbLevel = false;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_SORT))
		{
			//Window window = new Window();
			Window.alert("Feature not yet implemented.");
		}


	}
} );





lbErrCode.addChangeListener( new ChangeListener()
{
	public void onChange(Widget sender)
	{

		ListBox listBox = (ListBox)sender;
		int index = listBox.getSelectedIndex();
		String itemText = listBox.getItemText(index);

		if (itemText.equals(Defs.COLUMN_OPERATION_SHOW))
		{
			logReader.hideShowFlexTableColumn(true, Defs.ERRCODE_COL);
			showLbErrCode = true;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_HIDE))
		{
			logReader.hideShowFlexTableColumn(false, Defs.ERRCODE_COL);
			showLbErrCode = false;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_SORT))
		{
			//Window window = new Window();
			Window.alert("Feature not yet implemented.");
		}


	}
} );




lbMessage.addChangeListener( new ChangeListener()
{
	public void onChange(Widget sender)
	{

		ListBox listBox = (ListBox)sender;
		int index = listBox.getSelectedIndex();
		String itemText = listBox.getItemText(index);

		if (itemText.equals(Defs.COLUMN_OPERATION_SHOW))
		{
			logReader.hideShowFlexTableColumn(true, Defs.MSG_COL);
			showLbMessage = true;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_HIDE))
		{
			logReader.hideShowFlexTableColumn(false, Defs.MSG_COL);
			showLbMessage = false;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_SORT))
		{
			//Window window = new Window();
			Window.alert("Feature not yet implemented.");
		}


	}
} );







lbTimestamp.addChangeListener( new ChangeListener()
{
	public void onChange(Widget sender)
	{

		ListBox listBox = (ListBox)sender;
		int index = listBox.getSelectedIndex();
		String itemText = listBox.getItemText(index);

		if (itemText.equals(Defs.COLUMN_OPERATION_SHOW))
		{
			logReader.hideShowFlexTableColumn(true, Defs.TS_COL);
			showLbTimestamp = true;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_HIDE))
		{
			logReader.hideShowFlexTableColumn(false, Defs.TS_COL);
			showLbTimestamp = false;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_SORT))
		{
			//Window window = new Window();
			Window.alert("Feature not yet implemented.");
		}


	}
} );





lbSource.addChangeListener( new ChangeListener()
{
	public void onChange(Widget sender)
	{

		ListBox listBox = (ListBox)sender;
		int index = listBox.getSelectedIndex();
		String itemText = listBox.getItemText(index);

		if (itemText.equals(Defs.COLUMN_OPERATION_SHOW))
		{
			logReader.hideShowFlexTableColumn(true, Defs.SOURCE_COL);
			showLbSource = true;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_HIDE))
		{
			logReader.hideShowFlexTableColumn(false, Defs.SOURCE_COL);
			showLbSource = false;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_SORT))
		{
			//Window window = new Window();
			Window.alert("Feature not yet implemented.");
		}


	}
} );







lbSysid.addChangeListener( new ChangeListener()
{
	public void onChange(Widget sender)
	{

		ListBox listBox = (ListBox)sender;
		int index = listBox.getSelectedIndex();
		String itemText = listBox.getItemText(index);

		if (itemText.equals(Defs.COLUMN_OPERATION_SHOW))
		{
			logReader.hideShowFlexTableColumn(true, Defs.SYSID_COL);
			showLbSysid = true;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_HIDE))
		{
			logReader.hideShowFlexTableColumn(false, Defs.SYSID_COL);
			showLbSysid = false;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_SORT))
		{
			//Window window = new Window();
			Window.alert("Feature not yet implemented.");
		}


	}
} );





lbSubsysid.addChangeListener( new ChangeListener()
{
	public void onChange(Widget sender)
	{

		ListBox listBox = (ListBox)sender;
		int index = listBox.getSelectedIndex();
		String itemText = listBox.getItemText(index);

		if (itemText.equals(Defs.COLUMN_OPERATION_SHOW))
		{
			logReader.hideShowFlexTableColumn(true, Defs.SUBSYSID_COL);
			showLbSubsysid = true;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_HIDE))
		{
			logReader.hideShowFlexTableColumn(false, Defs.SUBSYSID_COL);
			showLbSubsysid = false;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_SORT))
		{
			//Window window = new Window();
			Window.alert("Feature not yet implemented.");
		}


	}
} );







lbXtrabuff.addChangeListener( new ChangeListener()
{
	public void onChange(Widget sender)
	{

		ListBox listBox = (ListBox)sender;
		int index = listBox.getSelectedIndex();
		String itemText = listBox.getItemText(index);

		if (itemText.equals(Defs.COLUMN_OPERATION_SHOW))
		{
			logReader.hideShowFlexTableColumn(true, Defs.XTRABUFF_COL);
			showLbXtrabuff = true;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_HIDE))
		{
			logReader.hideShowFlexTableColumn(false, Defs.XTRABUFF_COL);
			showLbXtrabuff = false;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_SORT))
		{
			//Window window = new Window();
			Window.alert("Feature not yet implemented.");
		}


	}
} );





lbMachine.addChangeListener( new ChangeListener()
{
	public void onChange(Widget sender)
	{

		ListBox listBox = (ListBox)sender;
		int index = listBox.getSelectedIndex();
		String itemText = listBox.getItemText(index);

		if (itemText.equals(Defs.COLUMN_OPERATION_SHOW))
		{
			logReader.hideShowFlexTableColumn(true, Defs.MACHINE_COL);
			showLbMachine = true;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_HIDE))
		{
			logReader.hideShowFlexTableColumn(false, Defs.MACHINE_COL);
			showLbMachine = false;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_SORT))
		{
			//Window window = new Window();
			Window.alert("Feature not yet implemented.");
		}


	}
} );







lbPort.addChangeListener( new ChangeListener()
{
	public void onChange(Widget sender)
	{

		ListBox listBox = (ListBox)sender;
		int index = listBox.getSelectedIndex();
		String itemText = listBox.getItemText(index);

		if (itemText.equals(Defs.COLUMN_OPERATION_SHOW))
		{
			logReader.hideShowFlexTableColumn(true, Defs.PORT_COL);
			showLbPort = true;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_HIDE))
		{
			logReader.hideShowFlexTableColumn(false, Defs.PORT_COL);
			showLbPort = false;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_SORT))
		{
			//Window window = new Window();
			Window.alert("Feature not yet implemented.");
		}


	}
} );





lbProcess.addChangeListener( new ChangeListener()
{
	public void onChange(Widget sender)
	{

		ListBox listBox = (ListBox)sender;
		int index = listBox.getSelectedIndex();
		String itemText = listBox.getItemText(index);

		if (itemText.equals(Defs.COLUMN_OPERATION_SHOW))
		{
			logReader.hideShowFlexTableColumn(true, Defs.PROCNAME_COL);
			showLbProcess = true;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_HIDE))
		{
			logReader.hideShowFlexTableColumn(false, Defs.PROCNAME_COL);
			showLbProcess = false;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_SORT))
		{
			//Window window = new Window();
			Window.alert("Feature not yet implemented.");
		}


	}
} );




lbInstance.addChangeListener( new ChangeListener()
{
	public void onChange(Widget sender)
	{

		ListBox listBox = (ListBox)sender;
		int index = listBox.getSelectedIndex();
		String itemText = listBox.getItemText(index);

		if (itemText.equals(Defs.COLUMN_OPERATION_SHOW))
		{
			logReader.hideShowFlexTableColumn(true, Defs.PROCINST_COL);
			showLbInstance = true;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_HIDE))
		{
			logReader.hideShowFlexTableColumn(false, Defs.PROCINST_COL);
			showLbInstance = false;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_SORT))
		{
			//Window window = new Window();
			Window.alert("Feature not yet implemented.");
		}


	}
} );



lbLogNumber.addChangeListener( new ChangeListener()
{
	public void onChange(Widget sender)
	{

		ListBox listBox = (ListBox)sender;
		int index = listBox.getSelectedIndex();
		String itemText = listBox.getItemText(index);

		if (itemText.equals(Defs.COLUMN_OPERATION_SHOW))
		{
			logReader.hideShowFlexTableColumn(true, Defs.LOGNUM_COL);
			showLbLogNumber = true;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_HIDE))
		{
			logReader.hideShowFlexTableColumn(false, Defs.LOGNUM_COL);
			showLbLogNumber = false;
		}

		if (itemText.equals(Defs.COLUMN_OPERATION_SORT))
		{
			//Window window = new Window();
			Window.alert("Feature not yet implemented.");
		}


	}
} );




  } // End of ColumnsManagementPannel constructor method
  










} //End of class




