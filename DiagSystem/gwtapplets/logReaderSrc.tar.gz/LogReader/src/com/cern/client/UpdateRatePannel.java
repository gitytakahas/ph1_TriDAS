package com.cern.client;

import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RadioButton;

import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;

import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Button;


public class UpdateRatePannel extends HorizontalPanel
{

  private Label updateRateLabel = new Label("Update Rate in milliseconds : ");
  TextBox updateRate = new TextBox();
  Button applyButton = new Button("Apply");



  private Label updateStreamingRateLabel = new Label("Update Streaming Rate in milliseconds : ");
  TextBox updateStreamingRate = new TextBox();
  Button applyStreamingButton = new Button("Apply");


  public UpdateRatePannel(final LogReader logReader) {


  this.add(updateRateLabel);
  updateRateLabel.addStyleDependentName("lineHeaderLabel");
  updateRateLabel.setWordWrap(false);



this.add(updateRate);


this.add(applyButton);





  this.add(updateStreamingRateLabel);
  updateStreamingRateLabel.addStyleDependentName("lineHeaderLabel");
  updateStreamingRateLabel.setWordWrap(false);



this.add(updateStreamingRate);


this.add(applyStreamingButton);



applyButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
		logReader.userdefinedRefreshInterval = updateRate.getText();
		logReader.updateRefreshRate();
  }
} );





applyStreamingButton.addClickListener(new ClickListener()
{
  public void onClick(Widget sender)
  {  
		logReader.userdefinedStreamingRefreshInterval = updateStreamingRate.getText();
		logReader.updateStreamingRefreshRate();
  }
} );




}


}










