/*
   FileName : 		FecDummySupervisor.h

   Content : 		FecDummySupervisor module

   Used in : 		Tracker Diagnostic System

   Programmer : 	Laurent GROSS

   Version : 		TDS 1.3

   Date of last modification : 03/03/2006

   Support : 		mail to : laurent.gross@ires.in2p3.fr
   
   Online help : 	https://uimon.cern.ch/twiki/bin/view/CMS/DiagnosticSystem
*/
/*
This file is part of Fec Software project.

Fec Software is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

Fec Software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Fec Software; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Copyright 2005, Laurent GROSS - IReS/IN2P3
*/

#ifndef _FecDummySupervisor_h_
#define _FecDummySupervisor_h_

#ifndef _SOAPStateMachine_h_
#define _SOAPStateMachine_h_


#include "xdaq/Application.h"
#include "xdaq/ApplicationGroup.h"
#include "xdaq/ApplicationContext.h"
#include "xdaq/ApplicationStub.h"
#include "xdaq/exception/Exception.h"
#include "xdaq/NamespaceURI.h"

#include "xoap/MessageReference.h"
#include "xoap/MessageFactory.h"
#include "xoap/SOAPEnvelope.h"
#include "xoap/SOAPBody.h"
#include "xoap/Method.h"


#include "xgi/Utils.h"
#include "xgi/Method.h"
#include "cgicc/CgiDefs.h"
#include "cgicc/Cgicc.h"
#include "cgicc/HTTPHTMLHeader.h"
#include "cgicc/HTMLClasses.h"

#include "xdata/String.h"
#include "xdata/UnsignedLong.h"

#include <iostream>
#include <sstream>
#include <string>

#include <diagbag/DiagBagWizard.h>

class FecDummySupervisor: public xdaq::Application  
{

public:

	//DIAGREQUESTED
	DiagBagWizard * diagService_;

	//! define factory method for instantion of HelloWorld application
	XDAQ_INSTANTIATOR();

	FecDummySupervisor(xdaq::ApplicationStub * s) throw (xdaq::exception::Exception): xdaq::Application(s)
	{
		//DIAGREQUESTED
		 diagService_ = new DiagBagWizard(
 			 (getApplicationDescriptor()->getClassName() + "DiagLvlOne") ,
 			 this->getApplicationLogger(),
			 getApplicationDescriptor()->getClassName(),
			 getApplicationDescriptor()->getInstance(),
			 getApplicationDescriptor()->getLocalId(),
			 (xdaq::WebApplication *)this
			  );
		  diagService_->setDiagName("FecLclErrorDispatcher");
		  diagService_->setSentinelContextName("FecErrorsPool");

		// A simple web control interface
		xgi::bind(this,&FecDummySupervisor::Default, "Default");
		xgi::bind(this,&FecDummySupervisor::sendReconfAutoLog, "sendReconfAutoLog");
		xgi::bind(this,&FecDummySupervisor::sendReconfStopLog, "sendReconfStopLog");
		xgi::bind(this,&FecDummySupervisor::sendReconfRunLog, "sendReconfRunLog");
		xgi::bind(this,&FecDummySupervisor::sendReconfLog, "sendReconfLog");
		xgi::bind(this,&FecDummySupervisor::sendInfoLog, "sendInfoLog");

		//DIAGREQUESTED
		xgi::bind(this,&FecDummySupervisor::configureDiagSystem, "configureDiagSystem");
		xgi::bind(this,&FecDummySupervisor::applyConfigureDiagSystem, "applyConfigureDiagSystem");

		//RECONFREQUESTED
		xoap::bind(this, &FecDummySupervisor::recovery100, "recovery100", XDAQ_NS_URI );

		DIAG_APPLY_CALLBACK_FOR_FIRST_TIME
	}



	void Default(xgi::Input * in, xgi::Output * out ) throw (xgi::exception::Exception)
	{
		*out << cgicc::HTMLDoctype(cgicc::HTMLDoctype::eStrict) << std::endl;
		*out << cgicc::html().set("lang", "en").set("dir","ltr") << std::endl;
		*out << cgicc::title("FEC DummySupervisor") << std::endl;

		xgi::Utils::getPageHeader
			(out, 
			"FEC DummySupervisor Configuration page", 
			getApplicationDescriptor()->getContextDescriptor()->getURL(),
			getApplicationDescriptor()->getURN(),
			"/daq/xgi/images/Application.jpg"
			);


		std::string urlReconfAuto = "/";
		urlReconfAuto += getApplicationDescriptor()->getURN();
		urlReconfAuto += "/sendReconfAutoLog";	
		*out << cgicc::form().set("method","post").set("action", urlReconfAuto).set("enctype","multipart/form-data") << std::endl;
		*out << cgicc::input().set("type", "submit").set("name", "send").set("value", "Send Auto-Reconfiguration Log");
		*out << cgicc::p() << std::endl;
		*out << cgicc::form() << std::endl;


		std::string urlReconfStop = "/";
		urlReconfStop += getApplicationDescriptor()->getURN();
		urlReconfStop += "/sendReconfStopLog";	
		*out << cgicc::form().set("method","post").set("action", urlReconfStop).set("enctype","multipart/form-data") << std::endl;
		*out << cgicc::input().set("type", "submit").set("name", "send").set("value", "Send ReconfStop Log");
		*out << cgicc::p() << std::endl;
		*out << cgicc::form() << std::endl;


		std::string urlReconfRun = "/";
		urlReconfRun += getApplicationDescriptor()->getURN();
		urlReconfRun += "/sendReconfRunLog";	
		*out << cgicc::form().set("method","post").set("action", urlReconfRun).set("enctype","multipart/form-data") << std::endl;
		*out << cgicc::input().set("type", "submit").set("name", "send").set("value", "Send ReconfRun Log");
		*out << cgicc::p() << std::endl;
		*out << cgicc::form() << std::endl;


		std::string urlReconf = "/";
		urlReconf += getApplicationDescriptor()->getURN();
		urlReconf += "/sendReconfLog";	
		*out << cgicc::form().set("method","post").set("action", urlReconf).set("enctype","multipart/form-data") << std::endl;
		*out << cgicc::input().set("type", "submit").set("name", "send").set("value", "Send Reconf Log");
		*out << cgicc::p() << std::endl;
		*out << cgicc::form() << std::endl;


		std::string urlInfo = "/";
		urlInfo += getApplicationDescriptor()->getURN();
		urlInfo += "/sendInfoLog";	
		*out << cgicc::form().set("method","post").set("action", urlInfo).set("enctype","multipart/form-data") << std::endl;
		*out << cgicc::input().set("type", "submit").set("name", "send").set("value", "Send Info Log");
		*out << cgicc::p() << std::endl;
		*out << cgicc::form() << std::endl;

		//DIAGREQUESTED
		DIAG_SET_CONFIG_CALLBACK();

		xgi::Utils::getPageFooter(*out);
	}




	//DIAGREQUESTED
	void FecDummySupervisor::DIAG_CONFIGURE_CALLBACK();

	//DIAGREQUESTED
	void FecDummySupervisor::DIAG_APPLY_CALLBACK();



	void sendReconfAutoLog(xgi::Input * in, xgi::Output * out ) throw (xgi::exception::Exception)
	{
		diagService_->reportError("This is a Reconfiguration Request following occurence of Error Code 100 in a process",
		DIAGINFO,
		"RECONFCMD",
		100,
		"STEADY",
		"TRACKER",
		"TEC");

		this->Default(in,out);
	}


	void sendReconfStopLog(xgi::Input * in, xgi::Output * out ) throw (xgi::exception::Exception)
	{
		diagService_->reportError("This is a Reconfiguration STOP Log",
		 DIAGINFO,
		 "RECONFSTOP",
		 72,
		 "STEADY",
		 "TRACKER",
		 "TEC");

		this->Default(in,out);
	}


	void sendReconfRunLog(xgi::Input * in, xgi::Output * out ) throw (xgi::exception::Exception)
	{
	
		diagService_->reportError("This is a Reconfiguration Log, bringing infos about current reconfiguration action",
		DIAGINFO,
		"RECONFRUN",
		72,
		"STEADY",
		"TRACKER",
		"TEC");

		this->Default(in,out);
	}


	void sendReconfLog(xgi::Input * in, xgi::Output * out ) throw (xgi::exception::Exception)
	{
		diagService_->reportError("This is a Reconfiguration Log",
		DIAGINFO,
		"RECONFCMD",
		72,
		"STEADY",
		"TRACKER",
		"TEC");

		this->Default(in,out);
	}



	void sendInfoLog(xgi::Input * in, xgi::Output * out ) throw (xgi::exception::Exception)
	{
		diagService_->reportError("This is a simple Info Log", DIAGINFO);
		this->Default(in,out);
	}


	//RECONFREQUESTED
	xoap::MessageReference recovery100(xoap::MessageReference msg) throw (xoap::exception::Exception)
	{
		// reply to caller
		xoap::MessageReference reply = xoap::createMessage();
		xoap::SOAPEnvelope envelope = reply->getSOAPPart().getEnvelope();
		xoap::SOAPName responseName = envelope.createName( "receivedLogResponse", "xdaq", XDAQ_NS_URI);
		envelope.getBody().addBodyElement ( responseName );
	    
		diagService_->reportError("Entering reconf100 method : starting Reconfiguration block execution", DIAGINFO);

		diagService_->reportError("In reconf100 method, info message dedicated to level1 : Reconfiguration block running, temp result is : OK",
		 DIAGINFO,
		 "RECONFRUN",
		 100,
		 "STEADY",
		 "TRACKER",
		 "TEC");

		diagService_->reportError("Ending reconf100 method : Reconfiguration block executed, result is : OK. RECONF mode should now be switched OFF.",
		 DIAGINFO,
		 "RECONFSTOP",
		 100,
		 "STEADY",
		 "TRACKER",
		 "TEC");

	    return reply;
	}



};

#endif
#endif
